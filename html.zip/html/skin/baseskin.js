﻿/**
baseskin.js
*/
var BaseSkin = new Class({
	
	initialize: function(o){
		try {
			this.skin = new Skin();
		} catch(e){/*alert(e);*/}
		this.UI_HEADER_HEIGHT = this.setHeaderHeight();
		this.UI_FOOTER_HEIGHT = this.setFooterHeight();
		this.UI_BREADCRUMB_HEIGHT = this.setBreadcrumbHeight();
		this.UI_MENU_WIDTH = this.setMenuWidth();
		this.UI_MENU_HEADER_HEIGHT = this.setMenuHeader();
    },
    
    setHeaderHeight: function(){
    	var h = Utils.dom.getCurrentStyleAsNum($('header'),"height");
		h = ($('header')).offsetHeight;
		return h;
    },
    
    setFooterHeight: function(){
    	var h = Utils.dom.getCurrentStyleAsNum($('footer'),"min-height");
		h = ($('footer')).offsetHeight;
		return h;
    },
    
    setBreadcrumbHeight: function(){
    	return Utils.dom.getCurrentStyleAsNum($('breadcrumb'),"height");
    },
    
    setMenuWidth: function(){
    	return Utils.dom.getCurrentStyleAsNum($('menu'),"width");
    },
    
    setMenuHeader: function(){
    	return Utils.dom.getCurrentStyleAsNum($('menuHeader'),"height");
    },
    
    setClearTypeFix: function(){
    	// Cleartype rendering fix for IE
    	if (this.skin){return;}
		Utils.dom.removeFilter($("menuBtn"));
		Utils.dom.removeFilter($("historyBtn"));
    },
    
    setInitHeader: function(){
    	$('header').setStyle('top', Conf.UI_MARGIN);
    	$('header').setStyle('left', Conf.UI_MARGIN);
		//this.header.style.height = this.UI_HEADER_HEIGHT +'px';
    },
    
    setInitFooter: function(){
    	if (this.skin){this.skin.setInitFooter();}
    	$('footer').setStyle('bottom', Conf.UI_MARGIN);
    	$('footer').setStyle('left', Conf.UI_MARGIN);
		//this.footer.style.height = this.UI_FOOTER_HEIGHT +'px';
    },
    
    setInitTranscript: function(transcriptHeight){
    	if (this.skin){
    		this.skin.setInitTranscript(transcriptHeight);
    		return;
    	}
    	$('transcript').setStyle('left', Conf.UI_MARGIN);
    	var b = Conf.UI_MARGIN + this.UI_FOOTER_HEIGHT;
    	$('transcript').setStyle('bottom', b);
    	$('transcript').setStyle('height', transcriptHeight);
    },
    
    setInitBreadCrumb: function(){
    	$('breadcrumb').setStyle('left', Conf.UI_MARGIN);
    	$('breadcrumb').setStyle('height', this.UI_BREADCRUMB_HEIGHT);
    },
    
    setInitContent: function(){
    	if (this.skin){return;}
    	$('content').setStyle('left', Conf.UI_MARGIN);
    },
    
    setInitMenu: function(){
    	$('menu').setStyle('left', Conf.UI_MARGIN);
    },
    
    setInitHistory: function(){
    	$('history').setStyle('left ', Conf.UI_MARGIN);
    },
    
    setInitResource: function(){
    	$('resource').setStyle('left ', Conf.UI_MARGIN);
    },
    
    setHeader: function(viewWidth){
    	if (this.skin){
    		this.skin.setHeader(viewWidth);
    		return;
    	}
		try
		{
			var w = viewWidth -(Conf.UI_MARGIN*2);
			//alert("header: " + w);
			$('header').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting header width ("+w+"): "+(e.description || e),'error');}
    },

    setBreadcrumb: function(viewWidth){
    	if (this.skin){
    		this.skin.setBreadcrumb(viewWidth);
    		return;
    	}
		try
		{
			var t = Conf.UI_MARGIN + this.UI_HEADER_HEIGHT;
			//alert("breadcrumb top: " + t);
			$('breadcrumb').setStyle('top', t);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting breadcrumb top ("+t+"): "+(e.description || e),'error');}
		
		try
		{
			var w = viewWidth-(Conf.UI_MARGIN*2);
			//alert("breadcrumb width: " + w);
			$('breadcrumb').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting breadcrumb width ("+w+"): "+(e.description || e),'error');}
    },

    setTranscript: function(viewWidth){
    	if (this.skin){
    		this.skin.setTranscript();
    		return;
    	}
    	try
    	{
    		var w = viewWidth-(Conf.UI_MARGIN*2);
    		//alert("transcript: " + w);
    		$('transcript').setStyle('width', w);
    	}
    	catch(e){Utils.debug.trace("Error in ui.updateLayout setting transcript style width ("+w+"): "+(e.description || e),'error');}
    },

    setFooter: function(viewWidth, viewHeight){
    	if (this.skin){	this.skin.refresh($('footer')); }
		try
		{
			var w = viewWidth-(Conf.UI_MARGIN*2);
			//alert("footer: " + w);
			$('footer').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting footer width ("+w+"): "+(e.description || e),'error');}
		if (this.skin){	this.skin.setFooter(viewHeight); }
    },
    
    setRound: function(viewWidth, viewHeight){
    	if (this.skin){this.skin.setRound(viewWidth, viewHeight);}
    },
    
    setContent: function(transcriptHeight, viewWidth, viewHeight){
    	if (this.skin){
    		this.skin.setContent();
    		return;
    	}
    	var t = this.UI_HEADER_HEIGHT + Conf.UI_MARGIN + this.UI_BREADCRUMB_HEIGHT;
    	//alert("content top: " + t);
    	$('content').setStyle('top', t);
    	try
		{
			var h = viewHeight-(this.UI_HEADER_HEIGHT+this.UI_FOOTER_HEIGHT+(Conf.UI_MARGIN*2)+this.UI_BREADCRUMB_HEIGHT+transcriptHeight);
			//alert("content height: " + h);
			$('content').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting content frame height ("+h+"): "+(e.description || e),'error');}
		try
		{
			var w = viewWidth-(Conf.UI_MARGIN*2);
			//alert("content width: " + w);
			$('content').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting content frame width ("+w+"): "+(e.description || e),'error');}
    },
    
    setMenu: function(){
    	if (this.skin){
    		this.skin.setMenu();
    		return;
    	}
    	var t = $('content').getStyle('top').toInt(); 
    	$('menu').setStyle('top', t);
    	
    	var h = $('content').getStyle('height').toInt(); 
    	try
		{
    		$('menu').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting menu height ("+h+"): "+(e.description || e),'error');}
		
		$('menu').setStyle('width', this.UI_MENU_WIDTH);
		
		$('menu').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('menu').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var contentH = h - this.UI_MENU_HEADER_HEIGHT;
			$('menuContent').setStyle('height', contentH);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting menuContent height("+h+"): "+(e.description || e),'error');}
		
		$('menuContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    setHistory: function(){
    	if (this.skin){
    		this.skin.setHistory();
    		return;
    	}
    	var t = $('content').getStyle('top').toInt(); 
    	$('history').setStyle('top', t);
    	
    	var h = $('content').getStyle('height').toInt(); 
		try
		{
			$('history').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting history height("+h+"): "+(e.description || e),'error');}
		
		$('history').setStyle('width', this.UI_MENU_WIDTH);
		
		$('historyHeader').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('historyHeader').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var historyContentH = h - this.UI_MENU_HEADER_HEIGHT;
			$('historyContent').setStyle('height', historyContentH);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting historyContent height("+h+"): "+(e.description || e),'error');}
		
		$('historyContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    setResource: function(){
    	if (this.skin){
    		this.skin.setResource();
    		return;
    	}
    	var t = $('content').getStyle('top').toInt(); 
    	$('resource').setStyle('top', t);
    	
    	var h = $('content').getStyle('height').toInt(); 
		try
		{
			$('resource').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting history height("+h+"): "+(e.description || e),'error');}
		
		$('resource').setStyle('width', this.UI_MENU_WIDTH);
		
		$('resourceHeader').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('resourceHeader').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var historyContentH = h - this.UI_MENU_HEADER_HEIGHT;
			$('resourceContent').setStyle('height', historyContentH);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting historyContent height("+h+"): "+(e.description || e),'error');}
		
		$('resourceContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    refreshTranscript: function(){
    	if (this.skin){this.skin.refreshTranscript();}
		//empty
	},
	
	checkBrowserVersion: function(){
		 if (this.skin){this.skin.checkBrowserVersion();}
	}

});
