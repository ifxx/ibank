﻿/**
skin.js
Uncomment the class below to add script-level control to your custom skin
*/

/*
var Skin = new Class({
	Extends: BaseSkin,
	
	initialize: function(o){
		this.UI_HEADER_HEIGHT = this.setHeaderHeight();
		this.UI_FOOTER_HEIGHT = this.setFooterHeight();
		this.UI_BREADCRUMB_HEIGHT = this.setBreadcrumbHeight();
		this.UI_MENU_WIDTH = this.setMenuWidth();
		this.UI_MENU_HEADER_HEIGHT = this.setMenuHeader();
    },
    
    setHeaderHeight: function(){
    	return this.parent();
    },
    
    setFooterHeight: function(){
    	return this.parent();
    },
    
    setBreadcrumbHeight: function(){
    	return this.parent();
    },
    
    setMenuWidth: function(){
    	return this.parent();
    },
    
    setMenuHeader: function(){
    	return this.parent();
    },
    
    setInitFooter: function(){
    	//to fix IE8 and IE7 Round edges bug
    	this.refresh($('footer'));
    },
    
    setInitTranscript: function(transcriptHeight){
		var b = Conf.UI_MARGIN + this.UI_FOOTER_HEIGHT;
		$('transcript').setStyle('bottom', b);
    	$('transcript').setStyle('height', transcriptHeight);
    },
    
    setHeader: function(viewWidth){	
		try
		{
			var retroHdr = this.returnStyleNum($('header'),"margin-right");
			var w = viewWidth-(Conf.UI_MARGIN*2) + retroHdr;
			$('header').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting header width ("+w+"): "+(e.description || e),'error');}
    },

    setBreadcrumb: function (viewWidth){
		try
		{
			var retroBreadCrumbTop = this.returnStyleNum($('breadcrumb'),"top");
			$('breadcrumb').setStyle('top', retroBreadCrumbTop);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting breadcrumb top ("+ retroBreadCrumbTop +"): "+(e.description || e),'error');}
		
		try
		{
			var retroBreadCrumbWidth = this.returnStyleNum($('breadcrumb'),"margin-right");
			var w = viewWidth-(Conf.UI_MARGIN*2) + retroBreadCrumbWidth;
			$('breadcrumb').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting breadcrumb width ("+w+"): "+(e.description || e),'error');}
    },

    setTranscript: function(){
    	
		try
		{
			var w = this.returnStyleNum($('transcript'),"width");
			$('transcript').setStyle('width', w);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting transcript style width ("+w+"): "+(e.description || e),'error');}
    },

    setFooter: function(viewHeight){
		//to fix IE8 and IE7 Round edges bug - seems like PIE.htc needs top defined to render properly
		try
		{
			var t = viewHeight-(this.UI_FOOTER_HEIGHT/2)-Conf.UI_MARGIN*2;
			$('footer').setStyle('top', t);
			this.change($('footer'));
			$('footer').setStyle('top', "");
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting footer top ("+t+"): "+(e.description || e),'error');}
    },
    
    setRound: function(viewWidth, viewHeight){	
		try
		{
			$('round').setStyle('left', Conf.UI_MARGIN);
			var t = this.UI_HEADER_HEIGHT + Conf.UI_MARGIN + this.UI_BREADCRUMB_HEIGHT;
			$('round').setStyle('top', t);
			//remove transcript height from calculated round div height
			var roundMarginBottom = this.returnStyleNum($('round'),"margin-bottom"); 
			var h = viewHeight-(this.UI_HEADER_HEIGHT+this.UI_FOOTER_HEIGHT+(Conf.UI_MARGIN*2)+this.UI_BREADCRUMB_HEIGHT) + roundMarginBottom;
			$('round').setStyle('height', h);
			var w = viewWidth-(Conf.UI_MARGIN*2);
			$('round').setStyle('width', w);				
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting round div margin bottom: "+(e.description || e),'error');}
    },
    
    setContent: function(){
		try
		{
			// offset by content top margin so that the rounded corners can show
			var h = ($('round').getStyle('height').toInt())-Utils.dom.getCurrentStyleAsNum($('content'),"top");
			$('content').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting content frame height ("+h+"): "+(e.description || e),'error');}
		
		try
		{
			$('content').setStyle('width', $('round').getStyle('width').toInt());
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting content frame width ("+w+"): "+(e.description || e),'error');}
    	
    },
    
    setMenu: function(){
    	$('menu').setStyle('top', $('round').getStyle('top').toInt());
		try
		{
			var h = $('round').getStyle('height').toInt() + this.returnStyleNum($('menu'),"margin-bottom");
			$('menu').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting menu height ("+h+"): "+(e.description || e),'error');}
		
		$('menu').setStyle('width', this.UI_MENU_WIDTH);
		
		$('menuHeader').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('menuHeader').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var h = $('round').getStyle('height').toInt() - this.UI_MENU_HEADER_HEIGHT + this.returnStyleNum($('menu'),"margin-bottom");
			$('menuContent').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting menuContent height("+h+"): "+(e.description || e),'error');}
		
		$('menuContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    setHistory: function(){ 	
		$('history').setStyle('top', $('round').getStyle('top').toInt());
		try
		{
			var h = $('round').getStyle('height').toInt() + this.returnStyleNum($('history'),"margin-bottom");
			$('history').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting history height("+h+"): "+(e.description || e),'error');}
		
		$('history').setStyle('width', this.UI_MENU_WIDTH);
		
		$('historyHeader').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('historyHeader').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var h = $('round').getStyle('height').toInt() - this.UI_MENU_HEADER_HEIGHT + this.returnStyleNum($('history'),"margin-bottom");
			$('historyContent').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting historyContent height("+h+"): "+(e.description || e),'error');}
		
		$('historyContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    setResource: function(){ 	
		$('resource').setStyle('top', $('round').getStyle('top').toInt());
		try
		{
			var h = $('round').getStyle('height').toInt() + this.returnStyleNum($('resource'),"margin-bottom");
			$('resource').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting resource height("+h+"): "+(e.description || e),'error');}
		
		$('resource').setStyle('width', this.UI_MENU_WIDTH);
		
		$('resourceHeader').setStyle('height', this.UI_MENU_HEADER_HEIGHT);
		$('resourceHeader').setStyle('width', this.UI_MENU_WIDTH);

		try
		{
			var h = $('round').getStyle('height').toInt() - this.UI_MENU_HEADER_HEIGHT + this.returnStyleNum($('resource'),"margin-bottom");
			$('resourceContent').setStyle('height', h);
		}
		catch(e){Utils.debug.trace("Error in ui.updateLayout setting resourceContent height("+h+"): "+(e.description || e),'error');}
		
		$('resourceContent').setStyle('width', this.UI_MENU_WIDTH);
    },
    
    refreshTranscript: function(){
		this.refresh($('transcript'));
	},
    
    returnStyleNum: function (el, prop){
		var num = Utils.dom.getCurrentStyleAsNum(el, prop);
		if (num != null && num != "undefined" && (!isNaN(num))) {
			return num;
		} else {
			return 0;
		}
    }
});
*/
