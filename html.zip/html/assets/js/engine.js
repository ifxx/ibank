/** 
* Defines the main content engine object
* @class Engine
* @requires Controller
* @requires CommFactory
* @requires UIControl
* @requires Audio
* @requires Utils
* @constructor
*/
function Engine()
{
	//Engine members
	this.rootPath = Utils.window.getRootFolder();
	this.assessmentSummaryPath = this.rootPath + '/content/assessment_summary.htm';
	this.flashPluginVer = [Conf.FLASH_MAJOR_VERSION, Conf.FLASH_MINOR_VERSION, Conf.FLASH_REVISION].join(".");
	this.root = null;
	this.courseTitle = '';
	this.searchparams = null;
	this.hasAudio = false;
	this.hasFlashAudio = false;
	this.contentScroller = null;
	this.ready = false;
	this.clientWidth = 0;
	this.started = false;
	this.quit = false;
	this.bypassOnReadyChecks = false;
	this.previousZoomLevel;
	// Document Types
	this.TYPES = {
		COURSE:{value:5}
	};
	
	/**
	 * Initializes the engine
	 * @method initialize
	 */
	this.initialize = function()
	{
		Utils.debug.trace('[ Begin Engine Initialize ]');

		this.checkAccessibility();
		
		// Cache the search params
		this.searchparams = Utils.window.getSearchParams();

		//Components of the engine are created here
		this.comm = CommFactory(Conf.API_TYPE,Conf.CONTENT_ID);
		this.controller = new Controller(this);
		this.ui = new UIControl();
		this.audio = new AudioObject();
		this.dialog = new Dialog();
		
		// Build the course structure from within "conf/structure.js"
		initStructure();

		// Check for the existence of audio prior to initializing the audio object.
		// Check must be made after the structure has been initialized.
		this.hasAudio = this.controller.hasAudio();
		this.hasFlashAudio = this.controller.hasFlashAudio();

		/*
		Force to Flash if:
		 - The audio_type is not "FLASH" already
		 - Browser can possibly support Flash Player (This isn't an iOS device)
		 - The course has Flash-based audio
		*/
		if((Conf.AUDIO_TYPE.toLowerCase() != "flash") && !Utils.browserDetection.isMobile() && this.hasFlashAudio)
		{
			Conf.AUDIO_TYPE = "FLASH";
		}

		if(Utils.browserDetection.isMobile())
		{
			Conf.AUDIO_TYPE = "HTML5";
			if(this.hasFlashAudio)
			{
				Utils.flash.showWarningIOS();
			}
		}

		// Initialize the UI object before comm or controller classes
		this.ui.initialize();
		this.ui.sizeWindow();
		this.ui.updateLayout();

		// The content iFrame's onResize event relies on the UI object's members, so don't
		// create the listener until the UI object has been initialized
		this.createContentWindowListener();

		if(this.hasAudio)
		{
			Utils.debug.trace('Course has audio');

			// Initialize the audio object
			var audioInitialized = this.audio.initialize();

			// Something went wrong initializing the audio object, disable it completely
			if(!audioInitialized)
			{
				Conf.AUDIO_TYPE = null;
				this.audio.initialize();
			}
		}
		else
		{
			Utils.debug.trace('Course does not have audio');
			Conf.AUDIO_TYPE = null;
			this.audio.initialize();
		}

		// Initialize other classes...
		var commInitialized = this.comm.initialize();

		// Has the Comm object successfully initialized?
		if(commInitialized)
		{
			Utils.debug.trace('Comm object initialized.');
			this.started = true;
			engine.comm.setSimMode(this.TYPES.COURSE.value);
			if(this.comm.autoRun)
			{
				this.run();
			}
		}
		else
		{
			Utils.debug.trace('Comm Error: Cannot initialize Comm object','error');
			this.run();
		}

		if(!Utils.browserDetection.isMobile())
		{
			if(document.body.getBoundingClientRect)
			{
				var rect = document.body.getBoundingClientRect();
				var clientWidth = rect.right - rect.left;
				engine.previousZoomLevel = clientWidth;
			}
			this.checkForZoom();
		}

		Utils.debug.trace('[ End Engine Initialize ]');
	};

	/**
	 * Attempts to call the onReady in the case of no audio
	 * @method run
	 */
	this.run = function()
	{
		Utils.debug.trace('[ Running Engine... ]');

		if(!this.hasAudio || Conf.AUDIO_TYPE == null)
		{
			this.onReady();
		}
		else
		{
			if(Conf.AUDIO_TYPE == 'HTML5')
			{
				this.onReady();
			}
			else
			{
				if(document.location.protocol.indexOf('file') > -1)
				{
					var func=function()
					{
						engine.handleFlashSecurityTimeout();
					};
					setTimeout(function(){func();},3000);
				}
			}
		}
	};

	/**
	 * Fired by the "run" method or from the Audio object's onReady event,
	 * depending on whether or not the course has audio
	 * @method onReady
	 */
	this.onReady = function()
	{
		if (!this.bypassOnReadyChecks)
		{
			if(this.ready || !this.comm.ready || !this.audio.ready){return;}
		}
		this.ready = true;
		Utils.debug.trace('Engine is ready...');
		this.controller.initialize();
		window.focus(document);
		EventHandler.createKeyListeners();
	};

	this.handleFlashSecurityTimeout = function()
	{
		if(this.ready){return;}
		this.bypassOnReadyChecks = true;
		Utils.debug.trace('The 3 second timeout threshold has been reached waiting for Flash to respond. Please check Flash Player Global Security Settings','error');
		this.onReady();
	};
	
	/**
	 * Attaches an onload event handler to the content iframe
	 * @method createContentWindowListener
	 */
	this.createContentWindowListener = function()
	{
		if(window.addEventListener)
		{
		    this.ui.content.onload = this.contentLoaded;
		    this.ui.nextContent.onload = this.contentLoaded;
		    this.ui.backContent.onload = this.contentLoaded;
		    this.ui.choice1Content.onload = this.contentLoaded;
		    this.ui.choice2Content.onload = this.contentLoaded;
		    this.ui.choice3Content.onload = this.contentLoaded;
		    this.ui.choice4Content.onload = this.contentLoaded;

			this.ui.content.onfocus = function()
			{
				engine.ui.contentFocused = true;
			};
			this.ui.content.onblur = function()
			{
				engine.ui.contentFocused = false;
			};

			this.ui.nextContent.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.nextContent.onblur = function () {
			    engine.ui.contentFocused = false;
			};

			this.ui.backContent.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.backContent.onblur = function () {
			    engine.ui.contentFocused = false;
			};
            //
			this.ui.choice1Content.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.choice1Content.onblur = function () {
			    engine.ui.contentFocused = false;
			};
			this.ui.choice2Content.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.choice2Content.onblur = function () {
			    engine.ui.contentFocused = false;
			};
			this.ui.choice3Content.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.choice3Content.onblur = function () {
			    engine.ui.contentFocused = false;
			};
			this.ui.choice4Content.onfocus = function () {
			    engine.ui.contentFocused = true;
			};
			this.ui.choice4Content.onblur = function () {
			    engine.ui.contentFocused = false;
			};
		}
		else if(this.ui.content.attachEvent)
		{
		    this.ui.content.attachEvent("onload", this.contentLoaded);
		    this.ui.nextContent.attachEvent("onload", this.contentLoaded);
		    this.ui.backContent.attachEvent("onload", this.contentLoaded);
		    this.ui.choice1Content.attachEvent("onload", this.contentLoaded);
		    this.ui.choice2Content.attachEvent("onload", this.contentLoaded);
		    this.ui.choice3Content.attachEvent("onload", this.contentLoaded);
		    this.ui.choice4Content.attachEvent("onload", this.contentLoaded);
		}
	};
	
	/**
	 * Fires when the content frame has finished loading a content page
	 * @method contentLoaded
	 */
	this.contentLoaded = function()
	{
		// Use direct reference to "engine" instead of "this", due to loss of context in event listener
		engine.controller.checkNavState();
		engine.controller.loadAudio();
		engine.ui.contentLoaded();
		Utils.debug.trace('Content loaded');
	};
	
	/**
	 * Replaces the content iframe source with a new page
	 * @method setContentSrc
	 * @param {String} pageURL The page to be loaded into the content iframe
	 */
	this.setContentSrc = function(pageURL)
	{
	    this.ui.content.contentWindow.window.name = 'content';
		this.ui.content.contentWindow.location.replace(pageURL);
	};
	
    /**
	 * Set iframe source with a next page to run background
	 * @method setNextPageSrc
	 * @param {String} pageURL The page to be loaded into the content iframe
	 */
	this.setNextPageSrc = function (pageURL) {
	    this.ui.nextContent.contentWindow.window.name = 'nextContent';
	    this.ui.nextContent.contentWindow.location.replace(pageURL);
	}

    /**
	 * Set iframe source with a back page to run background
	 * @method setBackPageSrc
	 * @param {String} pageURL The page to be loaded into the content iframe
	 */
	this.setBackPageSrc = function (pageURL) {
	    this.ui.backContent.contentWindow.window.name = 'backContent';
	    this.ui.backContent.contentWindow.location.replace(pageURL);
	}

    /**
    * Set iframe source with a choice page to run background
    * @method setChoicePageSrc
    * @param {String} pageURL The page to be loaded into the content iframe
    */
	this.setChoicePageSrc = function (pageURL, index) {
	    if (index == 0) {
	        this.ui.choice1Content.contentWindow.window.name = 'choice1Content';
	        this.ui.choice1Content.contentWindow.location.replace(pageURL + '?choiceContent=true');
	    }
	    else if (index == 1) {
	        this.ui.choice2Content.contentWindow.window.name = 'choice2Content';
	        this.ui.choice2Content.contentWindow.location.replace(pageURL + '?choiceContent=true');
	    }
	    else if (index == 2) {
	        this.ui.choice3Content.contentWindow.window.name = 'choice3Content';
	        this.ui.choice3Content.contentWindow.location.replace(pageURL + '?choiceContent=true');
	    }
	    else if (index == 3) {
	        this.ui.choice4Content.contentWindow.window.name = 'choice4Content';
	        this.ui.choice4Content.contentWindow.location.replace(pageURL + '?choiceContent=true');
	    }
	}

    /**
    * Reset next content from choice
    * @method gotoNextPageFromChoice
    * @param {int} indexChoice
    */
	this.gotoNextPageFromChoice = function (indexChoice) {
	    var tempFrame = null;
	    if (indexChoice == 0) {
	        this.ui.choice1Content.name = "nextContent1";// avoid duplicate
	        this.ui.choice1Content.id = "nextContent1";
	        this.ui.nextContent.name = "choice1Content";
	        this.ui.nextContent.id = "choice1Content";
	        this.ui.choice1Content.name = "nextContent";
	        this.ui.choice1Content.id = "nextContent";
	        tempFrame = this.ui.choice1Content;
	        this.ui.choice1Content = this.ui.nextContent;
	        this.ui.nextContent = tempFrame;
	        this.ui.nextContent.style.visibility = 'hidden';
	        this.ui.nextContent.style.display = '';
	        this.ui.choice1Content.style.display = 'none'
	        this.ui.choice1Content.contentWindow.window.name = 'choice1Content';
	    }
	    else if (indexChoice == 1) {
	        this.ui.choice2Content.name = "nextContent1";
	        this.ui.choice2Content.id = "nextContent1";
	        this.ui.nextContent.name = "choice2Content";
	        this.ui.nextContent.id = "choice2Content";
	        this.ui.choice2Content.name = "nextContent";
	        this.ui.choice2Content.id = "nextContent";
	        tempFrame = this.ui.choice2Content;
	        this.ui.choice2Content = this.ui.nextContent;
	        this.ui.nextContent = tempFrame;
	        this.ui.nextContent.style.visibility = 'hidden';
	        this.ui.nextContent.style.display = '';
	        this.ui.choice2Content.style.display = 'none'
	        this.ui.choice2Content.contentWindow.window.name = 'choice2Content';
	    }
	    else if (indexChoice == 2) {
	        this.ui.choice3Content.name = "nextContent1";
	        this.ui.choice3Content.id = "nextContent1";
	        this.ui.nextContent.name = "choice3Content";
	        this.ui.nextContent.id = "choice3Content";
	        this.ui.choice3Content.name = "nextContent";
	        this.ui.choice3Content.id = "nextContent";
	        tempFrame = this.ui.choice3Content;
	        this.ui.choice3Content = this.ui.nextContent;
	        this.ui.nextContent = tempFrame;
	        this.ui.nextContent.style.visibility = 'hidden';
	        this.ui.nextContent.style.display = '';
	        this.ui.choice3Content.style.display = 'none'
	        this.ui.choice3Content.contentWindow.window.name = 'choice3Content';
	    }
	    else if (indexChoice == 3) {
	        this.ui.choice4Content.name = "nextContent1";
	        this.ui.choice4Content.id = "nextContent1";
	        this.ui.nextContent.name = "choice4Content";
	        this.ui.nextContent.id = "choice4Content";
	        this.ui.choice4Content.name = "nextContent";
	        this.ui.choice4Content.id = "nextContent";
	        tempFrame = this.ui.choice4Content;
	        this.ui.choice4Content = this.ui.nextContent;
	        this.ui.nextContent = tempFrame;
	        this.ui.nextContent.style.visibility = 'hidden';
	        this.ui.nextContent.style.display = '';
	        this.ui.choice4Content.style.display = 'none'
	        this.ui.choice4Content.contentWindow.window.name = 'choice4Content';
	    }
	    this.ui.nextContent.contentWindow.window.name = 'nextContent';
	    try {
	        var currentPage = this.ui.nextContent.contentWindow.getCurrentPage();
	        var assess = null;
	        if (currentPage && (assess = currentPage.assessment)) {
	            assess.init(this.ui.nextContent.contentWindow.window, this.ui.nextContent.contentWindow.document);
	        }
	    }
	    catch (e) { }
	    tempFrame = null;
	};

    /**
	 * switch view content between two iframes current page and next page
	 * @method gotoNextPage
	 */
	this.gotoNextPage = function () {
	    var tempFrame = null;
	    var currentPage = this.ui.nextContent.contentWindow.getCurrentPage();
	    var branch = currentPage.branch;
	    if (branch) {
	        branch.setPreloadChoices();
	    }
	    this.ui.nextContent.style.left = this.ui.content.style.left;
	    this.ui.nextContent.style.top = this.ui.content.style.top;
	    this.ui.nextContent.style.width = this.ui.content.style.width;
	    this.ui.nextContent.style.height = this.ui.content.style.height;
	    this.ui.content.name = "nextContent1";
	    this.ui.content.id = "nextContent1";
	    this.ui.nextContent.name = "content";
	    this.ui.nextContent.id = "content";
	    this.ui.content.style.visibility = "hidden";
		this.ui.content.style.height = 0;
	    this.ui.nextContent.style.visibility = "visible";
	    this.ui.content.name = "nextContent";
	    this.ui.content.id = "nextContent";

	    tempFrame = this.ui.content;
	    this.ui.content = this.ui.nextContent;
	    this.ui.nextContent = tempFrame;
	    this.ui.content.contentWindow.window.name = 'content';
	    this.ui.nextContent.contentWindow.window.name = 'nextContent';
	    tempFrame = null;
		var waitingLoadImage = this.ui.content.contentWindow.document.getElementById("waitingLoadImage");
		// Generate content of branch and assessment
		if(waitingLoadImage == null || typeof waitingLoadImage == "undefined")
		{
		    try {
		        this.ui.content.contentWindow.playTransition();
			}
			catch (e) { }
		}
	};

    /**
	 * switch view content between two iframes current page and back page
	 * @method gotoNextPage
	 */
	this.gotoBackPage = function () {
	    var tempFrame = null;
	    var currentPage = this.ui.backContent.contentWindow.getCurrentPage();
	    var branch = currentPage.branch;
	    if (branch) {
	        branch.setPreloadChoices();
	    }
	    this.ui.backContent.style.left = this.ui.content.style.left;
	    this.ui.backContent.style.top = this.ui.content.style.top;
	    this.ui.backContent.style.width = this.ui.content.style.width;
	    this.ui.backContent.style.height = this.ui.content.style.height;
	    this.ui.content.name = "backContent1";
	    this.ui.content.id = "backContent1";
	    this.ui.backContent.name = "content";
	    this.ui.backContent.id = "content";
	    this.ui.content.style.visibility = "hidden";
		this.ui.content.style.height = 0;
	    this.ui.backContent.style.visibility = "visible";
	    this.ui.content.name = "backContent";
	    this.ui.content.id = "backContent";

	    tempFrame = this.ui.content;
	    this.ui.content = this.ui.backContent;
	    this.ui.backContent = tempFrame;
	    this.ui.content.contentWindow.window.name = 'content';
	    this.ui.backContent.contentWindow.window.name = 'backContent';
	    tempFrame = null;
		
		var waitingLoadImage = this.ui.content.contentWindow.document.getElementById("waitingLoadImage");
		// Generate content of branch and assessment
		if(waitingLoadImage == null || typeof waitingLoadImage == "undefined")
		{
		    try {
		        this.ui.content.contentWindow.playTransition();
			}
			catch (e) { }
		}
	};

	this.getBrowserName = function()
	{
	    var nAgt = navigator.userAgent;
	    var browserName = navigator.appName;
	    if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
	        browserName = "Microsoft Internet Explorer";
	    }
	        // In Chrome, the true version is after "Chrome" 
	    else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
	        browserName = "Chrome";
	    }
	        // In Safari, the true version is after "Safari" or after "Version" 
	    else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
	        browserName = "Safari";
	    }
	        // In Firefox, the true version is after "Firefox" 
	    else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
	        browserName = "Firefox";
	    }

	    return browserName;
	}

	/**
	 * Displays a dialog asking whether or not to exit the lesson
	 * @method displayExitPrompt
	 */
	this.displayExitPrompt = function()
	{
		if(confirm(unescape(Lang.EXIT_CONFIRMATION)))
		{
			this.quit = true;
			if(Conf.CLOSE_ON_TERMINATE)
			{
				if (!this.started){
					return window.top.close();
				} else {
					try {
						if (this.started){
							this.comm.commit();
						
							var func = function() {
								return window.top.close();
							};
							setTimeout(func,1500);
						}
					} catch (e){}
				}
			}
			else
			{
				this.terminate();
			}
		}
	};
	
	/**
	 * Terminates the engine
	 * @method terminate
	 */
	this.terminate = function()
	{
		Utils.debug.terminate();
		if (this.started){
			this.comm.terminate();
		}
	};
	
	/**
	 * Handles the resize event and updates the layout
	 * @method handleResize
	 */
	this.handleResize = function()
	{
		this.ui.handleResize();
	};
	
	/**
	 * Opens the Help window
	 * @method openHelp
	 */
	this.openHelp = function()
	{
		Utils.window.open(Conf.HELP_URL,'help',800,600,'resizable,scrollbars');
	};
	
	/**
	 * Opens the Resources window
	 * @method openResources
	 */
	this.openResources = function()
	{
		if (Conf.RESOURCES_PANEL_ENABLED){
			engine.ui.toggleResource();
		} else {
		Utils.window.open(Conf.RESOURCES_URL,'resources',800,600,'resizable,scrollbars');
		}
	};
	
	/**
	 * Opens the Glossary window
	 * @method openGlossary
	 */
	this.openGlossary = function()
	{
		Utils.window.open(Conf.GLOSSARY_URL);
	};

	this.checkForZoom = function()
	{
		if(document.body.getBoundingClientRect)
		{
			var rect = document.body.getBoundingClientRect();
			var clientWidth = rect.right - rect.left;
		}
		else
		{
			return;
		}

		var func=function()
		{
			if(engine.zoomLevel != clientWidth)
			{
				engine.zoomLevel = clientWidth;
				Utils.debug.trace('clientWidth changed ('+clientWidth+') - handling resize...');
				if (engine.previousZoomLevel != engine.zoomLevel){
					if(Utils.browserDetection.browser == "ie" && Utils.browserDetection.version == 9){
						var diff = engine.previousZoomLevel - engine.zoomLevel;
						var offset = document.body.offsetWidth;
						var newwidth = offset - diff;
						document.getElementById("container").style.cssText = 'width:'+ newwidth + 'px !important';
					}
				}
				engine.handleResize();
				if (engine.previousZoomLevel != engine.zoomLevel){
					//set new value
					engine.previousZoomLevel = engine.zoomLevel;
				}
			}
		}();

		setTimeout(function(){engine.checkForZoom();},1000);
	};

	this.onOrientationChange = function()
	{
		switch(window.orientation)
	    {
	    	case 0: // "right-side-up" portrait
	    		Utils.debug.trace("Orientation changed: right-side-up portrait");
	    		break;

	    	case 90: // "right-handed" landscape
	    		Utils.debug.trace("Orientation changed: right-handed landscape");
	    		break;

	    	case 180: // "upside-down" portrait
	    		Utils.debug.trace("Orientation changed: upside-down portrait");
	    		break;

	    	case -90: // "left-handed" landscape
	    		Utils.debug.trace("Orientation changed: left-handed landscape");
	    		break;
	    }
	    this.ui.updateLayout();
	};

	this.checkAccessibility = function()
	{
		var hasRequiredFlashVer = Utils.flash.hasRequiredVer();

		if(hasRequiredFlashVer)
		{
			var flashvars = {};
			var params = {
				menu: "false",
				swliveconnect: "true",
				allowScriptAccess: "always"
			};
			var attributes = {
				id: "flashAccessibilityCheckObj",
				name: "flashAccessibilityCheckObj",
                style:"left: -1px; position: absolute;",
				tabindex: -1
			};
			
			swfobject.embedSWF("assets/swf/accessibility-check.swf", "accessibilityCheckContainer", "1", "1",  engine.flashPluginVer, "assets/swf/expressinstall.swf", flashvars, params, attributes);
			Utils.debug.trace('Accessibility Checker created');
			var obj = Utils.dom.getFlashObject("flashAccessibilityCheckObj");
			if(obj)
			{
				obj.focus();
			}
		}
		else
		{
			Utils.debug.trace('Accessibility Checker not created - Flash not installed.');
		}
	};

	this.toString = function()
	{
		return 'Engine instance';
	};
}
