/**
* Creates a new instance of an Branch object
* @classDescription This class defines branching pages and their behavior
* @param {Object} o	A param that specifies the Branch class configuration (adopted from parent page)
* @requires Engine
* @requires Utils
* @constructor
*/
function Branch(parentPageObj, o)
{
	// Loop over the params in object "o" and add them to this object  
	for (var prop in o)
	{
		this[prop] = o[prop];
	}
	
	this.branchChoices = [];
	this.parentPageObj = parentPageObj;
	this.selectedBranchChoice = null;
	this.nextPageName = null;
	
	this.addBranchChoice = function(branchChoicePageObj)
	{
		this.branchChoices.push(branchChoicePageObj);
	};
	
	this.init = function (contentFrame, contentDoc)
	{
		this.selectedBranchChoice = null;

		// Set references to the content frame's DOM elements
		this.contentFrame = contentFrame;
		this.contentDoc = contentDoc;
		
		// Set references to the branching button elemens within the branch.htm stencil
		this.btnContinue = $CONTENT("btnContinue", contentDoc);
		this.btnContinue.value = unescape(Lang.UI_LABEL_CONTINUE);
		
		// Set default functionality of the branching buttons 
		var self = this;
		this.btnContinue.onclick = function()
		{
			self.check();
		};

		var c = engine.controller;
		var contentPage = this.getContentPage();
		// If the current page has a "next" property set, and it is the name of a valid page, use it
		if (contentPage.next && c.getPageByName(contentPage.next) && !(this.isLinear))
		{
		    this.nextPageName = contentPage.next;
		}
		else
		{
			this.btnContinue.disabled = true;
		}
		
		Utils.dom.renderHTML("directions", unescape(this.directions), this.contentDoc);
		
		this.renderBranchChoices();
	};
	
	this.getContentPage = function () {
	    if (engine) {
	        var indexOf = this.contentFrame.location.href.lastIndexOf('page_');
	        if (indexOf > 0) {
	            var pageName = this.contentFrame.location.href.substring(indexOf, this.contentFrame.location.href.length - 4);
	            var pageObj = engine.controller.getPageByName(pageName);
	            return pageObj;
	        }
	    }
	};

	this.renderBranchChoices = function()
	{
		var html=''

		html+='<div class="question">\n';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';
	
		for(var i=0;i<this.branchChoices.length; i++)
		{
			html+='<div class="choice">\n';
			html+='	<table class="choiceTable"><tr>';
			html+='		<td><input type="radio" name="'+this.name+'" id="'+this.name+i+'" value="'+i+'" onclick="engine.controller.currentPageObj.branch.enableContinueBtn();"';
			//perform Default Choice check: default choice should appear selected
			if(this.nextPageName == this.branchChoices[i])
			{
				html+='CHECKED';	
			}
			html+='></td>\n';

			html+='		<td><label for="'+this.name+i+'">'+this.branchChoices[i].title+'</label></td>\n';
			html+='	</tr></table>';
			html += '</div>\n';
		}
	
		html+='</div>';
	
		Utils.dom.renderHTML('branchFormContent',html,this.contentDoc);
	};
	
	this.setPreloadChoices = function()
	{
	    for (var i = 0; i < this.branchChoices.length; i++) {
	        try {
	            engine.controller.setChoicePage(this.branchChoices[i].name, i);
	        }
	        catch (e) { }
	    }
	};

	this.check = function()
	{
	    var contentDoc = (content.contentDocument || $("content").contentWindow.document);
		var radioObj = contentDoc.forms['contentForm'][this.name];
		
		if(!radioObj || Conf.PREVIEW_MODE)
		{
			return "";
		}
		
		var radioLength = radioObj.length;
	    
		for(var i = 0; i < radioLength; i++)
		{
			if(radioObj[i].checked)
			{
			    this.selectedBranchChoice = this.branchChoices[i];
                //set preload for next page
			    engine.gotoNextPageFromChoice(i);
			    break;
			}
		}
		
		if(this.selectedBranchChoice)
		{
			Utils.debug.trace("Branch - Selected BranchChoice: "+this.selectedBranchChoice.title);
			this.goToBranchChoiceByName(this.selectedBranchChoice);
		}
		else
		{
			if(this.nextPageName)
			{
				Utils.debug.trace("Branch - BranchChoice not selected, moving to next linear page: "+this.nextPageName);
				var c = engine.controller;
				c.gotoPageByName(this.nextPageName);
			}
		}
	};
	
	this.goToBranchChoiceByName = function(choicePage)
	{
	    var nextPageName = engine.controller.getNextPageNameFromBranchChoice(choicePage);
	    var nextPage = engine.controller.getPageByName(nextPageName);
	    if (nextPage) {
	        engine.controller.playExitTransitionAndGoToPageByName(nextPage.transitionOut, nextPage.name, nextPage.duration);
	    }
	    else {
	        engine.controller.gotoPageByName(choicePage.name);
	    }
	};

	this.enableContinueBtn = function()
	{
		this.btnContinue.disabled = false;
	};
}

