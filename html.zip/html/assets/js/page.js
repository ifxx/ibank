/**
* Class defining the page handling and menu entry display used by the engine
* @param {Object} o A param that specifies the Page class configuration
* @requires Engine
* @constructor

Some Menu Icons (Fugue Icons):
Copyright (C) 2010 Yusuke Kamiyamane. All rights reserved.
The icons are licensed under a Creative Commons Attribution
3.0 license. <http://creativecommons.org/licenses/by/3.0/>

*/
function Page(o)
{
	for (var prop in o)
	{
		this[prop] = o[prop];
	}
	
	this.parent = null;
	this.open = false;
	this.visited = false;
	this.here = false;
	this.pageList = [];
    this.animationList = [];
	this.passed = false;
	this.failed = false;
	this.menuItemHeight = 20;
	this.stem = null;
	this.childIndex = 0;
	this.visibleIndex = 0;
	
	this.title = unescape(this.title);
	this.transcript = unescape(this.transcript);
	
	if (this.isAssessment)
	{
		this.assessment = new Assessment(this, o);
	}
	else if (this.isBranch)
	{
		this.branch = new Branch(this, o);
	}
	
	this.index = engine.controller.pageList.length;
	engine.controller.pageList.push(this);
    
    var animationStringList = this.animations.split("][");
    for(var i = 0; i < animationStringList.length; i ++)
    {
        var animationString = animationStringList[i];
        if(i == 0)
        {
            animationString = animationString.substring(1, animationString.length);
        }
        else if(i == animationStringList.length - 1)
        {
            animationString = animationString.substring(0, animationString.length - 1);
        }
        
        var properties = animationString.split(";");
        if(properties.length == 5){
            this.animationList.push({eleId:properties[0], trigger:properties[1], styles:properties[2], duration:properties[3], delay:properties[4]});
        }
    }
	
	/**
	 * Add a page to another page as its child
	 * @param {String} pageObj A Page object to be added to this page
	 * @method addPage
	 */
	this.addPage = function(pageObj)
	{
		if(pageObj.isBranchChoice && this.isBranch)
		{
			this.branch.addBranchChoice(pageObj);
		}
		pageObj.childIndex = this.pageList.length;
		this.pageList.push(pageObj);
		pageObj.parent = this;
	};
	
	/**
	 * Set this as the current page being loaded into the engine
	 * @method setAsCurrentPage
	 */
	this.setAsCurrentPage = function()
	{
		this.visited = true;
		this.here = true;
		this.openPage();
		this.openParentFolders();
	};
	
	/**
	 * Get path to the HTML page to load
	 * @method getPageURL
	 * @return {String} Returns a string containing the path to the page to load
	 */
	this.getPageURL = function()
	{
		var pageURL;
		
		pageURL = engine.rootPath + '/content/' + this.name + '.htm';
		
		return pageURL;
	};
	
	/**
	 * Get the HTML for this page's menu branch
	 * @method getMenuHTML
	 * @return {String} Returns a string containing the HTML for this page's menu branch
	 */
	this.getMenuHTML = function()
	{
		var PageHTML;
		var plusMinusVal="";
		var statusVal="";
		var branchImgVal="";
		
		var spacerVal="";
		
		if (this.parent)
		{
			spacerVal = this.getSpacerVal();
		}
		
		if (this.parent)
		{
			if (this.isLastSibling() || (this.isBranchChoice && !this.parent.branchHasTrailingPages()))
			{
				branchImgVal = '<div id="singleBranchImage"></div>';
			}
			else
			{
				branchImgVal = '<div id="extendBranchImage"></div>';
			}
		}
		else
		{
			branchImgVal = '';
		}
		
		// Plus/Minus Button
		if(!this.parent)
		{
			plusMinusVal += '<div id="courseImage"></div>';
		}
		else if(this.isFolder() && !this.isAssessment && !this.isBranch && !this.isBranchChoice)
		{
			if (this.open)
			{
				plusMinusVal = '<a href="#" tabindex="-1" onClick="' + this.name + '.closePage(true);return false;">';
				plusMinusVal += '<div id="menuMinusImage"></div>';
				plusMinusVal += '</a>';
			}
			else
			{
				plusMinusVal = '<a href="#" tabindex="-1" onClick="' + this.name + '.openPage(true);return false;">';
				plusMinusVal += '<div id="menuPlusImage"></div>';
				plusMinusVal += '</a>';
			}
		}
		else if (this.isAssessment && !this.isPostAssessment)
		{
			if (this.passed)
			{
				plusMinusVal = '<div id="assessmentPassedImage"></div>';
			}
			else
			{
				plusMinusVal = '<div id="menuAssessmentImage"></div>';
			}
		}
		else if (this.isAssessment && this.isPostAssessment)
		{
			if (this.passed)
			{
				plusMinusVal = '<div id="postAssessmentPassedImage"></div>';
			}
			else
			{
				plusMinusVal = '<div id="postAssessmentImage"></div>';
			}
		}
		else if (this.isBranch)
		{
			plusMinusVal = '<div id="menuBranchImage"></div>';
		}
		else if (this.isBranchChoice)
		{
			plusMinusVal = '<div id="menuBranchChoiceImage"></div>';
		}
		else
		{
			plusMinusVal = '<div id="menuPageImage"></div>';
		}
		
		// Status Icon
		if (this.visited)
		{
			statusVal = '<div id="menuVisitedImage"></div>';
		}
		else
		{
			statusVal = '<div id="menuSpacerImage"></div>';
		}
		
		if (this.here)
		{
			statusVal = '<div id="menuHereImage"></div>';
		}
		
		//Status Style
		if (this.here)
		{
			statusSpan = '<span class="menuHere">';
		}
		else
		{
			if (this.isFolder())
			{
				statusSpan = '<span class="menuFolder">';
			}
			else
			{
				statusSpan = '<span class="menuPage">';
			}
		}
		
		// Basic folder-level checks
		if(this.isFolder())
		{
			if(this.open)
			{
				var title = Lang.ACCESSIBILITY_OPEN + ' ' + Lang.ACCESSIBILITY_MENU_ITEM +': '+ this.title;
				var aExpanded = 'aria-expanded="true"';
			}
			else
			{
				var title = Lang.ACCESSIBILITY_CLOSED + ' ' + Lang.ACCESSIBILITY_MENU_ITEM +': '+ this.title;
				var aExpanded = 'aria-expanded="false"';
			}
		}
		else
		{
			var title = Lang.ACCESSIBILITY_MENU_ITEM +': '+ this.title;
			var aExpanded = '';
		}
		
		PageHTML = '<li id="' + this.name + '_li" class="menuEntry" tabindex="0" pageName="' +this.name + '" onFocus="engine.ui.setMenuFocused(true,this);" onBlur="engine.ui.setMenuFocused(false,null);" aria-level="'+this.getPageDepth()+'" role="treeitem" title="' + title + '" '+aExpanded+'>';
		
		if(!this.isBranchChoice && (Conf.LOCKSTEP_MENU_NAVIGATION && (this.visited || this.here) || !Conf.LOCKSTEP_MENU_NAVIGATION))
		{
			/*
			if(Conf.RTLSupport)
			{
				PageHTML += spacerVal + branchImgVal + '<a href="#" tabindex="-1" onClick="engine.controller.gotoPageByName(\'' + this.name + '\');return false;">'+ statusSpan + this.title + '</span></a>'  + statusVal + plusMinusVal;
			}
			else
			{*/
				PageHTML += spacerVal + branchImgVal + plusMinusVal + statusVal;
				PageHTML += '<a href="#" tabindex="-1" onClick="engine.controller.gotoPage(\'' + this.name + '\');return false;">';
				PageHTML += statusSpan + this.title + '</span></a>';
			//}
		}
		else 
		{
			PageHTML += spacerVal + branchImgVal + plusMinusVal + statusVal + statusSpan + this.title + '</span>';
		}
		PageHTML += '</li>';
		
		engine.ui.pageCount++;
		
		return PageHTML;
	};
	
	/**
	 * Get the HTML for this page's history menu branch
	 * @method getHistoryHTML
	 * @return {String} Returns a string containing the HTML for this page's history menu branch
	 */
	this.getHistoryHTML = function(historyIndex)
	{
		var PageHTML;
		var statusSpan = '';
		
		PageHTML = '<li id="' + this.name + '_history_li_'+historyIndex+'" class="menuEntry" tabindex="0" onFocus="engine.ui.setMenuFocused(true,this);" onBlur="engine.ui.setMenuFocused(false,null);" pageName="'+this.name+'" historyIndex="'+historyIndex+'" title="' + this.title + '">';
		PageHTML += '<div id="menuPageImage"></div>';
		PageHTML += '<a href="#" tabindex="-1" onClick="engine.controller.gotoPageByNameFromHistory(\'' + this.name + '\',' + historyIndex + ');return false;">';
		/*if (Conf.RTLSupport)
		{
		PageHTML += '<span class="menuPage">'+ this.title +'</span> <span dir="ltr" class="menuPage">'+ (this.index + 1) + '.</span> '
		}
		else
		{*/
		PageHTML += '<span class="menuPage">' + (this.index + 1) + '. ' + this.title + '</span>'
		//}
		
		
		
		PageHTML += '</a></li>';
		 
		return PageHTML;
	};
	
	/**
	 * Get the HTML for the entire menu - should start from root course page
	 * @method cascadePage
	 * @return {String} Returns a string containing the HTML for the entire menu
	 */
	this.cascadePage = function()
	{
		var menuHTML;
		var currentPageObj = engine.controller.currentPageObj;
		
		menuHTML = this.getMenuHTML();
		
		if(this.open)
		{
			if(this.isNormalFolder()) 
			{
				menuHTML += '<ul role="group">';
				for(var i=0;i<this.pageList.length;i++)
				{
					menuHTML += this.pageList[i].cascadePage()
				}
				menuHTML += '</ul>';
			}
			else if(this.isBranch)
			{
				menuHTML += '<ul role="group">';
				for (var i = 0; i < this.pageList.length; i++)
				{
					if(!this.pageList[i].isBranchChoice || 
					  (this.pageList[i] == currentPageObj) || 
					  (this.pageList[i].isBranchChoice && currentPageObj.isADescendantOf(this.pageList[i])) ||
					  (this.pageList[i].isBranchChoice && (this.pageList[i] == this.branch.selectedBranchChoice)))
					{
						menuHTML += this.pageList[i].cascadePage();
					}
				}
				menuHTML += '</ul>';
			}
		}
		
		return menuHTML;
	};
	
	/**
	 * Get the depth of the page for menu indentation through recursion
	 * @method getPageDepth
	 * @return {Integer} Returns an integer equal to the depth of the page
	 */
	this.getPageDepth = function()
	{
		if (this == engine.root) 
		{
			return 0;
		}
		else 
		{
			return this.parent.getPageDepth() + 1;
		}
	};
	
	/**
	 * Get the HTML for the indentation images
	 * @method getSpacerVal
	 * @return {String} Returns a string containing the HTML for the page's indentation images
	 */
	this.getSpacerVal = function()
	{
		var spacerHTML = "";
		
		if (this.parent) 
		{
			if (this.parent.isLastSibling() || this.parent == engine.root || (this.parent.isBranchChoice && !this.parent.parent.branchHasTrailingPages()))
			{
				if (this.parent != engine.root) 
				{
					spacerHTML = '<div id="menuSpacerImage" class="menuSpacing"></div>' + spacerHTML;
				}
			}
			else 
			{
				spacerHTML = '<div id="branchConnectorImage"></div>' + spacerHTML;
			}
			spacerHTML = this.parent.getSpacerVal() + spacerHTML;
		}
		else 
		{
			spacerHTML = "";
		}
		
		return spacerHTML;
	};
	
	/**
	 * Returns whether or not this page (a branch) has pages existing after all branch choices
	 * @method branchHasTrailingPages
	 * @return {Boolean} Whether or not this page (a branch) has trailing pages
	 */
	this.branchHasTrailingPages = function()
	{
		if(!this.isBranch){return;}
		
		for(var i=0;i<this.pageList.length;i++)
		{
			if(!this.pageList[i].isBranchChoice)
			{
				return true;
			}
		}
		
		return false;
	};
	
	/**
	 * Is this page a folder?
	 * @method isFolder
	 * @return {Boolean} Whether or not this page is a folder (has children)
	 */
	this.isFolder = function()
	{
		var isFolderVal = (this.pageList.length > 0);
		return isFolderVal;
	};
	
	/**
	 * Is this page a "normal", non-branching-related folder?
	 * @method isNormalFolder
	 * @return {Boolean} Returns whether or not this page is a folder (has children) not related to branching
	 */
	this.isNormalFolder = function()
	{
		var isFolderVal = ((this.pageList.length > 0) && !this.isBranch);
		return isFolderVal;
	};
	
	/**
	 * Close this page, if it is a folder - used in the menu
	 * @method closePage
	 * @param {Boolean} refresh	Whether or not the menu re-render itself
	 */
	this.closePage = function(refresh)
	{
		this.open = false;
		if (refresh) 
		{
			engine.ui.renderMenu();
		}
	};
	
	/**
	 * Open this page, if it is a folder - used in the menu
	 * @method openPage
	 * @param {Boolean} refresh	Whether or not the menu re-render itself
	 */
	this.openPage = function(refresh)
	{
		this.open = true;
		if (refresh) 
		{
			engine.ui.renderMenu();
		}
	};
	
	/**
	 * Open all parents and ancestors through recursion
	 * @method openParentFolders
	 */
	this.openParentFolders = function()
	{
		this.open = true;
		if (this.parent) 
		{
			this.parent.openParentFolders();
		}
	};
	
	/**
	 * Open all children and descendants through recursion
	 * @method openChildFolders
	 */
	this.openChildFolders = function()
	{
		for(var i=0;i<this.pageList.length;i++)
		{
			this.pageList[i].open = true;
			if (this.isFolder())
			{
				this.pageList[i].openChildFolders();
			}
		}
	};
	
	/**
	 * Close all children and descendants through recursion
	 * @method closeChildFolders
	 */
	this.closeChildFolders = function()
	{
		for(var i=0;i<this.pageList.length;i++)
		{
			this.pageList[i].open = false;
			if (this.isFolder())
			{
				this.pageList[i].closeChildFolders();
			}
		}
	};
	
	/**
	 * Get the location path (breadcrumb trail)
	 * @method getLocationPath
	 * @return {String} A string containing this page title and parent's title
	 */
	this.getLocationPath = function()
	{
		var locationPath = "";
		
		locationPath += this.title
		
		return this.parent.getLocationPath();
	};
	
	/**
	 * Is this the last sibling?
	 * @method isLastSibling
	 * @return {Boolean} Whether or not this is the last sibling in its parent's page list
	 */
	this.isLastSibling = function()
	{
		var isLastSiblingVal = false;
		
		if (this.parent) 
		{
			if (this == this.parent.pageList[this.parent.pageList.length - 1])
			{
				isLastSiblingVal = true;
			}
		}
		return isLastSiblingVal;
	};
	
	this.isADescendantOf = function(parent)
	{
		if(this.parent == parent)
		{
			return true;
		}
		else
		{
			if(this.parent)
			{
				return this.parent.isADescendantOf(parent);
			}
		}
	};
	
	this.isLastPageInBranch = function()
	{
		// Is this page even inside a branch?
		if(this.parent.isBranchChoice)
		{
			// Does the index of this child match its parent's length (is its index the last one?)
			if((this.childIndex+1) == this.parent.pageList.length)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			// Page is not inside a branch, try parent
			return this.parent.isLastPageInBranch();
		}
	};
	
	this.hasNextSibling = function()
	{
		if(!this.parent){return false;}
		return (this.parent.pageList[(this.childIndex + 1)]) ? true : false;
	};
	
	this.hasPrevSibling = function()
	{
		if(!this.parent){return false;}
		return (this.parent.pageList[(this.childIndex - 1)]) ? true : false;
	};

	this.getNextSibling = function()
	{
		return (this.hasNextSibling()) ? this.parent.pageList[(this.childIndex + 1)] : null;
	};

	this.getPrevSibling = function()
	{
		return (this.hasPrevSibling()) ? this.parent.pageList[(this.childIndex - 1)] : null;
	};
	
	this.isTerminationPage = function()
	{
		if(this.parent)
		{
			// If my parent is a branch choice, I'm inside a branch...
			if(this.parent.isBranchChoice)
			{
				// Am I the last page in this branch?
				if(this.isLastPageInBranch())
				{
					// Does my parent have an "end" property set to "true"?
					return this.parent.end;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	};
	
	this.canMoveNext = function()
	{
		//Utils.debug.trace("Can I go next?...");
		// By default, I can move forward...
		var canNext = true;
	
		if(this.parent)
		{
			// If my parent is a branch choice, I'm inside a branch...
			if(this.parent.isBranchChoice)
			{
				// Am I the last page in this branch?
				if(this.isLastPageInBranch())
				{
					//Utils.debug.trace("I'm the last page in a branch, let me see...");
					// Does my parent have an "end" property set to "true"?
					if(this.parent.end)
					{
						//Utils.debug.trace("NO! I'm inside a branch choice, and parent.end = true.");
						canNext = false;
					}
		
					// Is there even a page to move forward to? 
					if(!this.getNextAccessiblePage())
					{
						//Utils.debug.trace("NO! I'm inside a branch choice, and I can't locate an accessible page.");
						canNext = false;
					}
				}
			}
		}

		// Am I a branching stencil?
		if(this.isBranch)
		{
			//Utils.debug.trace("I'm a branching stencil, let me see...");
			// Is there no "next" property to go to?
			if(!this.next)
			{
				//Utils.debug.trace("NO! I'm a branching stencil, and there's no 'next' property set.");
				canNext = false;
			}
		}
	
		// If my page index is greater than or equal to the total number of pages in the course, I must be the last page.
		if(this.index >= (engine.controller.pageList.length-1))
		{
			//Utils.debug.trace("NO! I'm the last page in the course.");
			canNext = false;
		}
	
		if(canNext)
		{
			//Utils.debug.trace("Yes, I can go next.");
		}
	
		return canNext;
	};
	
	this.getNextAccessiblePage = function()
	{
		/*
		 * In a branching scenario, the content author has three choices for
		 * allowing the learner to navigate forward from within a branching stencil
		 * 
		 * - No Default Choice (User must choose):
		 * 		- Next button is disabled, user must submit choice
		 * 		- The "next" page property does not exist
		 * 
		 * - Next Linear Page (User may bypass branching):
		 * 		- Next button is enabled, user can navigate to next linear page
		 * 		- Next linear page must exist "somewhere" after the branching stencil
		 * 		- The "next" page property is set to true
		 * 
		 * - Default Choice (A specific branch is selected):
		 * 		- Next button is enabled, user is taken to the default choice upon clicking Next
		 * 		- The "next" page property contains a reference to the choice's page name
		 */
		
		//Utils.debug.trace('Testing for next accessible page from page titled: '+this.title)
		// Does this node even have a next sibling to check for?
		if(this.hasNextSibling())
		{
			// This node has siblings.  Get a reference to them.
			var siblings = this.parent.pageList;
	
			//Utils.debug.trace('I have siblings... Let me check...');
			
			// Loop over the siblings, beginning with this child
			for(var i=(this.childIndex+1); i<siblings.length; i++)
			{
				// If this sibling is *not* a choice
				if(!siblings[i].isBranchChoice)
				{
					//Utils.debug.trace('This sibling is not a branch choice - returning page titled: '+siblings[i].title);
					// This sibling is the next "accessible" page
					return siblings[i];
				}
			}
	
			//Utils.debug.trace('I do not have siblings that I should be able to access...');
		}
		else
		{
			//Utils.debug.trace('I do not have siblings...');
		}
	
		// If there is no next sibling and this is a child
		if(this.parent)
		{
			//Utils.debug.trace('Let me check with my parent...');
			// Try getting the next sibling from this child's parent
			return this.parent.getNextAccessiblePage();
		}
		else
		{
			//Utils.debug.trace('I have no siblings or parents! Am I the root?');
			// No next sibling and no parent - root?
			return null;
		}
	};

	this.isVisiblePage = function()
	{
		if(!this.isADescendantOfABranch())
		{
			return true;
		}
		return false;
	};

	this.getVisibleAncestorIndex = function()
	{
		// If this page's parent is a branch, and its parent is not a descendant of a branch itself,
		// return its visible index
		if(this.parent && this.parent.isBranch && !this.parent.isADescendantOfABranch())
		{
			return this.parent.visibleIndex;
		}
		else
		{
			// No? If this page has a parent (not the root course page), check its parent
			if(this.parent)
			{
				return this.parent.getVisibleAncestorIndex();
			}
			else
			{
				return false;
			}
		}
	};

	this.isADescendantOfABranch = function()
	{
		// If this page's parent is a branch, it's a descendant of a branch
		if(this.parent && this.parent.isBranch)
		{
			return true;
		}
		else
		{
			// No? If this page has a parent (not the root course page), check its parent
			if(this.parent)
			{
				return this.parent.isADescendantOfABranch();
			}
			else
			{
				return false;
			}
		}
	};
	
	/**
	 * Return a useful string depiction of this page object
	 * @method toString
	 * @return {String} The name of this page object
	 */
	this.toString = function()
	{
		return this.name;
	};
}
