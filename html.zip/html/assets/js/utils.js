/** 
* Global singleton JavaScript utility library
* @type {Object}
*/
if(!window.Utils){window.Utils = {};}

//Array functions
Utils.array = {
	contains: function(a, match)
	{
        if(a.length)
		{
            for(var i = 0; i < a.length; i++)
			{
                if(a[i] === match)
				{
                    return true;
                }
            }
        }

		//no match
        return false;
    },
    
    truncate: function(a, i)
    {
    	a = a.slice(0,i);
    	return a;
    },
    
    fisherYates: function(a)
	{
		var i = a.length;
		if(i == 0)
		{
			return false;
		}
		while(--i)
		{
			var j = Math.floor(Math.random() * (i + 1));
			var tempi = a[i];
			var tempj = a[j];
			a[i] = tempj;
			a[j] = tempi;
		}
	},
	
	invoke: function(a,f)
	{
		for(var i=0; i<a.length;i++)
		{
			f(a[i]);
		}
	}
};

Utils.object = {
	extend: function(p)
	{
		function f(){}
		f.prototype = p;
		return new f();
	}
};

Utils.string = {
	trim: function(s)
	{
		return s.replace(/^\s+|\s+$/g,"");
	},
	stripTags: function(s)
	{
		return this.trim(s.replace(/<\/?[^>]+(>|$)/g, ""));
	},
	encodeState: function(str)
	{
		if(typeof(str) != 'string'){return;}
		var len=str.length;
		var curChar=str.charAt(0);
		var curCount=0;
		var encArr=[];
		for(var i=0;i<=len;i++)
		{
			var c = str.charAt(i);
			if(c===curChar)
			{
				curCount++;
			}
			else
			{
				encArr.push(curChar+'.'+curCount);
				curCount=1;
				curChar=c;
			}
		}
		return encArr.join('-');
	},
	decodeState: function(str)
	{
		var decStr='';
		var diffChars=str.split('-');
		var len=diffChars.length;
		for(var i=0;i<len;i++)
		{
			var curSection=diffChars[i].split('.');
			var curChar=curSection[0];
			var curLen=curSection[1];
			var curSectionStr='';
			while(curSectionStr.length < curLen)
			{
				curSectionStr+=curChar;
			}
			decStr += curSectionStr;
		}
		return decStr;
	},
	replaceChars: function(str){
		var symbols = {
			'%40':'@',
			'%26':'&amp;',
			'%2A':'*',
			'%2B':'+',
			'%2F':'/',
			'%5C':'\\',
			'%3C':'&lt;',
			'%3E':'&gt;',
			'%22':'"',
			'%27':'\''
	}
		str = str.replace(/(%(40|26|2A|2B|2F|5C|3C|3E|22|27))/g, function (m) { return symbols[m]; });
		return str;
	}
};

//Flash utilities - Based on swfobject
Utils.flash = {
	hasRequiredVer: function()
	{
		if(swfobject.hasFlashPlayerVersion(this.getRequiredVer()))
		{
			return true;
		}
		else
		{
			return false;
		}
	},
	getRequiredVer: function()
	{
		return engine.flashPluginVer;
	},
	getInstalledVer: function()
	{
		var verObj = swfobject.getFlashPlayerVersion();
		return verObj.major+'.'+verObj.minor+'.'+verObj.release;
	},
	showWarning: function()
	{
		Utils.dom.show("noFlash");

		Utils.dom.renderHTML("noFlashHeaderText",unescape(Lang.FLASH_WARNING_TITLE));
		Utils.dom.renderHTML("flashWarningItAppears",unescape(Lang.FLASH_WARNING_IT_APPEARS));
		Utils.dom.renderHTML("flashWarningCurrentVersion",unescape(Lang.FLASH_WARNING_CURRENT_VERSION));
		Utils.dom.renderHTML("flashCurrentVersion",this.getInstalledVer());
		Utils.dom.renderHTML("flashWarningRequiredVersion",unescape(Lang.FLASH_WARNING_REQUIRED_VERSION));
		Utils.dom.renderHTML("flashRequiredVersion",this.getRequiredVer());
		Utils.dom.renderHTML("flashWarningClickHereToInstall",unescape(Lang.FLASH_WARNING_CLICK_HERE_TO_INSTALL));
		Utils.dom.renderHTML("flashWarningContactYourAdmin",unescape(Lang.FLASH_WARNING_CONTACT_YOUR_ADMIN));
	},
	showWarningIOS: function()
	{
		Utils.dom.show("noFlash");

		Utils.dom.renderHTML("noFlashHeaderText",unescape(Lang.FLASH_WARNING_TITLE));
		Utils.dom.renderHTML("flashWarningItAppears",unescape(Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED));
		Utils.dom.renderHTML("flashWarningCurrentVersion",unescape(Lang.FLASH_WARNING_CURRENT_VERSION));
		Utils.dom.renderHTML("flashCurrentVersion",unescape(Lang.FLASH_WARNING_VERSION_UNSUPPORTED));
		Utils.dom.renderHTML("flashWarningRequiredVersion",unescape(Lang.FLASH_WARNING_REQUIRED_VERSION));
		Utils.dom.renderHTML("flashRequiredVersion",this.getRequiredVer());
	},
	showAICCWarning: function()
	{
		var c = new Cookie(document,'uPerformFlashWarningAicc',730,'/');
		c.load();
		if(c["hide"] === "true"){return;}

		Utils.dom.show("noFlash");

		Utils.dom.renderHTML("noFlashHeaderText",unescape(Lang.FLASH_WARNING_TITLE));
		Utils.dom.renderHTML("flashWarningItAppears",unescape(Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED_AICC));
		Utils.dom.renderHTML("flashWarningCurrentVersion",unescape(Lang.FLASH_WARNING_CURRENT_VERSION));
		Utils.dom.renderHTML("flashCurrentVersion",unescape(Lang.FLASH_WARNING_VERSION_UNSUPPORTED));
		Utils.dom.renderHTML("flashWarningRequiredVersion",unescape(Lang.FLASH_WARNING_REQUIRED_VERSION));
		Utils.dom.renderHTML("flashRequiredVersion",this.getRequiredVer());

		var tmp = '<input type="checkbox" onclick="Utils.flash.toggleFlashAICCMessage(this);" />';

		Utils.dom.renderHTML("flashWarningDoNotShowAgain",tmp+' '+unescape(Lang.FLASH_WARNING_DO_NOT_SHOW_MESSAGE_AGAIN));
	},
	closeWarning: function()
	{
		Utils.dom.hide("noFlash");
	},
	toggleFlashAICCMessage: function(chkbx)
	{
		var c = new Cookie(document,'uPerformFlashWarningAicc',730,'/');
		if(chkbx.checked)
		{
			c["hide"] = "true";
			c.store();
		}
		else
		{
			c.remove();
		}
	}
};

//Window functions
Utils.window = {
	getRootFolder: function()
	{
		try
		{
			if(self.location.href.indexOf("?") >= 0)
			{
				var urlOnly = self.location.href.substring(0,self.location.href.lastIndexOf("?"));
			}
			else
			{
				var urlOnly = self.location.href;
			}
			return urlOnly.substring(0,urlOnly.lastIndexOf("/"));
		}
		catch (e)
		{
			Utils.debug.trace('Error: Cannot get filename in Utils.window.getRootFolder: '+e);
		}
		
	},
	getFileName: function()
	{
		try
		{
			if(self.location.href.indexOf("?") >= 0)
			{
				var urlOnly = self.location.href.substring(0,self.location.href.lastIndexOf("?"));
			}
			else
			{
				var urlOnly = self.location.href;
			}
			return unescape(urlOnly.substring(urlOnly.lastIndexOf("/")+1,urlOnly.lastIndexOf(".htm")));
		}
		catch (e)
		{
			Utils.debug.trace('Error: Cannot get filename in Utils.window.getFileName: '+e);
		}
		
	},
	open: function(url_name,window_name,w,h,options)
	{
		try
		{
			if (options == null) { options=""; }

			if(!Utils.window.canFit(Conf.WINDOW_W,Conf.WINDOW_H) || ((Utils.browserDetection.browser == "ie" && Utils.browserDetection.version < 9) && (w > 1024 && h > 768))) {
				var width = screen.availWidth-100;
				var height = screen.availHeight-100;
				var left = 50;
				var top = 50;
			} else {
				var width = w;
				var height = h;
				var left = 0;
				var top = 0;
			}
			winopts = "toolbar=" + (options.indexOf("toolbar") == -1 ? "no," : "yes,") +
			"location="  + (options.indexOf("location") == -1 ? "no," : "yes,") +
			"menubar=" + (options.indexOf("menubar") == -1 ? "no," : "yes,") +
			"scrollbars=" + (options.indexOf("scrollbars") == -1 ? "no," : "yes,") +
			"status=" + (options.indexOf("status") == -1 ? "no," : "yes,") +
			"resizable=" + (options.indexOf("resizable") == -1 ? "no," : "yes,") +
			"copyhistory=" + (options.indexOf("copyhistory") == -1 ? "no," : "yes,") +
			"width=" + width + ",height=" + height + "," +
			"left=" + left + ",top=" + top;
			
			var newWin = window.open(url_name,window_name,winopts);
			
			try
			{
				if(newWin)
				{
					newWin.moveTo(0,0);
					newWin.focus();
				}
			} catch (e) { }

			return newWin;
		}
		catch (e)
		{
			Utils.debug.trace('Error: Cannot open window in Utils.window.open: '+e);
		}
	},
	openSim: function(simName,mode,simParent,params)
	{
		if(Utils.browserDetection.isMobile())
		{
			var c = new Cookie(document,'uPerformSimLaunchPage',730,'/');
			c["simParent"] = simParent.name;
			c.store();
		}
		
		switch(mode)
		{
			case 0:
				var file = "sim_auto_playback.htm";
				break;
			case 1:
				var file = "sim_standard.htm";
				break;
			case 2:
				var file = "sim_self_test.htm";
				break;
			case 3:
				var file = "sim_assessment.htm";
				break;
			default:
				var file = "sim_auto_playback.htm";
				break;
		}
		var rootFolder = this.getRootFolder();
		if (params != null) {		
			this.open(rootFolder+'/content/sims/'+simName+'/'+file+'?embedded=true&' + encodeURI(params),"simWin",Conf.WINDOW_W,Conf.WINDOW_H, "resizable=yes");
		} else {
		this.open(rootFolder+'/content/sims/'+simName+'/'+file+'?embedded=true' ,"simWin",Conf.WINDOW_W,Conf.WINDOW_H, "resizable=yes");
		}
	},
	/*
	Return the name of the sim launch page we've left off with in a mobile environment.
	*/
	getMobileSimPageName: function()
	{
		try
		{
			var c = new Cookie(document,'uPerformSimLaunchPage',730,'/');
			c.load();
			var simParent = c["simParent"];
			if(simParent)
			{
				c.remove();
				return simParent;
			}
			return null;
		}
		catch(e){}
	},
	/*
	Clear the name of the sim launch page cookie.
	*/
	clearMobileSimPageName: function()
	{
		var c = new Cookie(document,'uPerformSimLaunchPage',730,'/');
		c.remove();
	},
	parseParams: function(paramString)
	{
		paramString = paramString.substring(1,paramString.length);
		var d = new Object();
		if(paramString.indexOf('=') != -1)
		{
			var index0 = -1;
			var count = 1;
			while(((index0 + 1) < paramString.length) &&
					((index0 = paramString.indexOf('&', index0 + 1)) != -1)) {
				count++;
			}
	
			var index1 = 0;
			var index2 = 0;
			var keyValue = null;
			var subindex = 0;
			var len = paramString.length;
	
			while(index1 < len) {
				index2 = paramString.indexOf('&', index1);
				if(index2 == -1)
					index2 = len;
					keyValue = paramString.substring(index1, index2);
					subindex = keyValue.indexOf('=');
					var key = keyValue.substring(0, subindex);
					var key = key.toLowerCase();
					var val = keyValue.substring(subindex + 1, keyValue.length)
					d[unescape(key)] = unescape(val);
					index1 = index2 + 1;
				}
			}
		return d;
	},
	getSearchParams: function()
	{
		if(document.location.search)
		{
			Utils.debug.trace('Found search string in this window');
			return Utils.window.parseParams(document.location.search);
		}

		if(this.isSameDomain('parent'))
		{
			if(parent.document.location.search)
			{
				Utils.debug.trace('Found search string in parent window');
				return Utils.window.parseParams(parent.document.location.search);
			}
		}

		if(this.isSameDomain('top'))
		{
			if(top.document.location.search)
			{
				Utils.debug.trace('Found search string in top window');
				return Utils.window.parseParams(top.document.location.search);
			}
		}
		
		Utils.debug.trace('Search string not detected');

		return null;
	},
	isSameDomain: function(winRefStr)
	{
		var winRef = eval(winRefStr);
		var sameDomain = true;
		var winName = null;
    
		try
		{
			winName = winRef.name;			
			if(!winName)
			{
				winRef.name = (Conf.REUSE_EXISTING_WINDOW) ? 'courseWindow' : 'courseWindow_'+Conf.CONTENT_ID;
				if (!winRef.name)
				{
					sameDomain = false;
				}
			}
		}
		catch(e)
		{
			sameDomain = false;
			Utils.debug.trace('Window reference not in same domain as: '+document.domain);
		}

		return sameDomain;
	},
	canFit: function(w,h)
	{
		return ((w < screen.width) && (h < screen.height));
	}
}

//DOM functions
Utils.dom = {

	cursor: {x:0, y:0},
	
	setStyleById: function(id,attr,val,suffix,doc)
	{
		var el = (doc) ? doc.id(id) : $(id);
		var suf = (suffix) ? suffix : '';
		if(el)
		{
			el.style[attr]=val+suf;
		}
	},
	
	renderHTML: function(id,val,doc)
	{
		var el = (doc) ? doc.id(id) : $(id);
		el.innerHTML='<span id="renderText">'+val+'</span>';
	},
	
	renderHTMLclass: function(id,val,doc,classVal)
	{
		var el = (doc) ? doc.id(id) : $(id);
		el.innerHTML=val;
		el.className=classVal;
	},
	
	findPosX: function(el)
	{
		var curleft = 0;
		if(el.offsetParent)
		{
			while(1) 
		    {
		      curleft += el.offsetLeft;
		      if(!el.offsetParent)
		        break;
		      el = el.offsetParent;
		    }
		}
		else if(el.x)
		{
			curleft += el.x;
		}

		return curleft;
	},
	
	findPosY: function(el)
	{
		var curtop = 0;
		if(el.offsetParent)
		{
			while(1)
		    {
		      curtop += el.offsetTop;
		      if(!el.offsetParent)
		        break;
		      el = el.offsetParent;
		    }
		}
		else if(el.y)
		{
			curtop += el.y;
		}
		    
		return curtop;
	},
	
	updateCursorPos: function(e)
	{
		e = e || window.event;
		try
		{
			/*if(e.pageX || e.pageY)
			{
		        Utils.dom.cursor.x = e.pageX;
		        Utils.dom.cursor.y = e.pageY;
		    } 
		    else
			{
		        Utils.dom.cursor.x = e.clientX + 
		            (document.documentElement.scrollLeft || 
		            document.body.scrollLeft) - 
		            document.documentElement.clientLeft;
				Utils.dom.cursor.y = e.clientY + 
		            (document.documentElement.scrollTop || 
		            document.body.scrollTop) - 
		            document.documentElement.clientTop;
		    }*/
			var contentWrapper = $('wrapper');
			Utils.dom.cursor.x = e.clientX + 
				contentWrapper.scrollLeft;
			Utils.dom.cursor.y = e.clientY + 
				contentWrapper.scrollTop;

		    
		}
		catch(e)
		{
			alert('error - '+e.description);
			Utils.debug.trace('Error: Utils.dom.updateCursorPos - '+e.description);
		}
	},

	updateTouchPos: function(e)
	{
		var x = e.touches[0].pageX;
		var y = e.touches[0].pageY;
		if(x || y)
		{
	        Utils.dom.cursor.x = x;
	        Utils.dom.cursor.y = y;
	    }
	},

	getCurrentStyle: function(el, prop)
	{
	   if(el.currentStyle)
	   {  
		  var ar = prop.match(/\w[^-]*/g);
		  var s = ar[0];
		  
		  for(var i = 1; i < ar.length; ++i)		   
		  {
			 s += ar[i].replace(/\w/, ar[i].charAt(0).toUpperCase());
		  }
			   
		  return el.currentStyle[s]
	   }
	   else if(document.defaultView.getComputedStyle)
	   {
		  return document.defaultView.getComputedStyle(el, null).getPropertyValue(prop);
	   }
	},

	getElementsByClassName: function(node,classname)
	{
		var a = [];
		var re = new RegExp('\\b'+classname+'\\b');
		var els = node.getElementsByTagName("*");
		for(var i=0,j=els.length; i<j; i++)
		{
			if(re.test(els[i].className))
			{
				a.push(els[i]);
			}
		}
		return (a.length > 1) ? a : a[0];
	},
	
	getCurrentStyleAsNum: function(el,prop)
	{
		return parseInt(this.getCurrentStyle(el,prop));
	},

	show: function(id)
	{
		$(id).setStyle('display','block');
		$(id).setStyle('visibility','');
	},

	hide: function(id)
	{
		$(id).setStyle('display','none');
	},

	getTrueElement: function(el, doc)
	{
		doc = (doc) ? doc : document;
		if (el != null)
		{
			if(typeof el == "string")
			{
				el = doc.id(el);
			}
			else
			{
				el = doc.id(el.id);
			}
		}
		return el;
	},

	setOpacity: function(opac,el,doc)
	{
		el = Utils.dom.getTrueElement(el, doc);

		if (el != null)
		{
			el.set({
				styles:
				{
					'-khtml-opacity':(opac/100),
					'-moz-opacity':(opac/100),
					'filter':'alpha(opacity='+opac+')',
					'opacity':(opac/100)
				}
			});
		}
	},
	
	fadeIn: function(el,cb,doc)
	{
		if(Conf.ENABLE_TRANSITIONS)
		{
			this.fadeTo(el,0,1,cb,doc);
		}
		else
		{
			this.setOpacity(100,el,doc);
			if(typeof cb == "function")
			{
				cb();
			}
		}
	},
	
	fadeOut: function(el,cb,doc)
	{
		if(Conf.ENABLE_TRANSITIONS)
		{
			this.fadeTo(el,1,0,cb,doc);
		}
		else
		{
			this.setOpacity(0,el,doc);
			if(typeof cb == "function")
			{
				cb();
			}
		}
	},
	
	fadeTo: function(el,from,to,cb,doc)
	{
		el = Utils.dom.getTrueElement(el, doc);
		if(Conf.ENABLE_TRANSITIONS)
		{
			cb = cb || function(){};
			if(el.fadefx){el.fadefx.cancel();}
			el.fadefx = new Fx.Tween(el,
				{link:'ignore',property:'opacity',duration:500,transition:'linear'})
				.addEvent('onComplete', function(){
					cb();
				});
			el.fadefx.start(from,to);
		}
		else
		{
			this.setOpacity(to,el);
			if(typeof cb == "function")
			{
				cb();
			}
		}
	},
	
	animateTo: function(el,prop,from,to,dur,suffix,cb)
	{
		if(Conf.ENABLE_TRANSITIONS)
		{
			cb = cb || function(){};
			if(el.animfx){el.animfx.cancel();}
			el.animfx = new Fx.Tween(el,
				{link:'ignore',property:prop,duration:dur,transition:'quint:out'})
				.addEvent('onComplete', function(){
					cb();
				});
			el.animfx.start(from,to);
		}
		else
		{
			this.setStyleById(el.id,prop,to,suffix);
			if(typeof cb == "function")
			{
				cb();
			}
		}
	},

	removeFilter: function(el)
	{
		el.style.filter = '';
	},

	getFlashObject: function(id)
	{
		if(Utils.browserDetection.browser == "ie")
		{
			return window[id];
		}
		else
		{
			return document[id];
		}
	},

	loadJsFile: function(filename)
	{
		var fileref = document.createElement('script');
		fileref.setAttribute("type","text/javascript");
		fileref.setAttribute("src", filename);

		if(typeof fileref!="undefined")
		{
			document.getElementsByTagName("head")[0].appendChild(fileref);
		}
	},
	
	loadCssFile: function(filename) 
	{
		var fileref = document.createElement("link");
		fileref.setAttribute("rel", "stylesheet");
		fileref.setAttribute("type", "text/css");
		fileref.setAttribute("href", filename);
		
		if(typeof fileref!="undefined")
		{
			document.getElementsByTagName("head")[0].appendChild(fileref);
		}
	},
	
	addEvent: function(obj,evType,fn)
	{ 
		if(obj && obj.addEventListener)
		{ 
			obj.addEventListener(evType, fn, false); 
			return true; 
		}
		else if (obj && obj.attachEvent)
		{
			var r = obj.attachEvent("on"+evType, fn); 
			return r; 
		}
		else
		{ 
			return false; 
		} 
	},

	addEventById: function(id,evType,fn)
	{
	    if (document) {
	        var element = document.getElementById(id);
	        return this.addEvent(element, evType, fn);
	    }

	    return false;
	},

	removeEvent: function(obj,evType,fn)
	{
	    if(obj && obj.removeEventListener)
	    {
	        obj.removeEventListener(evType, fn);
	        return true;
	    }
	    else if(obj && obj.detachEvent)
	    {
	        obj.detachEvent(evType, fn);
	        return true;
	    }

	    return false;
	},

	removeEventById: function(id,evType,fn)
	{
	    if (document) {
	        var element = document.getElementById(id);
	        this.removeEvent(element, evType, fn);
	    }

	    return false;
	},
	
	getEventTargetElement: function(e)
	{
		var target;
		if(!e) var e=window.event;
		if(e.target)
		{
			target = e.target;
		}
		else if(e.srcElement)
		{
			target = e.srcElement;
		}
		if (target.nodeType == 3)
		{
			target = target.parentNode;
		}
		return target;
	},
	convertPageTitle: function(title)
	{
        var d=document.createElement("div");
        d.innerHTML=title;
        return d.innerHTML;
	},
	unselectable: function(el)
	{
		if(typeof el.onselectstart != 'undefined')
		{
			el.addEvent('selectstart',function() { return false; });
		}
		else if(typeof el.style.MozUserSelect != 'undefined')
		{
			el.setStyle('MozUserSelect', 'none');
		}
		else if(typeof el.style.WebkitUserSelect != 'undefined')
		{
			el.setStyle('WebkitUserSelect', 'none');
		}
		else if(typeof el.unselectable  != 'undefined')
		{
			el.setProperty('unselectable','on');
		}		
	},
	hitTest: function(o,l)
	{
		//+ Jonas Raoni Soares Silva
		//@ http://jsfromhell.com/geral/hittest [rev. #2]
	    function getOffset(o){
	        for(var r = {l: o.offsetLeft, t: o.offsetTop, r: o.offsetWidth, b: o.offsetHeight};
	            o = o.offsetParent; r.l += o.offsetLeft, r.t += o.offsetTop);
	        return r.r += r.l, r.b += r.t, r;
	    }
	    var a = arguments, j = a.length;
	    j > 2 && (o = {offsetLeft: o, offsetTop: l, offsetWidth: j == 5 ? a[2] : 0,
	    offsetHeight: j == 5 ? a[3] : 0, offsetParent: null}, l = a[j - 1]);
	    for(var b, s, r = [], a = getOffset(o), j = isNaN(l.length), i = (j ? l = [l] : l).length; i;
	        b = getOffset(l[--i]), (a.l == b.l || (a.l > b.l ? a.l <= b.r : b.l <= a.r))
	        && (a.t == b.t || (a.t > b.t ? a.t <= b.b : b.t <= a.b)) && (r[r.length] = l[i]));
	    return j ? !!r.length : r;
	},
	disableAuxButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("auxBtnEnabled");
		$(id).addClass("auxBtnDisabled");
	},
	enableAuxButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("auxBtnDisabled");
		$(id).addClass("auxBtnEnabled");
	},
	disableNavButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("navBtnEnabled");
		$(id).addClass("navBtnDisabled");
	},
	enableNavButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("navBtnDisabled");
		$(id).addClass("navBtnEnabled");
	},
	disableAudioButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("audioBtnEnabled");
		$(id).addClass("audioBtnDisabled");
	},
	enableAudioButtonById: function(id)
	{
		if(!$chk($(id))){return;}
		$(id).removeClass("audioBtnDisabled");
		$(id).addClass("audioBtnEnabled");
	}
};

// Popup functionality
Utils.popup = {
	show: function(name,hs,ignoreSingle,defX,defY)
	{
		if(!$chk($(name))){return;}
		if (Conf.SINGLE_POPUP && !ignoreSingle)
		{
			Utils.popup.hideAll();
		}

		$(name).setStyle('opacity',0);
		Utils.dom.show(name);
		
		Utils.dom.setStyleById(name,'width',Conf.POPUP_WIDTH,'px');
		Utils.dom.setStyleById('t_'+name,'display','block');
		Utils.dom.setStyleById('tc_'+name,'display','block');
		Utils.dom.setStyleById('tclose_'+name,'display','block');
		
		var hh = $('tc_'+name).getStyle('height').toInt();
		var hh2 = $('tclose_'+name).getStyle('height').toInt();
		if (hh2 > hh)
		{
			hh = hh2;
    	}
    	
    	Utils.dom.setStyleById('t_'+name,'height',hh,'px');
		
        if (!defX || !defY){
		if(hs && (Utils.dom.cursor.x == 0 && Utils.dom.cursor.y == 0))
		{
			if(Utils.browserDetection.isMobile())
			{
				var x = Utils.dom.findPosX(hs)+20+hs.getStyle('width').toInt()+$('container').getStyle('margin-left').toInt();
			}
			else
			{
				var x = Utils.dom.findPosX(hs)+20+hs.getStyle('width').toInt();
			}
			
			var y = Utils.dom.findPosY(hs)+20;
		}
		else
		{
			var x = Utils.dom.cursor.x+20;
			var y = Utils.dom.cursor.y+20;
		}

			// If the popup is off the bottom of the screen, fix it
			var h = parseInt(Utils.dom.getCurrentStyle($(name),"height"));
			h = (isNaN(h)) ? $(name).offsetHeight : h;
			y = ((y+h) > parent.$("content").clientHeight) ? (parent.$("content").clientHeight-h-10) : y;

			var cursorX = (Utils.dom.cursor.x > 0) ? Utils.dom.cursor.x : hs.x;
	
			// If x is off the screen to the right, fix it
			x = ((x+(Conf.POPUP_WIDTH)) > parent.$("content").offsetWidth) ? cursorX-(20+Conf.POPUP_WIDTH) : x;
	
			// If y is off the top of the screen, fix it
			y = (y<0) ? 0 : y;
			// If x is off the screen to the left, fix it
			x = (x<0) ? 0 : x;
		} else{
			var x = defX;
			var y = defY;
			
		// If the popup is off the bottom of the screen, fix it
		var h = parseInt(Utils.dom.getCurrentStyle($(name),"height"));
		h = (isNaN(h)) ? $(name).offsetHeight : h;
			y = ((y+h) > parent.$("content").offsetHeight) ? (parent.$("content").offsetHeight-h) : y;
	
			var cursorX = (Utils.dom.cursor.x > 0) ? Utils.dom.cursor.x : hs.x;
	
			// If x is off the screen to the right, fix it
			x = ((x+(Conf.POPUP_WIDTH)) > parent.$("content").offsetWidth) ? x-(Conf.POPUP_WIDTH) : x;
	
			// If y is off the top of the screen, fix it
			y = (y<0) ? 0 : y;
			// If x is off the screen to the left, fix it
			x = (x<0) ? 0 : x;
		}

		$(name).set('aria-hidden',false);

		// If the popup is off the bottom of the screen, fix it
		var h = parseInt(Utils.dom.getCurrentStyle($(name),"height"));
		h = (isNaN(h)) ? $(name).offsetHeight : h;
		y = ((y+h) > ($("wrapper").offsetHeight)+$("wrapper").scrollTop) ? ((($("wrapper").offsetHeight)+$("wrapper").scrollTop)-h) : y;

		var cursorX = (Utils.dom.cursor.x > 0) ? Utils.dom.cursor.x : hs.x;
		
		// If x is off the screen to the right, fix it
		x = ((x+(Conf.POPUP_WIDTH)) > parent.$("content").offsetWidth) ? cursorX-(20+Conf.POPUP_WIDTH) : x;

		// If y is off the top of the screen, fix it
		y = (y<0) ? 0 : y;
		// If x is off the screen to the left, fix it
		x = (x<0) ? 0 : x;

		$(name).set('aria-hidden',false);

		Utils.dom.setStyleById(name,'top',y,'px');
		Utils.dom.setStyleById(name,'left',x,'px');
		
		var anchor = $('anchor_' + name);
		if (anchor == null)
		{
			anchor = new Element('a',{
				'name':name,
				'id':'anchor_' + name
			});
			$(name).adopt(anchor);
		}

		Utils.dom.fadeIn($(name));

		if(Hotspot){Hotspot.updateHotspots();}
		if(Zoom){Zoom.updateZoomButtons();}
		if(Zoom){Zoom.ZoomPopup();}
	},
	showNoClose: function(name,hs)
	{
		Utils.popup.show(name, hs);
		Utils.dom.setStyleById('tclose_'+name,'display','none');
	},
	hide: function(name)
	{
		if(!$chk($(name))){return;}
		Utils.dom.hide(name);
		$(name).set('aria-hidden',true);

		if(Hotspot){Hotspot.updateHotspots();}
		if(Zoom){Zoom.updateZoomButtons();}
	},
	hideAll: function()
	{
		var test = $$('.popupContainer');

		test.each(function(pContainer, index){
			Utils.popup.hide(pContainer.id);
		});
	},
	showDefault: function(name, ctrl)
	{
		var pContainer = $(name);

		if (pContainer){
			if (pContainer.getAttribute("showDefault"))
			{
				if (pContainer.getAttribute("showDefault") == "true")
	            {
	                var x = ctrl.getStyle('left').toInt();
	                var y = ctrl.getStyle('top').toInt();
	
	                if (isNaN(x))
	                {
	                    x = Utils.dom.findPosX(ctrl);
	}
	
	                if (isNaN(y))
	                {
	                    y = Utils.dom.findPosY(ctrl);
}

	                //Accounts for the popup links in first page showing up in successive assessment pages
	                if (x > 0 || y >0)
	                {				
		                Utils.popup.show(pContainer.id, ctrl, true, x + 20, y + 20);
					}
				}
			}
		}
	},
	showAll: function()
	{
        if(Hotspot){Hotspot.updateHotspots();}
		if(Hotspot){Hotspot.showAllHotspotPopups();}
		
		var test = $$('.popupContainer');
	
		test.each(function(pContainer, index){
			if ($('source_'+pContainer.id)) 
			{
				Utils.popup.showDefault(pContainer.id, $('source_'+pContainer.id));
			}
		});
	}
}

//Debugger functions
Utils.debug = {

	data: [],
	debugConsole: null,

	//msg: the trace string
	//type: 'info', 'comm', 'error' (defaults to info if not specified)
	trace: function(msg,type)
	{
		if(!Conf.ENABLE_DEBUGGER){return}
		type = type || 'info';
		this.data.push({msg:msg,type:type,toString:function(){return this.msg;}});
		try
		{
			if(console)
			{
				if(type === 'error')
				{
					console.warn(msg);
				}
				else
				{
					console.log(msg);
				}
			}
		}
		catch(e){}
		this.refresh();
	},

	show: function()
	{
		if(!this.debugConsole || this.debugConsole.closed)
		{
			this.debugConsole = Utils.window.open(Utils.window.getRootFolder()+'/assets/htm/debugger.htm','debugger',640,480,'scrollbars,resizable');
		}
		else
		{
			this.debugConsole.focus();
		}

		if(!this.debugConsole)
		{
			alert(unescape(Lang.CANNOT_OPEN_DEBUG_WIN));
			alert(this.data.join("\n"));
		}
	},

	refresh: function()
	{
		try
		{
			if(this.debugConsole)
			{
				if(!this.debugConsole.closed)
				{
					var html = '';
					for(var i=0; i<this.data.length; i++)
					{
						html += '<div class="'+this.data[i].type+'">&gt; '+this.data[i].msg+'</div>';
					}
					this.debugConsole.updateConsole(html);
				}
			}
		}
		catch(e){}
	},
	
	terminate: function()
	{
		if(this.debugConsole)
		{
			if(!this.debugConsole.closed)
			{
				this.debugConsole.close();
			}
		}		
	}
};

//Comment/Reviewer functions
Utils.comment = {

	commentWin: null,

	show: function()
	{
		try
		{
			if(!this.commentWin || this.commentWin.closed)
			{
				this.commentWin = Utils.window.open('assets/htm/comment.htm?itemid='+engine.controller.currentPageObj.name,'reviewerComment',670,600,'scrollbars,resizable');
			}
			else
			{
				this.commentWin.focus();
			}
		}
		catch (e)
		{
			alert('Error: '+e);
		}
		
	}
};

//Browser detection functions
Utils.browserDetection = {

	browser:"",
	version:"",
	OS:"",
	details:"",
	
	init: function()
	{
		this.browser = Browser.name;
		this.version = Browser.version;
		this.OS = Browser.Platform.name;
		this.details = this.OS +" "+ this.browser + " " + this.version;
	},

	isMobile: function()
	{
		if(Conf.MOBILE_DEVICES.length === 0){return;}
		var isMobile = false;
		Conf.MOBILE_DEVICES.each(function(item,index){
			var a = item.split("/");
			if(a.length === 2)
			{
				var os = a[0].toLowerCase();
				if(a[1] === "")
				{
					if(this.OS == os)
					{
						isMobile = true;
					}
				}
				else
				{
					var browser = a[1].toLowerCase();
					if(this.OS == os && this.browser == browser)
					{
						isMobile = true;
					}
				}
			}
		},this);
		return isMobile;
	}
};
