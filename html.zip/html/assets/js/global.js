
// For embedded "legacy" simulations (pre-4.20). Must exist in global namespace.
var sendSimApi = function(simApi,title,totalToInclude,totalIncorrect,incStepNumberList)
{
	engine.controller.setStudentResponse(simApi,title,totalToInclude,totalIncorrect,incStepNumberList);
};

var $CONTENT = function (id, contentDocument)
{
    var contentDoc = null;
    if (contentDocument) {
        contentDoc = contentDocument;
    }
    else {
        contentDoc = (content.contentDocument || $("content").contentWindow.document);
    }
	return contentDoc.id(id);
}
