/**
* Class defining the user interface layer used by the engine controller
* @type {Object}
*/
var UIControl = function()
{
	this.transcriptOpen = false;
	this.menuOpen = false;
	this.historyOpen = false;
	this.resourceOpen = false;
	this.pageCount = 0;
	this.menuFocused = false;
	this.activeElement = null;
	this.contentFocused = true;
	this.iosAudioPromptOpen = false;
	this.audioControlsHidden = false;

	/**
	* Initializes the user interface layer
	* @method initialize
	*/
	this.initialize=function()
	{
		//Setup UI elements
		this.loadingMessage = $('loadingMessage');

		//this.header = $('header');
	    // nextContent to buffer next frame
		this.nextContent = $('nextContent');
		this.content = $('content');
	    // backContent to buffer back frame
		this.backContent = $('backContent');
	    // branching choice buffer frame
		this.choice1Content = $('choice1Content');
		this.choice2Content = $('choice2Content');
		this.choice3Content = $('choice3Content');
		this.choice4Content = $('choice4Content');

		//this.footer = $('footer');
		this.title = $('title');

		//this.breadcrumb = $('breadcrumb');
		this.breadcrumbText = $('breadcrumbText');
		this.pageNumber = $('pageNumber');
		this.pageTitle = $('pageTitle');

		this.progressText = $('progressText');
		this.progressBarBorder = $('progressBarBorder');
		this.progressBarFill = $('progressBarFill');

		this.menu = $('menu');
		this.menuHeader = $('menuHeader');
		this.menuContent = $('menuContent');
		
		this.history = $('history');
		this.historyHeader = $('historyHeader');
		this.historyContent = $('historyContent');
		
		this.resource = $('resource');
		this.resourceHeader = $('resourceHeader');
		this.resourceContent = $('resourceContent');
		
		this.transcript = $('transcript');
		this.transcriptContent = $('transcriptContent');
		this.transcriptText = $('transcriptText');
		this.transcriptHeaderText = $('transcriptHeaderText');

		this.audioPosition = $('audioPosition');
		this.audioControls = $('audioControls');
		
		this.skinObject = new BaseSkin();
		this.UI_TRANSCRIPT_HEIGHT = Utils.dom.getCurrentStyleAsNum(this.transcript,"height");
		
		//Cache titles atts
		$('transcriptBtn').set('label',$('transcriptBtn').getElements('a')[0].get('title'));
		$('menuBtn').set('label',$('menuBtn').getElements('a')[0].get('title'));
		$('historyBtn').set('label',$('historyBtn').getElements('a')[0].get('title'));
		$('nextBtn').set('label',$('nextBtn').getElements('a')[0].get('title'));
		$('backBtn').set('label',$('backBtn').getElements('a')[0].get('title'));
		$('resourcesBtn').set('label',$('resourcesBtn').getElements('a')[0].get('title'));
		$('audioStopBtn').set('label',$('audioStopBtn').getElements('a')[0].get('title'));
		$('audioPlayBtn').set('label',$('audioPlayBtn').getElements('a')[0].get('title'));
		$('audioPauseBtn').set('label',$('audioPauseBtn').getElements('a')[0].get('title'));

		//Cache tab indexes
		$('audioPlayBtn').set('tabidx',$('audioPlayBtn').getElements('a')[0].get('tabindex'));
		$('audioPauseBtn').set('tabidx',$('audioPauseBtn').getElements('a')[0].get('tabindex'));
		$('audioStopBtn').set('tabidx',$('audioStopBtn').getElements('a')[0].get('tabindex'));

		this.patchTitleClosed('transcriptBtn');
		this.patchTitleClosed('menuBtn');
		this.patchTitleClosed('historyBtn');
		this.patchTitleClosed('resourcesBtn');

		//Add spacebar support to UI buttons
		$('exitBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.displayExitPrompt();
			}
		});
		$('transcriptBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.ui.toggleTranscript();
			}
		});
		$('audioStopBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.controller.audioStop();
			}
		});
		$('audioPlayBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.controller.audioTogglePlay();
			}
		});
		$('audioPauseBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.controller.audioTogglePlay();
			}
		});
		$('audioDisableBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.controller.audioToggleEnabled();
			}
		});
		$('audioEnableBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.controller.audioToggleEnabled();
			}
		});

		this.skinObject.setClearTypeFix();
		
		this.sizeWindow();
		this.initializeLayout();
		
		//Let's ensure all elements are available and their style properties have been applied
		var self = this;
		setTimeout(function(){self.updateLayout();},100);
	};

	this.enableSpacebarAccess = function()
	{
		$('nextBtn').addEvent('keydown',function(e){
			if(!$('nextBtn').retrieve('enabled')){return;}
			if(e.key == 'space')
			{
				engine.controller.next();
			}
		});
		$('backBtn').addEvent('keydown',function(e){
			if(!$('backBtn').retrieve('enabled')){return;}
			if(e.key == 'space')
			{
				engine.controller.back();
			}
		});
		$('menuBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.ui.toggleMenu();
			}
		});
		$('historyBtn').addEvent('keydown',function(e){
			if(e.key == 'space')
			{
				engine.ui.toggleHistory();
			}
		});
	};

	this.disableSpacebarAccess = function()
	{
		$('nextBtn').removeEvents('keydown');
		$('backBtn').removeEvents('keydown');
		$('menuBtn').removeEvents('keydown');
		$('historyBtn').removeEvents('keydown');
	};

	/**
	* Size the window on initialization
	* @method sizeWindow
	*/
	this.sizeWindow=function()
	{
		if(Conf.WINDOW_CONTROL)
		{
			if(Conf.FULLSCREEN || !Utils.window.canFit(Conf.WINDOW_W,Conf.WINDOW_H))
			{
				var w = screen.availWidth;
				var h = screen.availHeight;
			}
			else
			{
				var w = Conf.WINDOW_W;
				var h = Conf.WINDOW_H;
			}

			try
			{
				if(Utils.window.isSameDomain('top'))
				{
					if(Conf.ZEROWIN || Conf.FULLSCREEN)
					{
						top.moveTo(0,0);
					}
					else
					{
						if(Utils.window.canFit(Conf.WINDOW_W,Conf.WINDOW_H))
						{
							var l = (screen.width) ? (screen.width-w)/2 : 0;
							var t = (screen.height) ? (screen.height-h)/2 : 0;
							top.moveTo(l,t);
						}
						else
						{
							top.moveTo(0,0);
						}
					}

					if(top.resizeTo)
					{
						top.resizeTo(w,h);
					}
					else if(document.layers)
					{
						top.outerWidth = w;
						top.outerHeight = h;
					}
					else if(window.outerWidth)
					{
						top.outerWidth = w;
						top.outerHeight = h;
					}

					top.focus();
				}
			}
			catch(e)
			{
				Utils.debug.trace('UI Error - Cannot resize or place window: '+(e.description || e),'error');
			}
			
		}
	};

	/**
	* Calls all update UI commands
	* @method updateInterface
	*/
	this.updateInterface=function()
	{
		this.updateBreadcrumbText();
		this.updateProgress();
	};

	/**
	* Updates the breadcrumb text (page location/total and page title)
	* @method updateBreadcrumbText
	*/
	this.updateBreadcrumbText=function()
	{
		var pageTotal = engine.controller.visiblePageTotal;
		var currPageNo = (engine.controller.branchingEnabled) ? engine.controller.currentPageObj.visibleIndex+1 : engine.controller.currentPageIndex+1;
		var currPageTitle = engine.controller.currentPageObj.title;

		var pageXofX = unescape(Lang.UI_LABEL_PAGE_NUMBER.replace('%s',currPageNo).replace('%t',pageTotal));

		var pageLocation = pageXofX+': ';
		Utils.dom.setOpacity(0,this.breadcrumbText.id);
		this.pageNumber.innerHTML = pageLocation;
		this.pageTitle.innerHTML = currPageTitle;
		//this.breadcrumbText.innerHTML = pageLocation+currPageTitle;
	};

	/**
	* Updates the progress bar and percentage label
	* @method updateProgress
	*/
	this.updateProgress=function()
	{
		var pageTotal = engine.controller.visiblePageTotal;
		var pageIdx = (engine.controller.branchingEnabled) ? engine.controller.currentPageObj.visibleIndex+1 : engine.controller.currentPageIndex+1;

		if(Conf.PROGRESS_BAR_MODE === 'PERCENTAGE_VISITED')
		{
			var viewedTotal = engine.controller.getTotalPagesVisited();
		}
		else
		{
			var viewedTotal = pageIdx;
		}
		
		var percentage = Math.round((viewedTotal/pageTotal)*100);
		if(Conf.RTLSupport)
			{
				this.progressText.innerHTML = '%' + percentage;
			}
		else
			{
			this.progressText.innerHTML = percentage+'%';
			}

		var borderWidth = Utils.dom.getCurrentStyleAsNum(this.progressBarBorder,"width");
		var curW = Utils.dom.getCurrentStyleAsNum(this.progressBarFill,"width");
		var newW = Math.round((viewedTotal/pageTotal)*borderWidth);
		if(curW != newW)
		{
			Utils.dom.animateTo(this.progressBarFill,'width',curW,newW,1000,'px');
		}
	};
	
	/**
	 * Hides the container of the progress-related elements
	 * @method hideProgress
	 */
	this.hideProgress = function()
	{
		Utils.dom.hide('progress');
	};
	
	/**
	 * Fires when the content frame has finished loading a content page
	 * @method contentLoaded
	 */
	this.contentLoaded = function()
	{
		Utils.dom.fadeIn(this.breadcrumbText,function(){
			Utils.dom.removeFilter($("breadcrumbText"));
		});
		this.audioUpdatePosition(0,0);
		try
		{
			if(engine.controller.currentPageObj.isPostAssessment && engine.controller.currentPageObj.assessment.inSummary)
			{
				if(this.transcriptOpen)
				{
					this.transcriptOpen = false;
					Utils.dom.hide('transcript');
					this.updateLayout();
				}
				Utils.dom.disableNavButtonById("transcriptBtn");
			}
			else
			{
				if(this.transcriptOpen)
				{
					Utils.dom.disableNavButtonById("transcriptBtn");
				}
				else
				{
					Utils.dom.enableNavButtonById("transcriptBtn");
				}
			}
		}
		catch(e){}
	};

	/**
	* Handles the resize event and updates the layout
	* @method handleResize
	*/
	this.handleResize=function()
	{
		this.updateLayout();
	};

	/**
	* Toggle the menu display
	* @method toggleMenu
	*/
	this.toggleMenu=function()
	{
		// Restrict access if navigation has been disabled
		if(!engine.controller.navEnabled){return;}
		
		//toggle menu
		this.menuOpen = !this.menuOpen;
		if(this.menuOpen)
		{
			this.renderMenu();
			this.showMenu();
		}
		else
		{
			this.hideMenu();
		}
	};
	
	/**
	* Toggle the history menu display
	* @method toggleHistory
	*/
	this.toggleHistory=function()
	{
		// Restrict access if navigation has been disabled
		if(!engine.controller.navEnabled){return;}
		
		//toggle menu
		this.historyOpen = !this.historyOpen;
		if(this.historyOpen)
		{
			this.renderHistory();
			this.showHistory();
		}
		else
		{
			this.hideHistory();
		}
	};
	
	/**
	* Toggle the resources display
	* @method toggleResource
	*/
	this.toggleResource=function()
	{
		// Restrict access if navigation has been disabled
		if(!engine.controller.navEnabled){return;}
		
		//toggle resource
		this.resourceOpen = !this.resourceOpen;
		if(this.resourceOpen)
		{
			this.renderResource();
			this.showResource();
		}
		else
		{
			this.hideResource();
		}
	};
	
	/**
	* Toggles the transcript pane display
	* @method toggleTranscript
	*/
	this.toggleTranscript=function()
	{
		if(engine.controller.currentPageObj.isPostAssessment && engine.controller.currentPageObj.assessment.inSummary){return;}
		//toggle transcript
		this.transcriptOpen = !this.transcriptOpen;
		if(this.transcriptOpen)
		{
			this.renderTranscript();
			this.showTranscript();
		}
		else
		{
			this.hideTranscript();
		}
	};
	
	/**
	* Renders the contents of the transcript pane
	* @method renderTranscript
	*/
	this.renderTranscript=function()
	{
		if(engine.controller.currentPageObj.isPostAssessment && engine.controller.inAssessmentMode)
		{
			engine.controller.currentPageObj.assessment.renderTranscript();
		}
		else
		{
			this.transcriptHeaderText.innerHTML = unescape(Lang.UI_LABEL_TRANSCRIPT)+": " + unescape(engine.controller.currentPageObj.title);
			this.transcriptText.innerHTML = Utils.string.replaceChars(engine.controller.currentPageObj.transcript);
			if(Utils.browserDetection.isMobile())
			{				
				if (transcriptScroller !== null && typeof transcriptScroller !== "undefined") {
					transcriptScroller.scrollTo(0, 0);
				} else {
					transcriptScroller = new iScroll('transcriptContent');					
				}
				
				setTimeout(function(){transcriptScroller.refresh();},0);
			}
		}
	};
	
	/**
	* Shows the transcript pane
	* @method showTranscript
	*/
	this.showTranscript=function()
	{
        if(Utils.browserDetection.browser == "ie")
        {
            var contentFrame = window.frames.content;
            if(contentFrame.flashObj)
            {
                contentFrame.flashObj.style.visibility = "hidden";
            }
        }
        if(Utils.browserDetection.browser != "firefox")
        {
            var contentFrame = window.frames.content;
            if(contentFrame.videoContainer)
            {
                contentFrame.videoContainer.style.visibility = "hidden";
            }
        }
		Utils.dom.disableNavButtonById("transcriptBtn");
		this.patchTitleOpen('transcriptBtn');
		Utils.dom.show('transcript');
		Utils.dom.fadeIn(this.transcriptContent,function(){
			Utils.dom.removeFilter($("transcriptContent"));
		});
		this.updateLayout();
		this.skinObject.refreshTranscript();
	};
	
	/**
	* Hides the transcript pane
	* @method hideTranscript
	*/
	this.hideTranscript=function()
	{
        if(Utils.browserDetection.browser == "ie")
        {
            var contentFrame = window.frames.content;
            if(contentFrame.flashObj)
            {
                contentFrame.flashObj.style.visibility = "visible";
            }
        }
        if(Utils.browserDetection.browser != "firefox")
        {
            var contentFrame = window.frames.content;
            if(contentFrame.videoContainer)
            {
                contentFrame.videoContainer.style.visibility = "visible";
            }
        }
		Utils.dom.enableNavButtonById("transcriptBtn");
		this.patchTitleClosed('transcriptBtn');
		Utils.dom.hide('transcript');
		this.updateLayout();
	};

	/**
	* Shows the menu (and hides the history, if open)
	* @method showMenu
	*/
	this.showMenu=function()
	{
		if(this.historyOpen)
		{
			this.hideHistory();
		}
		if (this.resourceOpen)
		{
			this.hideResource();
		}
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "hidden";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "hidden";
			}
		}
		this.menuOpen = true;
		Utils.dom.disableAuxButtonById("menuBtn");
		Utils.dom.setOpacity(0, "menuContent");
		Utils.dom.setOpacity(0, "menu");
		Utils.dom.show('menu');
		this.patchTitleOpen('menuBtn');
		
		Utils.dom.fadeIn(this.menu,function(){
			Utils.dom.removeFilter($("menu"));
		});
		Utils.dom.animateTo(this.menu,'left',-20,Conf.UI_MARGIN,500,'px',function(){
			Utils.dom.fadeIn($('menuContent'),function(){
				Utils.dom.removeFilter($("menuContent"));
				var menuItems = $$('#menuContent li');
				menuItems[0].focus();
			})
		});
	};

	/**
	* Hides the menu
	* @method showMenu
	*/
	this.hideMenu=function()
	{
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "visible";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "visible";
			}
		}
		this.menuFocused = false;
		this.focusNextBtn();
		this.menuOpen = false;
		Utils.dom.enableAuxButtonById("menuBtn");
		Utils.dom.removeFilter($("menuBtn"));
		this.patchTitleClosed('menuBtn');

		Utils.dom.fadeOut(this.menu);
		Utils.dom.animateTo(this.menu,'left',Conf.UI_MARGIN,-20,500,'px',function(){
			Utils.dom.hide('menu')
		});
	};

	/**
	* Renders the menu if it is open
	* @method renderMenu
	*/
	this.renderMenu=function()
	{
		if(this.menuOpen)
		{
			this.pageCount = 0;
			
			var menuHTML = engine.root.cascadePage();
			this.menuContent.innerHTML = '<ul role="tree">'+menuHTML+'</ul>';
			if(Utils.browserDetection.isMobile())
			{
				if (menuScroller == null || typeof menuscroller=="undefined") {
					menuScroller = new iScroll('menuContent', {useTransform: false});
				}
				if(Conf.RTLSupport)
				{
					try {
						$(this.menuContent.children[0]).setStyle('right', 0);
					} catch (err){}
				}
				setTimeout(function(){menuScroller.refresh();},0);
			}
		}
	};
	
	/**
	* Shows the history (and hides the menu, if open)
	* @method showHistory
	*/
	this.showHistory=function()
	{
		if(this.menuOpen)
		{
			this.hideMenu();
		}
		if (this.resourceOpen)
		{
			this.hideResource();
		}
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "hidden";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "hidden";
			}
		}
		this.historyOpen = true;
		Utils.dom.disableAuxButtonById("historyBtn");
		Utils.dom.setOpacity(0, "historyContent");
		Utils.dom.show('history');
		this.patchTitleOpen('historyBtn');
		
		Utils.dom.fadeIn(this.history,function(){
			Utils.dom.removeFilter($("history"));
		});
		Utils.dom.animateTo(this.history,'left',-20,Conf.UI_MARGIN,500,'px',function(){
			Utils.dom.fadeIn($('historyContent'),function(){
				Utils.dom.removeFilter($("historyContent"));
				var menuItems = $$('#historyContent li');
				menuItems[0].focus();
			})
		});
	};

	/**
	* Hides the history
	* @method hideHistory
	*/
	this.hideHistory=function()
	{
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "visible";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "visible";
			}
		}
		this.menuFocused = false;
		this.focusNextBtn();
		Utils.dom.enableAuxButtonById("historyBtn");
		Utils.dom.removeFilter($("historyBtn"));
		this.historyOpen = false;
		this.patchTitleClosed('historyBtn');

		Utils.dom.fadeOut(this.history);
		Utils.dom.animateTo(this.history,'left',Conf.UI_MARGIN,-20,500,'px',function(){
			Utils.dom.hide('history')
		});
	};

	/**
	* Renders the history if it is open
	* @method renderHistory
	*/
	this.renderHistory=function()
	{
		if(this.historyOpen)
		{
			this.pageCount = 0;
			
			var historyHTML = engine.controller.getHistoryHTML();
			this.historyContent.innerHTML = "<ul>"+historyHTML+"</ul>";
			if(Utils.browserDetection.isMobile())
			{
				historyScroller = new iScroll('historyContent');
				setTimeout(function(){historyScroller.refresh();},0);
			}
		}
	};
	
	/**
	* Shows the resource panel (and hides the menu, if open)
	* @method showResource
	*/
	this.showResource=function()
	{
		if(this.menuOpen)
		{
			this.hideMenu();
		}
		if(this.historyOpen)
		{
			this.hideHistory();
		}
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "hidden";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "hidden";
			}
		}
		this.resourceOpen = true;
		Utils.dom.disableAuxButtonById("resourcesBtn");
		Utils.dom.setOpacity(0, "resourceContent");
		Utils.dom.show('resource');
		this.patchTitleOpen('resourcesBtn');
		
		Utils.dom.fadeIn(this.resource,function(){
			Utils.dom.removeFilter($("resource"));
		});
		Utils.dom.animateTo(this.resource,'left',-20,Conf.UI_MARGIN,500,'px',function(){
			Utils.dom.fadeIn($('resourceContent'),function(){
				Utils.dom.removeFilter($("resourceContent"));
				var resourceItems = $$('#resourceContent li');
				if ($chk($(resourceItems))){
					resourceItems[0].focus();
				}
			})
		});
	};

	/**
	* Hides the resource panel
	* @method hideResource
	*/
	this.hideResource=function()
	{
		if(Utils.browserDetection.browser == "ie")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.flashObj)
			{
				contentFrame.flashObj.style.visibility = "visible";
			}
		}
		if(Utils.browserDetection.browser != "firefox")
		{
			var contentFrame = window.frames.content;
			if(contentFrame.videoContainer)
			{
				contentFrame.videoContainer.style.visibility = "visible";
			}
		}
		this.menuFocused = false;
		this.focusNextBtn();
		Utils.dom.enableAuxButtonById("resourcesBtn");
		Utils.dom.removeFilter($("resourcesBtn"));
		this.resourceOpen = false;
		this.patchTitleClosed('resourcesBtn');

		Utils.dom.fadeOut(this.resource);
		Utils.dom.animateTo(this.resource,'left',Conf.UI_MARGIN,-20,500,'px',function(){
			Utils.dom.hide('resource')
		});
	};
	
	/**
	* Renders the resource if it is open
	* @method renderResource
	*/
	this.renderResource=function()
	{
		if(this.resourceOpen)
		{
			var resourceHTML = engine.controller.getResourceHTML();
			this.resourceContent.innerHTML = '<ul class="resourceContent" role="tree">'+resourceHTML+'</ul>';
			if(Utils.browserDetection.isMobile())
			{
				resourceScroller = new iScroll('resourceContent');
				setTimeout(function(){resourceScroller.refresh();},0);
			}
		}
	};
	
	/**
	* Hides the audio controls container
	* @method hideAudioControls
	*/
	this.hideAudioControls=function()
	{
		this.audioControlsHidden = true;
		Utils.dom.hide('audioControls');
	};

	/**
	* Shows the audio controls container
	* @method showAudioControls
	*/
	this.showAudioControls=function()
	{
		this.audioControlsHidden = false;
		Utils.dom.show('audioControls');
	};

	/**
	* Fades the loading message out or hides it immediately
	* @method fadeOutLoadingMessage
	*/
	this.fadeOutLoadingMessage = function()
	{
		Utils.dom.fadeOut(this.loadingMessage,function(){
			Utils.dom.hide('loadingMessage');
		});
	};
	
	/**
	* Collapses all menu element folders and re-render the menu
	* @method menuCollapseAll
	*/
	this.menuCollapseAll=function()
	{
		engine.root.closeChildFolders();
		engine.ui.renderMenu();
	};

	/**
	* Expands all menu element folders and re-render the menu
	* @method menuExpandAll
	*/
	this.menuExpandAll=function()
	{
		engine.root.openChildFolders();
		engine.ui.renderMenu();
	};
	
	/**
	* Initializes the layout - Only done on engine load
	* @method initializeLayout
	*/
	this.initializeLayout=function()
	{
		if(!Conf.ENABLE_HELP_BUTTON){Utils.dom.hide('helpBtn');}
		if(!Conf.ENABLE_RESOURCES_BUTTON){Utils.dom.hide('resourcesBtn');}
		if(!Conf.ENABLE_GLOSSARY_BUTTON){Utils.dom.hide('glossaryBtn');}
		if(!Conf.ENABLE_EXIT_BUTTON){Utils.dom.hide('exitBtn');}
		if(!Conf.ENABLE_MENU_BUTTON){Utils.dom.hide('menuBtn');}
		if(!Conf.ENABLE_HISTORY_BUTTON){Utils.dom.hide('historyBtn');}
		if(!Conf.ENABLE_NEXT_BUTTON){Utils.dom.hide('nextBtn');}
		if(!Conf.ENABLE_BACK_BUTTON){Utils.dom.hide('backBtn');}

		// Display the debugger link if it is enabled.
		if(Conf.ENABLE_DEBUGGER){this.showDebugOption();}
		// Display the reviewer/comment link if it is enabled.
		if(Conf.ENABLE_COMMENTS){this.showCommentOption();}
		
		this.title.innerHTML = unescape(engine.courseTitle);

		this.skinObject.setInitHeader();

		this.skinObject.setInitFooter();
		
		this.skinObject.setInitTranscript(this.UI_TRANSCRIPT_HEIGHT);
				
		this.skinObject.setInitBreadCrumb();
		
		this.skinObject.setInitContent();
		
		try {
			var menuOpacity = $('menuBtn').getStyle('opacity')*100;
			this.opacityValue = menuOpacity;
		} catch(e) {
			// set default value
			this.opacityValue = 100;
		}
				
		this.skinObject.setInitMenu();
		
		this.skinObject.setInitHistory();

		this.skinObject.setInitResource();

		Utils.debug.trace('initialized layout');
	};

	/**
	* Update the layout
	* @method updateLayout
	*/
	this.updateLayout=function()
	{
		var viewWidth = (document.documentElement.clientWidth) ? document.documentElement.clientWidth : window.innerWidth;
		var viewHeight = (document.documentElement.clientHeight) ? document.documentElement.clientHeight : window.innerHeight;

		if(!viewWidth || !viewHeight)
		{
			return;
		}
		
		//dialog
		engine.dialog.updateLayout(viewWidth,viewHeight);
		
		if(this.transcriptOpen)
		{
			var transcriptHeight = this.UI_TRANSCRIPT_HEIGHT;
		}
		else
		{
			var transcriptHeight = 0;
		}
					
		this.skinObject.setHeader(viewWidth);
		//The additional 10 Pixel subtration is for the "left" margin we create in the template.
		var titlewidth = parseInt($('header').getStyle('width')) - parseInt($('logo').getStyle('width'))-10;
		$('title').setStyle('width', titlewidth);
		
		this.skinObject.setBreadcrumb(viewWidth);
		
		this.skinObject.setTranscript(viewWidth);
		
		this.skinObject.setFooter(viewWidth, viewHeight);
		
		this.skinObject.setRound(viewWidth, viewHeight);

		this.skinObject.setContent(transcriptHeight, viewWidth, viewHeight);

		this.skinObject.setMenu();
		
		this.skinObject.setHistory();
		
		this.skinObject.setResource();
		
		this.skinObject.checkBrowserVersion();
		
		if(Utils.browserDetection.isMobile())
		{
			setTimeout(function(){if(historyScroller){historyScroller.refresh();}},0);
			setTimeout(function(){if(menuScroller){menuScroller.refresh();}},0);
			setTimeout(function(){if(transcriptScroller){transcriptScroller.refresh();}},0);
			setTimeout(function(){if(contentScroller){contentScroller.refresh();}},0);
		}
		
		this.showMenuOnload();
	};

	this.showMenuOnload = function(){
		if (Conf.ENABLE_MENU_BUTTON && Conf.MENU_DISPLAY_ONLOAD == "collapsed"){
			this.menuOpen = true;
			this.renderMenu();
			this.showMenu();
		}
		else if (Conf.ENABLE_MENU_BUTTON && Conf.MENU_DISPLAY_ONLOAD == "expanded"){
			this.menuOpen = true;
			this.menuExpandAll();
			this.renderMenu();
			this.showMenu();
		} else {
			this.menuOpen = false;
		}
	};
	
	/**
	* Show the debug button
	* @method showDebugOption
	*/
	this.showDebugOption=function()
	{
		var divTag = document.createElement("div");
		divTag.id = "debugLink";
		document.body.appendChild(divTag);
		Utils.dom.renderHTML('debugLink','<a href="#" onclick="Utils.debug.show();return false;" title="Debug Console"><img src="assets/img/debug.gif" width="20" height"20" border="0" tabindex="-1" aria-hidden="true"></a>');
	};

	/**
	* Show the reviewer/comments button
	* @method showCommentOption
	*/
	this.showCommentOption=function()
	{
		var divTag = document.createElement("div");
		divTag.id = "commentLink";
		document.body.appendChild(divTag);
		Utils.dom.renderHTML('commentLink','<a href="#" onclick="Utils.comment.show();return false;" title="Comment"><img src="assets/img/comment.gif" width="20" height"20" border="0"></a>');
	};

	/**
	* Update the audio position/duration string
	* @method audioUpdatePosition
	*/
	this.audioUpdatePosition=function(pos,dur)
	{
		var posStr = this.formatSeconds(pos);
		var durStr = this.formatSeconds(dur);
		var strPosDur = posStr + " / " + durStr;
		if(strPosDur.indexOf("NaN") < 0)
		{
			Utils.dom.renderHTML('audioPosition',strPosDur);
		}
	};

	/**
	* Format the total seconds to something meaningful in the UI (00:00)
	* @method formatSeconds
	*/
	this.formatSeconds=function(seconds)
	{
		var min = Math.floor(seconds/60);
		var sec = Math.floor(seconds)%60;
		if(min < 10)
		{
			min = "0"+min;
		}
		if(sec < 10)
		{
			sec = "0"+sec;
		}
		
		return min+":"+sec;
	};
	
	/**
	* Handle the page navigation event at the UI level
	* @method onGoToPage
	*/
	this.onGoToPage=function()
	{
	    // turn off all videos if there is any
	    var videos = this.content.contentDocument.getElementsByTagName('video');
	    for (i = videos.length - 1; i >= 0; i--) {
	        var video = videos[i];
	        if ($chk(video)) {
	            video.pause();
	            video.destroy();
	        }
	    }

	    // Clear the videos as in controller
	    try {
	        engine.controller.clearVideos(true);
	    }
	    catch (ex) {
	        // do nothing - if the video still playing, check another case
	    }

	    // turn off al flash if there is any
	    var flashObj = this.content.contentDocument.flashObj;
	    if (flashObj) {
	        flashObj.destroy();
	    }

	    // If the menu is open, close it
		if(this.menuOpen)
		{
			this.hideMenu();
		}
		
		// If the history menu is open, close it
		if(this.historyOpen)
		{
			this.hideHistory();
		}

		// If the resource panel is open, close it
		if(this.resourceOpen)
		{
			this.hideResource();
		}

		// If the transcript is open, refresh its content
		if(this.transcriptOpen)
		{
			this.renderTranscript();
		}

		if(this.iosAudioPromptOpen)
		{
			this.hideEnablePlaybackPrompt();
		}

		this.updateInterface();

		this.focusNextBtn();
		
		this.contentFocused = false;
		
		window.frames.content.focus();
	};

	this.handleKeyDownEvent=function(e)
	{
		var k = e.keyCode;

		switch(k)
		{
			case 77: // m = 77
				if(e.ctrlKey && this.contentFocused)
				{
					return;
				}
				this.toggleMenu();
				break;
			case 72: // h = 72
				this.toggleHistory();
				break;
			case 82: // r = 82
				this.toggleResource();
				break;
			case 84: // t = 84
				this.toggleTranscript();
				break;
			case 27: // Esc = 27
				engine.displayExitPrompt();
				break;
			case 39: // Right Arrow = 39
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						this.openActiveMenuPage();
						return EventHandler.killEvent(e);
					}
				}
				//else
				//{
					//engine.controller.next();
				//}
				break;
			case 37: // Left Arrow = 37
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						this.closeActiveMenuPage();
						return EventHandler.killEvent(e);
					}
				}
				else
				{
					engine.controller.back();
				}
				break;
			case 38: // Up Arrow = 38
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						this.focusPreviousMenuElement();
					}
					else if(this.historyOpen)
					{
						this.focusPreviousHistoryElement();
					}
					return EventHandler.killEvent(e);
				}
				break;
			case 40: // Down Arrow = 40
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						this.focusNextMenuElement();
					}
					else if(this.historyOpen)
					{
						this.focusNextHistoryElement();
					}
					return EventHandler.killEvent(e);
				}
				break;
			case 13: // Enter = 13
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						engine.controller.gotoPageByName(this.activeElement.getAttribute('pageName'));
						return EventHandler.killEvent(e);
					}
					else if(this.historyOpen)
					{
						engine.controller.gotoPageByNameFromHistory(this.activeElement.getAttribute('pageName'),this.activeElement.getAttribute('historyIndex'));
						return EventHandler.killEvent(e);
					}
					else if (this.resourceOpen)
					{
						engine.controller.goToResourceByName(this.activeElement.getAttribute('resourceName'));
						return EventHandler.killEvent(e);
				}
				}
				break;
			case 32: // Space = 32
				if(this.menuFocused)
				{
					if(this.menuOpen)
					{
						engine.controller.gotoPageByName(this.activeElement.getAttribute('pageName'));
						return EventHandler.killEvent(e);
					}
					else if(this.historyOpen)
					{
						engine.controller.gotoPageByNameFromHistory(this.activeElement.getAttribute('pageName'),this.activeElement.getAttribute('historyIndex'));
						return EventHandler.killEvent(e);
					}
					else if (this.resourceOpen)
					{
						engine.controller.goToResourceByName(this.activeElement.getAttribute('resourceName'));
						return EventHandler.killEvent(e);
				}
				}
				break;
			case 9: // Tab = 9
				Utils.debug.trace(this.menuFocused);
				if(!this.menuFocused)
				{
					if(e.ctrlKey && e.shiftKey)
					{
						window.frames.content.focus();
						this.contentFocused = true;
						return EventHandler.killEvent(e);
					}
				}
				break;
		}
	};

	this.setMenuFocused=function(focused,el)
	{
		this.menuFocused = focused;
		this.activeElement = el;
	};

	this.openActiveMenuPage=function()
	{
		if(!this.activeElement){return;}
		var page = engine.controller.getPageByName(this.activeElement.getAttribute('pageName'));
		if(page.isNormalFolder() && page.parent)
		{
			page.openPage(true);
		}
		$(page.name + '_li').focus();
	};

	this.closeActiveMenuPage=function()
	{
		if(!this.activeElement){return;}
		var page = engine.controller.getPageByName(this.activeElement.getAttribute('pageName'));
		if(page.isNormalFolder() && page.parent)
		{
			page.closePage(true);
		}
		$(page.name + '_li').focus();
	};

	this.focusPreviousMenuElement=function()
	{
		var items = $$('#menuContent li');
		var idx = this.getMenuElementIndex(this.activeElement.getAttribute('pageName'));
		if(idx > 0)
		{
			prevEl = items[idx-1];
		}

		if(prevEl)
		{
			prevEl.focus();
		}
	};

	this.focusNextMenuElement=function()
	{
		var items = $$('#menuContent li');
		var idx = this.getMenuElementIndex(this.activeElement.getAttribute('pageName'));
		if(idx < items.length)
		{
			nextEl = items[idx+1];
		}

		if(nextEl)
		{
			nextEl.focus();
		}
	};

	this.getMenuElementIndex=function(pageName)
	{
		var items = $$('#menuContent li');
		for(var i=0;i<items.length;i++)
		{
			if(items[i].id == pageName+'_li')
			{
				return i;
			}
		}
		return false;
	};
	
	this.focusPreviousHistoryElement=function()
	{
		var items = $$('#historyContent li');
		var idx = this.activeElement.getAttribute('historyIndex');
		if(idx > 0)
		{
			prevEl = items[parseInt(idx)-1];
		}
		if(prevEl)
		{
			prevEl.focus();
		}
	};

	this.focusNextHistoryElement=function()
	{
		var items = $$('#historyContent li');
		var idx = this.activeElement.getAttribute('historyIndex');
		if(idx < items.length)
		{
			nextEl = items[parseInt(idx)+1];
		}
		if(nextEl)
		{
			nextEl.focus();
		}
	};

	this.focusNextBtn=function()
	{
		// We might be running in the editor, where the Next button is hidden
		if($('nextBtn').getStyle('display') != 'none')
		{
			$('nextBtnLink').focus();
		}
	};

	this.skipMenu=function()
	{
		$('nextBtnLink').focus();
		this.menuFocused = false;
		this.contentFocused = false;
	};

	this.showEnablePlaybackPrompt=function()
	{
		if(!this.iosAudioPromptOpen)
		{
			$('iosAudioPrompt').show();
			this.iosAudioPromptOpen = true;
		}
	};

	this.hideEnablePlaybackPrompt=function()
	{
		if(this.iosAudioPromptOpen)
		{
			$('iosAudioPrompt').hide();
			this.iosAudioPromptOpen = false;
		}
	};

	this.patchTitleOpen=function(id)
	{
		var a = $(id).getElements('a')[0];
		a.set('title',$(id).get('label')+'-'+Lang.ACCESSIBILITY_OPEN);
	};

	this.patchTitleClosed=function(id)
	{
		var a = $(id).getElements('a')[0];
		a.set('title',$(id).get('label')+'-'+Lang.ACCESSIBILITY_CLOSED);
	};

	this.patchTitleOn=function(id)
	{
		var a = $(id).getElements('a')[0];
		a.set('title',$(id).get('label')+'-'+Lang.ACCESSIBILITY_ON);
	};

	this.patchTitleOff=function(id)
	{
		var a = $(id).getElements('a')[0];
		a.set('title',$(id).get('label')+'-'+Lang.ACCESSIBILITY_OFF);
	};

	this.removeFromTabChain=function(el)
	{
		el.getElements('a')[0].setAttribute('tabindex',-1);
	};

	this.resetTabIndex=function(el)
	{
		var idx = el.get('tabidx');
		el.getElements('a')[0].setAttribute('tabindex',idx);
	};

	this.disableTransitions=function()
	{
		Conf.ENABLE_TRANSITIONS = false;
	};
};
