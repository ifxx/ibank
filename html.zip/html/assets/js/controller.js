/**
 * Class defining the navigation/interface control layer used by the engine
 * @requires Engine
 * @requires Utils
 */
function Controller()
{
    this.isClickOnMenuBar = false;
    this.currentPageObj = null;
    this.currentPageIndex = 0;
    this.pageList = [];
    this.pageTotal = 0;
    this.navEnabled = true;
    this.inAssessmentMode = false;
    this.audioEnabled = true;
    this.history = [];
    this.resources = [];
    this.suspendDataObj = {};
    this.suspendDataObj.courseState = null;
    this.suspendDataObj.history = null;
    this.suspendDataObj.assessmentState = null;
    this.hasAssessment = false;
    this.isMuted = false;
    this.branchingEnabled = false;
    this.completeOnAllPagesVisited = true;
    this.completionThreshold = -1;
    this.nextPageNameToGoAfterAnimation = "";
    this.skipPlayTransitionTime = 0;
    this.pauseCookieChecker = true;
    this.completionStrings = {
        'completed':Conf.COMPLETION_STRING.split("_")[0],
        'incomplete':Conf.COMPLETION_STRING.split("_")[1]
    };
    
    /**
     * Initialize the navigation control layer
     * @method initialize
     */
    this.initialize = function()
    {
        this.pageTotal = this.visiblePageTotal = this.pageList.length;
        
        // Set the default status of this lesson if this is the user's first entry
        var status = engine.comm.getCompletionStatus();
        if(status.toLowerCase().charAt(0) == 'n' || 
            status.toLowerCase().charAt(0) == 'u' || 
            status == 'undefined' || 
            status == null || 
            status == '' || 
            status == 'null')
        {
            engine.comm.setCompletionStatus('incomplete');
        }
        
        // Reset the course page status/states based on the persisted Comm object data
        var suspend_data = engine.comm.getSuspendData();
        if(suspend_data != null && suspend_data != 'null' && suspend_data != '')
        {
            // Parse the suspend_data into a native JS object to manipulate during this session 
            this.suspendDataObj = JSON.decode(suspend_data);
            
            // If this course's page total is the same length as the persisted courseState,
            // no change has been made to the structure since the previous session.
            // If any changes have been made, we cannot ensure a safe reset of the course. 
            var state = Utils.string.decodeState(this.suspendDataObj.courseState);
            if(this.pageTotal == state.length)
            {
                if(this.suspendDataObj.courseState)
                {
                    this.resetCourseState(state);
                }
                if(this.suspendDataObj.history)
                {
                    this.resetHistoryState(this.suspendDataObj.history);
                }
            }
        }
        
        // Do checks for existing lesson location data, setting a default, "just in case".
        var pageName = engine.root.name;
        
        try
        {
            this.startPage = engine.searchparams['uperform_startpage'];
        }
        catch(e){}

        // Just in case we're running in a mobile environment
        if(Utils.browserDetection.isMobile())
        {
            this.startPage = Utils.window.getMobileSimPageName();
        }

        // If the course has been passed a startPage param, try to use it
        if(this.startPage)
        {
            // If the startPage param is valid, use it.  Otherwise, the default is the root.
            var pageName = (this.getPageByName(this.startPage)) ? this.startPage : engine.root.name;
        }
        else 
        {
            // If the Comm object can return a starting page name, prompt the user to use it.  Otherwise, the default is the root.
            var location = engine.comm.getLocation();
            
            // If the location is valid, and it isn't the root, prompt the user.  Otherwise, the default is the root.
            var pageObj = this.getPageByName(location);
            if(pageObj && (pageObj != engine.root) && (pageObj != this.getLastPage()))
            {
                // Fix the page title we read in to ensure we can write it into the prompt without issue.
                pageName = null;
                var fixedTitle = new String(pageObj.title).replace(/&quot;/g,'"');
                fixedTitle = Utils.dom.convertPageTitle(fixedTitle);
                var o={};
                o.scope = this;
                o.label = unescape(fixedTitle);
                o.txt = '<p>'+unescape(Lang.RETURN_TO_LAST_LOCATION)+'<br><br>'+fixedTitle+'</p>';
                o.onOk = function(){
                    engine.controller.gotoPageByName(location);
                };
                o.onCancel=function(){
                    engine.controller.gotoPageByName(engine.root.name);
                };
                engine.dialog.confirm(o);
            }
            else
            {
                // Default to the first page... why not?
                pageName = engine.root.name;
            }
        }
        
        // Should we enable branching mode?
        if(this.hasBranches())
        {
            this.branchingEnabled = true;
            this.next = this.nextBranching;
            this.back = this.backBranching;
            this.visiblePageTotal = this.updatePageTotalAndVisibleIndexes();
        }
        else
        {
            this.next = this.nextLinear;
            this.back = this.backLinear;
        }
        
        // If branching is present, or there is only one page, hide the progress
        if(this.pageTotal == 1)
        {
            engine.ui.hideProgress();
        }

        engine.ui.enableSpacebarAccess();
        $('nextBtn').store('enabled',true);
        $('backBtn').store('enabled',true);
        
        this.validateThreshold();
        
        // Should the course be marked completed once all pages have been viewed?
        // If there is a post-assessment, we should base completion on the user's performance.
        // If branching is enabled, we cannot guarantee that all pages will be visited.
        this.completeOnAllPagesVisited = (this.hasPostAssessment() || this.branchingEnabled) ? false : true;
        this.setAssessmentState();
        
        // Finally, load the correct page.
        if (pageName != null){
            this.gotoPageByName(pageName);
        }

        if(window.parent != undefined && !((window.parent.location.protocol).contains("file")) && (window.parent.location.href).contains('ucontent'))
        {
            console.log('Running From uPServer');
            setInterval(function(){this.checkCookie;},100);
			this.pauseCookieChecker = false;
        }
        else
        {
            console.log('Not running from uPServer');
            this.pauseCookieChecker = true;
        }
        
        engine.ui.fadeOutLoadingMessage();
    };
    
  	this.checkCookie = function()
	{		
		if(this.pauseCookieChecker)
		{
			return;
		}
		var theCookie = document.cookie;
		var theResponse = "";
		if(!theCookie.contains("uPerformInfoToken"))
		{	
			console.log('No cookie found.');
			this.pauseCookieChecker = true;
			var xhttp = new XMLHttpRequest();
			xhttpError = false;
			xhttp.open("GET","/gm/?",false);
			try
			{
				xhttp.send();				
				theResponse = xhttp.reponseText;
				xhttpError = false;
			}
			catch(err)
			{
				xhttpError = true;
				this.openCookieRefreshWindow();
			}

			
			if(xhttpError == false && theResponse.contains("SAMLResponse"))
			{					
				postLocationStart = theResponse.indexOf('action="') + 8;
				postLocationEnd = theResponse.indexOf('"',postLocationStart);
				postLocation = theResponse.substring(postLocationStart,postLocationEnd);
				//Make sure this is the response intended for uPerform
				if(postLocation.contains('/gm/consume'))
				{
					ResponseInputPosition = theResponse.indexOf('<input');
					ResponseNamePosition = theResponse.indexOf('name',ResponseInputPosition);
					ResponsePositionElement = theResponse.substring(ResponseInputPosition,ResponseNamePosition + 21);
					ResponseInputPosition2 = theResponse.indexOf('<input',ResponseNamePosition);
					ResponseNamePosition2 = theResponse.indexOf('name',ResponseInputPosition2);
					ResponsePositionElement2 = theResponse.substring(ResponseInputPosition2,ResponseNamePosition2 + 21);				
					if(ResponsePositionElement.contains('SAMLRes'))
					{
						SAMLResponseStart = theResponse.indexOf('value',ResponseInputPosition) + 7;
						SAMLResponseEnd = theResponse.indexOf('"',SAMLResponseStart);
						tempSAMLResponse = theResponse.substring(SAMLResponseStart,SAMLResponseEnd);
						SAMLResponse = tempSAMLResponse.replace(/\+/gi,'%2B')
					}
					else
					{
						RelayStateStart = theResponse.indexOf('value',ResponseInputPosition) + 7;
						RelayStateEnd = theResponse.indexOf('"',RelayStateStart);
						RelayState = theResponse.substring(RelayStateStart,RelayStateEnd);
					}					
					if(ResponsePositionElement2.contains('SAMLRes'))
					{
						SAMLResponseStart = theResponse.indexOf('value',ResponseInputPosition2) + 7;
						SAMLResponseEnd = theResponse.indexOf('"',SAMLResponseStart);
						tempSAMLResponse = theResponse.substring(SAMLResponseStart,SAMLResponseEnd);
						SAMLResponse = tempSAMLResponse.replace(/\+/gi,'%2B')
					}
					else
					{
						RelayStateStart = theResponse.indexOf('value',ResponseInputPosition2) + 7;
						RelayStateEnd = theResponse.indexOf('"',RelayStateStart);
						RelayState = theResponse.substring(RelayStateStart,RelayStateEnd);
					}
					samlFormData = 'SAMLResponse=' + SAMLResponse + '&RelayState=' + RelayState;			
					xhttp.open("POST", postLocation,false);
					xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
					xhttp.setRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
					xhttp.setRequestHeader("Upgrade-Insecure-Requests", "1");
					xhttp.setRequestHeader("Cache-Control","max-age=0");
					xhttp.send(samlFormData);
					if (xhttp.readyState == 4 && xhttp.status == 200) 
					{
						this.pauseCookieChecker = false;			
					}						
				}
				else
				{
					console.log('I see a SAML response, but it is not for uPerform.')							
					this.openCookieRefreshWindow();
				}				
			}
			else
			{
				if(xhttpError == true)
				{
					this.openCookieRefreshWindow();
				}
				else
				{
					alert('Session Expired. Upon closing this message, a new login window will appear. After logging in, press the play button to resume playback.');
					idpWindow = window.open('/gm/?','Login Required','width=1024,height=768');
				}
			}	
		}		
	};
	
	this.openCookieRefreshWindow = function()
	{
		console.log('Open Refresh fired');
		authWindow = window.open('/gm/','CookieRefresh','width=100,height=100');
		theTimer = setTimeout(function(){this.closeCookieRefreshWindow;},3000);	
	};
	
	this.closeCookieRefreshWindow = function()
	{
		console.log('close refresh fired');
		clearTimeout(theTimer);
		this.pauseCookieChecker = false;
		window.parent.focus();
	};
    
    this.hasBranches = function()
    {
        for(var i=0;i<this.pageList.length;i++)
        {
            if(this.pageList[i].isBranch)
            {
                return true;
            }
        }
        return false;
    };

    this.hasAudio = function()
    {
        for(var i=0;i<this.pageList.length;i++)
        {
            var p = this.pageList[i];
            if((p.audio !== "") && (p.audio != null))
            {
                return true;
            }
            if(p.isAssessment)
            {
                for(var j=0;j<p.assessment.questions.length;j++)
                {
                    var q = p.assessment.questions[j];
                    if((q.audio !== "") && (q.audio != null))
                    {
                        return true;
                    }
                }
            }
        }

        Utils.debug.trace('Course does not have audio');
        return false;
    };

    this.hasFlashAudio = function()
    {
        for(var i=0;i<this.pageList.length;i++)
        {
            var p = this.pageList[i];
            if((p.audio !== "") && (p.audio != null))
            {
                var ext = p.audio.substring(p.audio.lastIndexOf(".")+1).toLowerCase();
                if(ext == "swf")
                {
                    return true;
                }
            }
            if(p.isAssessment)
            {
                for(var j=0;j<p.assessment.questions.length;j++)
                {
                    var q = p.assessment.questions[j];
                    if((q.audio !== "") && (q.audio != null))
                    {
                        var ext = q.audio.substring(q.audio.lastIndexOf(".")+1).toLowerCase();
                        if(ext == "swf")
                        {
                            return true;
                        }
                    }
                }
            }
        }

        Utils.debug.trace('Course does not have flash audio');
        return false;
    };
    
    //This event will be fired when playing either exit animation or entrance animation
    this.onAnimationEndForWrapperElement = function () {
        var wrapper = engine.ui.content.contentWindow.document.getElementById('wrapper');
        
        if (wrapper) {
            Utils.dom.removeEvent(wrapper, "animationend", this.onAnimationEndForWrapperElement);
            engine.controller.clearVideos(true);
            if (engine.controller.nextPageNameToGoAfterAnimation) {
                //Just play the exit animation
                var nextPageName = engine.controller.nextPageNameToGoAfterAnimation;
                engine.controller.nextPageNameToGoAfterAnimation = "";
                engine.controller.gotoPageByName(nextPageName);
            }
        }
    };

    this.clearVideos = function (stopVideo) {
        var videoContainers = engine.ui.content.contentWindow.document.getElements('.videoContainer');
        if (videoContainers) {
            for (i = 0; i < videoContainers.length; i++) {
                if(videoContainers[i]){
                    try{
                        var html5Video = videoContainers[i].querySelector("video");
                        if(html5Video){
                            if(stopVideo){
                                videoContainers[i].set("html", "");
                            }
                        }else {
                            videoContainers[i].set("html", "");
                        }
                    } catch(Exception){}
                }
            }
        }
    };
    
    this.playExitTransitionAndGoToPageByName = function (animationName, pageName, duration) {
        if (!this.navEnabled) 
        {
            // Navigation is currently disabled, returning.
            return;
        }
        
        if (animationName) {
            if(engine.ui.content.contentWindow.isPlayingAnimation && engine.controller.skipPlayTransitionTime <= engine.ui.content.contentWindow.maxAnimationWaitingTime * 2)
            {
                engine.controller.skipPlayTransitionTime++;
                engine.ui.content.contentWindow.isForceAbortAnimation = true;
                setTimeout(function(){
                    engine.controller.playExitTransitionAndGoToPageByName(animationName, pageName, duration);
                }, 500);
                return;
            }
            else
            {
                engine.controller.skipPlayTransitionTime = 0;
            }
            
            var wrapper = engine.ui.content.contentWindow.document.getElementById('wrapper');
            if (wrapper) {
                this.clearVideos(false);
                this.nextPageNameToGoAfterAnimation = pageName;
                var animationStyles = " animated " + animationName;
                Utils.dom.addEvent(wrapper, "animationend", this.onAnimationEndForWrapperElement);
                wrapper.style.animationDuration = duration;
                wrapper.className = wrapper.className + animationStyles;
            }
            else{
                this.gotoPageByName(pageName);
            }
        }
        else{
            this.gotoPageByName(pageName);
        }
    };

    this.hasPostAssessment = function ()
    {
        for(var i=0;i<this.pageList.length;i++)
        {
            if(this.pageList[i].isAssessment && this.pageList[i].isPostAssessment)
            {
                this.hasAssessment = true;
                return true;
            }
        }
        return false;
    };

    this.getTransitionDuration = function () {
        if(this.currentPageIndex >= 0 && this.pageList.length > this.currentPageIndex)
        {
            return this.pageList[this.currentPageIndex].duration;
        }
    };
    
    this.getTransitionIn = function () {
        if(this.currentPageIndex >= 0 && this.pageList.length > this.currentPageIndex)
        {
            return this.pageList[this.currentPageIndex].transitionIn;
        }
        return null;
    };
    
    this.getAnimations = function (){
        if(this.currentPageIndex >= 0 && this.pageList.length > this.currentPageIndex)
        {
            return this.pageList[this.currentPageIndex].animationList;
        }
        return null;
    };
    
    this.nextLinear = function()
    {
        if (this.currentPageIndex < (this.pageList.length - 1)) 
        {
            this.playExitTransitionAndGoToPageByName(this.pageList[this.currentPageIndex + 1].transitionOut, this.pageList[this.currentPageIndex + 1].name, this.pageList[this.currentPageIndex + 1].duration);
        }
    };
    
    this.gotoPage = function(nextPageName)
    {
        var nexPage = this.getPageByName(nextPageName);
        if (nexPage) {
            this.isClickOnMenuBar = true;
            this.playExitTransitionAndGoToPageByName(nexPage.transitionOut, nexPage.name, nexPage.duration);
        }
    };
    
    this.getNextPageNameFromBranchChoice = function(branchChoice)
    {
        var nextPageName = null;
        if (branchChoice.isBranchChoice) {
            // Mark the branch choice "container" page as visited
            branchChoice.visited = true;

            Utils.debug.trace('nextPageObj is a branch choice...');

            // Does this branch have child pages?
            if (branchChoice.isFolder()) {
                // This branch has child pages, so navigate to its first child page.
                nextPageName = branchChoice.pageList[0].name;

                Utils.debug.trace("nextPageObj has " + branchChoice.pageList.length + " child pages... nextPageName was set to: " + nextPageName);
            }
            else {
                // This branch has no children.  The destination must be the next linear page.
                var nextLinearPage = branchChoice.getNextAccessiblePage();

                // Set the current page (number) to the destination's page index value.
                nextPageName = nextLinearPage.name;

                Utils.debug.trace("nextPageObj has no child pages... nextPageName was set to: " + nextPageName);
            }
        }
        return nextPageName;
    }

    this.nextBranching = function()
    {
        if(!this.canMoveNext()){return;}

        // Does several branching-related checks to clarify which is the next page before advancing
        var nextPageName = null;
        var isBranchChoice = false;
        this.isClickOnMenuBar = false;
        // If the current page has a "next" property set, and it is the name of a valid page, use it
        if(this.currentPageObj.next && this.getPageByName(this.currentPageObj.next))
        {
            var nextPageObj = this.getPageByName(this.currentPageObj.next);

            if(nextPageObj)
            {
                // Do checks for branch choice pages...

                // Is the destination page a branch?
                if(nextPageObj.isBranchChoice) 
                {
                    isBranchChoice = true;

                    nextPageName = this.getNextPageNameFromBranchChoice(nextPageObj);
                    //// Mark the branch choice "container" page as visited
                    //nextPageObj.visited = true;

                    //Utils.debug.trace('nextPageObj is a branch choice...');
                    
                    //// Does this branch have child pages?
                    //if(nextPageObj.isFolder()) 
                    //{
                    //    // This branch has child pages, so navigate to its first child page.
                    //    nextPageName = nextPageObj.pageList[0].name;

                    //    Utils.debug.trace("nextPageObj has "+nextPageObj.pageList.length+" child pages... nextPageName was set to: "+nextPageName);
                    //}
                    //else
                    //{
                    //    // This branch has no children.  The destination must be the next linear page.
                    //    var nextLinearPage = nextPageObj.getNextAccessiblePage();

                    //    // Set the current page (number) to the destination's page index value.
                    //    nextPageName = nextLinearPage.name;

                    //    Utils.debug.trace("nextPageObj has no child pages... nextPageName was set to: "+nextPageName);
                    //}
                }
                else
                {
                    // We're not dealing with a branch here, use the original destination page's name.
                    nextPageName = nextPageObj.name;

                    Utils.debug.trace('nextPageObj is NOT a branch choice...');
                }
            } 
            else 
            {
                // We couldn't find the page using the page name, send the user to the first page.
                nextPageName = nextPageObj.pageList[0].name;
            }

            Utils.debug.trace("this.currentPageObj.next set to "+this.getPageByName(this.currentPageObj.next).name+" - nextPageName was set to: "+nextPageName);
        }
        else if(this.currentPageObj.next)
        {
            // This branch has no children.  The destination must be the next linear page.
            var nextLinearPage = this.currentPageObj.getNextAccessiblePage();

            // Set the current page (number) to the destination's page index value.
            nextPageName = nextLinearPage.name;

            Utils.debug.trace("this.currentPageObj.next set to true - nextPageName was set to: "+nextPageName);
        }
        else
        {
            if (this.currentPageIndex < (this.pageList.length - 1)) 
            {
                // Grab the next page object before we load it.
                var currentCheck =  this.pageList[this.currentPageIndex + 1];
    
                // Is the next page a branch choice? We must have made it to the end of a branch, and there is no "parent.end" property.
                if(currentCheck.isBranchChoice)
                {
                    isBranchChoice = true;
                    // This branch has no child pages.  The destination must be the next linear page.
                    var nextLinearPage = currentCheck.getNextAccessiblePage();
    
                    // Set the next page name to the destination's page's name
                    nextPageName = nextLinearPage.name;
    
                    Utils.debug.trace("currentCheck is a branch choice  - nextPageName was set to: "+nextPageName);
                }
                else
                {
                    nextPageName =  this.pageList[this.currentPageIndex + 1].name;
                }
            }
            else
            {
                return;
            }
            
        }
        
        if (this.currentPageIndex < (this.pageList.length - 1) && this.pageList[this.currentPageIndex + 1])
        {
            var nextPage = null;
            if (isBranchChoice)
            {
                nextPage = this.getPageByName(nextPageName);
            }
            else
            {
                nextPage = this.pageList[this.currentPageIndex + 1];
            }
            this.playExitTransitionAndGoToPageByName(nextPage.transitionOut, nextPage.name, nextPage.duration);
        }
    };
    
    this.backLinear = function()
    {
        if (this.currentPageIndex > 0 && this.pageList[this.currentPageIndex - 1])
        {
            this.playExitTransitionAndGoToPageByName(this.pageList[this.currentPageIndex - 1].transitionOut, this.pageList[this.currentPageIndex - 1].name, this.pageList[this.currentPageIndex - 1].duration);
        }
    };
    
    this.backBranching = function()
    {
        // History-based backward navigation
        if(this.canMoveBack())
        {
            this.isClickOnMenuBar = false;
            var prevPageIndex = this.getPrevPageIndexFromHistory();
            var prevPageName = this.pageList[prevPageIndex].name;
            var prevPage = this.getPageByName(prevPageName);
            if (prevPage)
            {
                this.playExitTransitionAndGoToPageByName(prevPage.transitionOut, prevPage.name, prevPage.duration);
            }
        }
    };

    this.up = function()
    {
        if(this.currentPageObj) 
        {
            var currParent = this.currentPageObj.parent;
            if(currParent)
            {
                this.gotoPageByName(currParent.name);
            }
        }
    };

    this.setChoicePage = function (pageName, indexChoice) {
        var page = this.getPageByName(pageName);
        var nextPageName = null;
        if (page.isBranchChoice) {
            // Does this branch have child pages?
            if (page.isFolder()) {
                // This branch has child pages, so navigate to its first child page.
                nextPageName = page.pageList[0].name;
            }
            else {
                // This branch has no children.  The destination must be the next linear page.
                var nextLinearPage = page.getNextAccessiblePage();

                // Set the current page (number) to the destination's page index value.
                nextPageName = nextLinearPage.name;
            }

            var firstPage = this.getPageByName(nextPageName);
            if (firstPage) {
                engine.setChoicePageSrc(firstPage.getPageURL(), indexChoice);
            }
        }
    };

    this.gotoPageByName = function(pageName)
    {
        if(!this.navEnabled) 
        {
            Utils.debug.trace('Navigation is currently disabled - Returning...');
            return;
        }

        this.disableNav();

        // Hide the audio loading image, as a user may have moved on before the audio finished loading
        Utils.dom.hide("audioLoading");

        if(Utils.browserDetection.isMobile())
        {
            Utils.window.clearMobileSimPageName();
        }
        
        if(this.currentPageObj) 
        {
            this.audioReset();
        }
        var isBranchChoice = false;
        var page = this.getPageByName(pageName);
        if (page)
        {
            if(page.isBranchChoice) 
            {
                isBranchChoice = true;
                // Mark the branch choice "container" page as visited
                page.visited = true;

                Utils.debug.trace('Page object is a branch choice...');
                
                // Does this branch have child pages?
                if(page.isFolder()) 
                {
                    // This branch has child pages, so navigate to its first child page.
                    nextPageName = page.pageList[0].name;
                }
                else
                {
                    // This branch has no children.  The destination must be the next linear page.
                    var nextLinearPage = page.getNextAccessiblePage();

                    // Set the current page (number) to the destination's page index value.
                    nextPageName = nextLinearPage.name;
                }
                
                var page = this.getPageByName(nextPageName);
            }
            
            Utils.debug.trace('Moving to page: ' + page.title);
            
            // Set the current page index/object properties
            var oldCurrentPageIndex = this.currentPageIndex;
            this.setCurrentPageIndex(page.index);
            this.setCurrentPageObj(page);
            
            // Add page to history
            this.addToHistory(this.currentPageIndex);
            
            // Reset all pages' "here" status
            this.resetPageListStatus();
            
            // Set the current page
            page.setAsCurrentPage();
            
            // Set the courseState property of the suspendDataObj
            this.setCourseState();
            
            // Set the history property of the suspendDataObj
            this.setHistoryState();
            
            this.setStatus(pageName);
            
            // Commit the Comm object data
            engine.comm.commit();

            if(this.hasBranches())
            {
                this.visiblePageTotal = this.updatePageTotalAndVisibleIndexes();
            }
            
            // Fire the page navigation UI handler
            engine.ui.onGoToPage();
            
            var nextpage = null;
            var backpage = null;
            if (this.pageList.length > page.index + 1)
            {
                nextpage = this.pageList[page.index + 1];
                if(nextpage && nextpage.isBranchChoice)
                {
                    if (!isBranchChoice) {
                        isBranchChoice = true;
                    }
                    nextpage = null;
                }
            }
            
            if (page.index >= 1)
            {
                if (this.hasBranches() && this.history.length > 1)
                {
                    backpage = this.pageList[this.history[this.history.length - 2]];
                }
                else {
                    backpage = this.pageList[page.index - 1];
                }
                
                if(backpage && backpage.isBranchChoice)
                {
                    if (!isBranchChoice) {
                        isBranchChoice = true;
                    }

                    backpage = this.pageList[backpage.index - 1];
                }
            }
            
            if (page.index == 0) 
            {
                if (oldCurrentPageIndex == 1) 
                {
                    //click on back button
                    this.gotoBackContent(page);
                }
                else 
                {
                    engine.setContentSrc(page.getPageURL());                    
                }
            }
            else if (page.index == this.pageList.length - 1) 
            {
                if (oldCurrentPageIndex + 1 == page.index || (!this.isClickOnMenuBar && oldCurrentPageIndex < page.index)) 
                {
                    //click on next button
                    this.gotoNextContent(page);
                }
                else 
                {
                    // click on menu bar
                    engine.setContentSrc(page.getPageURL());
                }
            }
            else 
            {
                if (oldCurrentPageIndex + 1 == page.index)
                {
                    this.gotoNextContent(page);
                }
                else if (oldCurrentPageIndex == page.index + 1)
                {
                    //engine.gotoBackPage();
                    this.gotoBackContent(page);
                }
                else
                {
                    if (!this.isClickOnMenuBar)
                    {
                        if (oldCurrentPageIndex < page.index)
                        {
                            //engine.gotoNextPage();
                            this.gotoNextContent(page);
                        }
                        else
                        {
                            this.gotoBackContent(page);
                        }
                    }
                    else
                    {
                        // click on menu bar
                        engine.setContentSrc(page.getPageURL());
                    }
                }
            }

            try
            {
                if (nextpage != null) {
                    engine.setNextPageSrc(nextpage.getPageURL());
                }
                else {
                    engine.setNextPageSrc(engine.rootPath + '/assets/htm/blank.htm')
                }

                if (backpage != null) {
                    engine.setBackPageSrc(backpage.getPageURL());
                }
                else {
                    engine.setBackPageSrc(engine.rootPath + '/assets/htm/blank.htm')
                }
            }
            catch(ex){}
        }
        else 
        {
            Utils.debug.trace('Error: Cannot locate page object named: ' + pageName);
        }
        
        if (Conf.ENABLE_DEBUGGER) 
        {
            Utils.debug.refresh();
        }
        
        this.checkNavState();
    };

    this.gotoNextContent = function(page)
    {
        if(engine.ui.nextContent.contentWindow.location.href.indexOf(page.name) != -1)
        {
            engine.gotoNextPage();
        }
        else {
            engine.setContentSrc(page.getPageURL());
        }
    }

    this.gotoBackContent = function (page) {
        if (engine.ui.backContent.contentWindow.location.href.indexOf(page.name) != -1) {
            engine.gotoBackPage();
        }
        else {
            engine.setContentSrc(page.getPageURL());
        }
    }
    
    this.getPrevPageIndexFromHistory = function()
    {
        // Remove the most recent page from history - it should be the current page
        this.history.pop();
        
        // Return the previous page index from the history array
        return this.history.pop();
    };
    
    this.gotoPageByNameFromHistory = function(pageName, historyIndex)
    {
        try 
        {
            this.history = Utils.array.truncate(this.history, historyIndex);
            this.gotoPageByName(pageName);
        } 
        catch (e) 
        {
            Utils.debug.trace('Error: An error occurred while attempting to load the page from history within the controller.');
        }
    };

    this.updatePageTotalAndVisibleIndexes = function()
    {
        var total = 0;
        this.pageList.each(function(item,index){
            if(item.isVisiblePage())
            {
                item.visibleIndex=total;
                total++;
            }
            else
            {
                item.visibleIndex=item.getVisibleAncestorIndex();
            }
        });
        return total;
    };

    this.getTotalPagesVisited = function()
    {
        var total = 0;
        this.pageList.each(function(item,index){
            if((item.visited || item.here) && item.isVisiblePage())
            {
                total++;
            }
        });
        return total;
    };
    
    this.calculateVisited = function()
    {
        var pageTotal = this.visiblePageTotal;
        var viewedTotal = this.getTotalPagesVisited();
        var visited = (Math.round((viewedTotal/pageTotal)*100))/100;
        return visited;
    };
    
    this.setProgressStatus = function()
    {
        var visited = this.calculateVisited();
        if (this.completionThreshold != -1) {
            engine.comm.setProgressStatus(visited);
        }
    };
    
    this.meetsCompletionThreshold = function()
    {
        if (this.completionThreshold != -1 && engine.comm.completeOnThreshold){
            var visited = this.calculateVisited();
            if (visited >= this.completionThreshold){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    };
    
    
    this.setStatus = function(pageName)
    {
        var page;
        if (pageName != undefined || pageName != null){
            page = this.getPageByName(pageName);
            Utils.debug.trace('Page ' + pageName);
        } else {
            page = this.getPageByName(this.currentPageObj);
            Utils.debug.trace('Page ' + this.currentPageObj);
        }
        if(page)
        {
            // Persist suspendDataObj as a JSON string in the Comm object
            this.setSuspendData();
                
            engine.comm.setLocation(pageName);
                
            this.setProgressStatus();
    
            // Check if the Comm object in use automatically sets completion
            // when all steps have been viewed
            this.checkForCompletion();
        }
    };
    
    this.validateThreshold = function()
    {
        if (engine.comm.completeOnThreshold){
            this.completionThreshold = engine.comm.getCompletionThreshold();
            
            if (this.completionThreshold == '' || this.completionThreshold == -1){
                if (Conf.SCORM_COMPLETION_THRESHOLD && !isNaN(Conf.SCORM_COMPLETION_THRESHOLD))
                {
                    if (Conf.SCORM_COMPLETION_THRESHOLD > 1) {
                        // completion threshold cannot be greater than 1
                        this.completionThreshold = 1;
                    } else if (Conf.SCORM_COMPLETION_THRESHOLD < 0) {
                        // completion threshold cannot be less than 0
                        this.completionThreshold = 0;
                    } else {
                        this.completionThreshold = (Math.round((Conf.SCORM_COMPLETION_THRESHOLD)*100))/100;
                    }
                    engine.comm.setCompletionThreshold(this.completionThreshold);
                }
            }
        }
    };
    
    this.resetPageListStatus = function()
    {
        Utils.array.invoke(this.pageList, function(pageObj){
            pageObj.here = false;
        });
    };
    
    this.goToResourceByName = function(resourceName, newwindow)
    {
        if(!this.navEnabled) 
        {
            Utils.debug.trace('Navigation is currently disabled - Returning...');
            return;
        }

        this.disableNav();

        // Hide the audio loading image, as a user may have moved on before the audio finished loading
        Utils.dom.hide("audioLoading");

        if(this.currentPageObj) 
        {
            this.audioReset();
        }
        
        var resource = this.getResourceByName(resourceName);
        if(resource)
        {
            resource.openWindow(true, newwindow);
        }
        
        if (Conf.ENABLE_DEBUGGER) 
        {
            Utils.debug.refresh();
        }
        
        this.checkNavState();
    };
    
    this.getResourceByName = function(resourceName)
    {
        for (var i = 0; i < this.resources.length; i++) 
        {
            if (this.resources[i].name == resourceName) 
            {
                return this.resources[i];
            }
        }
        return false;
    };
    
    this.getPageByName = function(pageName)
    {
        for (var i = 0; i < this.pageList.length; i++) 
        {
            if (this.pageList[i].name == pageName) 
            {
                return this.pageList[i];
            }
        }
        return false;
    };

    this.getLastPage = function()
    {
        return this.pageList[this.pageTotal-1];
    };
    
    this.checkForCompletion = function()
    {
        // If this is a branching scenario, check for termination
        if(this.branchingEnabled)
        {
            // If this is a branch termination page, and we're supposed to send the score, send it.
            if((this.currentPageObj.isTerminationPage()) && (this.currentPageObj.parent.sendScore) && (!isNaN(this.currentPageObj.parent.scoreToSend)))
            {
                Utils.debug.trace('In check for completion: Termination detected, sending completion and score...');
                
                // Persist the first page as the lesson location in the Comm object, since the user shouldn't be
                // prompted again to restart on a termination page.
                engine.comm.setLocation(engine.root.name);

                // Set completion status and score
                this.setStatusAndScore(this.currentPageObj.parent.scoreToSend);
            }
        }
        else
        {
            if(engine.comm.autoCompleteOnAllPagesVisited)
            {
                // Set completion status to completed
                if(this.areAllPagesVisited())
                {
                    Utils.debug.trace('In check for completion: All pages have been visited (and comm object allows auto complete on all pages visited), sending completion...');
                    engine.comm.setCompleted(this.completionStrings.completed);
                } else {
                    if (this.meetsCompletionThreshold()){
                        engine.comm.setCompleted(this.completionStrings.completed);
                    }
                }
            }
            else
            {
                if(this.completeOnAllPagesVisited)
                {
                    // Set completion status to completed
                    if(this.areAllPagesVisited())
                    {
                        Utils.debug.trace('In check for completion: All pages have been visited (and completeOnAllPagesVisited = true), sending completion...');
                        engine.comm.setCompleted(this.completionStrings.completed);
                    } else {
                        if (this.meetsCompletionThreshold()){
                            engine.comm.setCompleted(this.completionStrings.completed);
                        }
                    }
                }
            }
        }
    };
    
    this.disableNav = function()
    {
        this.navEnabled = false;
    };
    
    this.disableNavButtons = function()
    {
        engine.ui.disableSpacebarAccess();
        $('nextBtn').store('enabled',false);
        $('backBtn').store('enabled',false);
        Utils.dom.disableNavButtonById("nextBtn");
        Utils.dom.disableNavButtonById("backBtn");
        Utils.dom.disableAuxButtonById("menuBtn");
        Utils.dom.disableAuxButtonById("historyBtn");
        engine.ui.removeFromTabChain($("nextBtn"));
        engine.ui.removeFromTabChain($("backBtn"));
        engine.ui.removeFromTabChain($("menuBtn"));
        engine.ui.removeFromTabChain($("historyBtn"));
    };
    
    this.enableNav = function()
    {
        this.navEnabled = true;
    };
    
    this.enableNavButtons = function()
    {
        engine.ui.enableSpacebarAccess();
        $('nextBtn').store('enabled',true);
        $('backBtn').store('enabled',true);
        Utils.dom.enableNavButtonById("nextBtn");
        Utils.dom.enableNavButtonById("backBtn");
        Utils.dom.enableAuxButtonById("menuBtn");
        Utils.dom.enableAuxButtonById("historyBtn");
        engine.ui.resetTabIndex($("nextBtn"));
        engine.ui.resetTabIndex($("backBtn"));
        engine.ui.resetTabIndex($("menuBtn"));
        engine.ui.resetTabIndex($("historyBtn"));
    };
    
    this.enableAssessmentMode = function()
    {
        Utils.debug.trace("Assessment mode: enabled");
        this.inAssessmentMode = true;
        this.disableNavButtons();
        this.disableNav();
    };
    
    this.disableAssessmentMode = function()
    {
        Utils.debug.trace("Assessment mode: disabled");
        this.inAssessmentMode = false;
        this.enableNavButtons();
        this.enableNav();
    };
    
    this.setCurrentPageObj = function(pageObj)
    {
        this.currentPageObj = pageObj;
    };
    
    this.setCurrentPageIndex = function(pageIndex)
    {
        this.currentPageIndex = pageIndex;
    };
    
    this.checkNavState = function()
    {
        if(this.inAssessmentMode && this.currentPageObj.isPostAssessment || this.currentPageObj.isTerminationPage())
        {
            this.disableNavButtons();
            return;
        }
        else
        {
            this.enableNav();
        }
        
        if(this.canMoveNext()) 
        {
            $('nextBtn').store('enabled',true);
            Utils.dom.enableNavButtonById("nextBtn");
            Utils.dom.removeFilter($("nextBtn"));
            engine.ui.resetTabIndex($("nextBtn"));
            engine.ui.patchTitleOn($("nextBtn"));
        }
        else 
        {
            $('nextBtn').store('enabled',false);
            Utils.dom.disableNavButtonById("nextBtn");
            engine.ui.patchTitleOff($("nextBtn"));
        }
        
        if (this.canMoveBack()) 
        {
            $('backBtn').store('enabled',true);
            Utils.dom.enableNavButtonById("backBtn");
            Utils.dom.removeFilter($("backBtn"));
            engine.ui.resetTabIndex($("backBtn"));
            engine.ui.patchTitleOn($("backBtn"));
        }
        else 
        {
            $('backBtn').store('enabled',false);
            Utils.dom.disableNavButtonById("backBtn");
            engine.ui.patchTitleOff($("backBtn"));
        }
    };
    
    this.canMoveNext = function()
    {
        return this.currentPageObj.canMoveNext();
    };
    
    this.canMoveBack = function()
    {
        // By default, we can move backward...
        var canBack = true;
    
        // If current page index is less than or equal to 0, this must be the first page.
        if(this.currentPageIndex <= 0)
        {
            canBack = false;

            if(this.branchingEnabled && (this.history.length > 1)){
                canBack = true;
            }
            
        }
        
        // If branching has been enabled, and the length of the history list is-
        // less than or equal to 0, we have nowhere to move back to.
        if(this.branchingEnabled && (this.history.length <= 0))
        {
            canBack = false;
        }
    
        return canBack;
    };
    
    this.hideAudioControls = function()
    {
        engine.ui.hideAudioControls();
    };
    
    this.loadAudio = function(file)
    {
        if(Conf.AUTO_HIDE_AUDIO_CONTROLS)
        {
            if((this.currentPageObj.audio || file) && (Conf.AUDIO_TYPE != null)) 
            {
                engine.ui.showAudioControls();
            }
            else
            {
                engine.ui.hideAudioControls();
            }
        }
        else
        {
            engine.ui.showAudioControls();
        }
        
        // If the course is muted, return...
        if(this.isMuted){return;}

        // If the loaded HTML file is the summary page, return...
        if(engine.ui.content.contentWindow.location.href == engine.assessmentSummaryPath)
        {
            this.disableAudio();
            return;
        }

        // If this page object is a post assessment, and it is being bypassed to load the summary page automatically, return...
        if(this.currentPageObj.isPostAssessment && this.currentPageObj.assessment.inSummary){return;}

        if(Conf.AUDIO_TYPE != null && engine.audio.ready)
        {
            if(this.inAssessmentMode && !file)
            {
                engine.audio.reset();
                this.currentPageObj.assessment.loadQuestionAudio();
            }
            else
            {
                if(this.currentPageObj.audio || file)
                {
                    this.enableAudio();
                    this.audioStop();
                    var audioFile = (file) ? "./content/audio/" + file : "./content/audio/" + this.currentPageObj.audio;
                    engine.audio.load(audioFile);
                }
                else
                {
                    this.disableAudio();
                }
            }
        }
        else
        {
            this.disableAudio();
        }
    };
    
    this.audioToggleEnabled = function()
    {
        this.isMuted = !this.isMuted;
        if(this.isMuted)
        {
            Utils.dom.renderHTML('audioLabel',unescape(Lang.UI_LABEL_AUDIO_DISABLED));
            this.audioStop();
            this.disableAudio();
            Utils.dom.hide("audioDisableBtn");
            $('audioDisableBtn').getElements('a')[0].setAttribute('tabindex',-1);
            Utils.dom.show("audioEnableBtn");
            $('audioEnableBtn').getElements('a')[0].setAttribute('tabindex',0);
            setTimeout(function(){$('audioEnableBtn').getElements('a')[0].focus();},0);
        }
        else
        {
            Utils.dom.renderHTML('audioLabel',unescape(Lang.UI_LABEL_AUDIO_ENABLED));
            this.loadAudio();
            Utils.dom.show("audioDisableBtn");
            $('audioDisableBtn').getElements('a')[0].setAttribute('tabindex',0);
            Utils.dom.hide("audioEnableBtn");
            $('audioEnableBtn').getElements('a')[0].setAttribute('tabindex',-1);
            setTimeout(function(){$('audioDisableBtn').getElements('a')[0].focus();},0);
        }
    };
    
    this.disableAudio = function()
    {
        this.audioEnabled = false;
        engine.audio.remove();
        Utils.dom.hide("audioPauseBtn");
        Utils.dom.show("audioPlayBtn");
        Utils.dom.disableAudioButtonById("audioStopBtn");
        Utils.dom.disableAudioButtonById("audioPlayBtn");
        engine.ui.removeFromTabChain($("audioStopBtn"));
        engine.ui.removeFromTabChain($("audioPlayBtn"));
        engine.ui.patchTitleOff($("audioStopBtn"));
        engine.ui.patchTitleOff($("audioPlayBtn"));

        engine.ui.hideEnablePlaybackPrompt();
        Utils.dom.hide("audioLoading");
    };
    
    this.enableAudio = function()
    {
        this.audioEnabled = true;
    };
    
    this.audioTogglePlay = function()
    {
        if (!this.audioEnabled) 
        {
            return;
        }
        
        if (engine.audio.isPlaying) 
        {
            engine.audio.pause();
            Utils.dom.hide("audioPauseBtn");
            $('audioPauseBtn').getElements('a')[0].setAttribute('tabindex',-1);
            Utils.dom.show("audioPlayBtn");
            engine.ui.resetTabIndex($("audioPlayBtn"));
            $('audioPlayBtn').getElements('a')[0].focus();
            Utils.dom.enableAudioButtonById("audioStopBtn");
            Utils.dom.enableAudioButtonById("audioPlayBtn");
            engine.ui.resetTabIndex($("audioStopBtn"));
            engine.ui.patchTitleOn($("audioStopBtn"));
            engine.ui.patchTitleOn($("audioPlayBtn"));
        }
        else 
        {
            Utils.dom.hide("audioPlayBtn");
            $('audioPlayBtn').getElements('a')[0].setAttribute('tabindex',-1);
            Utils.dom.show("audioPauseBtn");
            engine.ui.resetTabIndex($("audioPauseBtn"));
            $('audioPauseBtn').getElements('a')[0].focus();
            engine.audio.play();
            this.onAudioStart();
        }

        engine.ui.hideEnablePlaybackPrompt();
    };
    
    this.audioStop = function()
    {
        if (!this.audioEnabled) 
        {
            return;
        }
        try
        {
            $('audioPlayBtn').getElements('a')[0].focus();
        }
        catch(e){}
        engine.audio.stop();
        this.onAudioComplete();
    };

    this.audioReset = function()
    {
        if (!this.audioEnabled) 
        {
            return;
        }

        Utils.dom.disableAudioButtonById("audioStopBtn");
        Utils.dom.disableAudioButtonById("audioPlayBtn");
        engine.ui.removeFromTabChain($("audioStopBtn"));
        engine.ui.removeFromTabChain($("audioPlayBtn"));
        engine.ui.patchTitleOff($("audioStopBtn"));
        engine.ui.patchTitleOff($("audioPlayBtn"));

        engine.audio.reset();
        this.onAudioComplete();
    };
    
    this.onAudioStart = function()
    {
        if(engine.ui.audioControlsHidden){return;}
        Utils.dom.show("audioPauseBtn");
        $('audioPauseBtn').getElements('a')[0].focus();
        Utils.dom.hide("audioPlayBtn");
        Utils.dom.enableAudioButtonById("audioStopBtn");
        engine.ui.resetTabIndex($("audioStopBtn"));
        engine.ui.resetTabIndex($("audioPauseBtn"));
        engine.ui.patchTitleOn($("audioStopBtn"));
        engine.ui.patchTitleOff($("audioPlayBtn"));
        engine.ui.patchTitleOn($("audioPauseBtn"));
    };

    this.onAudioLoad = function()
    {
        if(engine.ui.audioControlsHidden){return;}
        Utils.dom.enableAudioButtonById("audioStopBtn");
        Utils.dom.enableAudioButtonById("audioPlayBtn");
        engine.ui.resetTabIndex($("audioStopBtn"));
        engine.ui.resetTabIndex($("audioPlayBtn"));
        engine.ui.patchTitleOn($("audioPlayBtn"));
        engine.ui.patchTitleOn($("audioStopBtn"));
        Utils.dom.hide("audioLoading");
    };
    
    this.onAudioComplete = function()
    {
        if(engine.ui.audioControlsHidden){return;}
        Utils.dom.hide("audioPauseBtn");
        $('audioPauseBtn').getElements('a')[0].setAttribute('tabindex',-1);
        Utils.dom.show("audioPlayBtn");
        engine.ui.resetTabIndex($("audioPlayBtn"));
        $('audioPlayBtn').getElements('a')[0].focus();
        Utils.dom.disableAudioButtonById("audioStopBtn");
        Utils.dom.enableAudioButtonById("audioPlayBtn");
        engine.ui.removeFromTabChain($("audioPauseBtn"));
        engine.ui.patchTitleOff($("audioStopBtn"));
        engine.ui.patchTitleOn($("audioPlayBtn"));
    };
    
    this.onInteractionComplete = function(result)
    {
        Utils.debug.trace('Interaction completed  - Result: ' + result);
    };
    
    this.addToHistory = function(pageIndex)
    {
        if (this.history[this.history.length - 1] != pageIndex) 
        {
            this.history.push(pageIndex);
        }
        if(this.history.length > Conf.MAX_HISTORY_LENGTH)
        {
            var a = this.history.slice(this.history.length-Conf.MAX_HISTORY_LENGTH);
            this.history = a;
        }
    };
    
    this.getHistoryHTML = function()
    {
        var html = '';
        
        for (var i = 0; i < this.history.length; i++) 
        {
            var pageIndex = this.history[i];
            var pageObj = this.pageList[pageIndex];
            html += pageObj.getHistoryHTML(i);
        }
        
        return html;
    };
    
    this.getResourceHTML = function()
    {
        var html = '';
        
        for (var i = 0; i < this.resources.length; i++) 
        {
            var resourceObj = this.resources[i];
            html += resourceObj.getResourceHTML(i);
        }
        
        return html;
    };
    
    this.setStatusAndScore = function(score)
    {
        var o = {};
        o.score = score;

        engine.comm.setScore(score);
        
        if(score >= Conf.PASSING_SCORE)
        {
            // Passed
            engine.comm.setCompletionStatus(this.completionStrings.completed);
            engine.comm.setSuccessStatus('passed');
            o.passed = true;
        }
        else
        {
            // Failed
            engine.comm.setCompletionStatus(this.completionStrings.incomplete);
            engine.comm.setSuccessStatus('failed');
            o.passed = false;
        }

        if(engine.comm.enableManualSubmit)
        {
            o.totalToInclude = 'n/a';
            o.totalIncorrect = 'n/a';
            o.incNumberList = 'n/a';
            
            engine.comm.sendResults(o);
        }
    };
    
    this.setCourseState = function()
    {
        var state = Utils.string.encodeState(this.getCourseState());
        this.suspendDataObj.courseState = state;
    };
    
    this.setHistoryState = function()
    {
        this.suspendDataObj.history = this.getHistoryState();
    };
    
    
    this.setAssessmentState = function()
    {
        this.suspendDataObj.assessmentState = this.hasAssessment;
    };
    
    this.setIncQuestionList = function(a)
    {
        this.suspendDataObj.incQuestionList = a.join("-");
    };
    
    this.getIncQuestionList = function()
    {
        return (this.suspendDataObj.incQuestionList != null) ? this.suspendDataObj.incQuestionList.split("-") : null;
    };
    
    this.clearIncQuestionList = function()
    {
        delete this.suspendDataObj.incQuestionList;
    };
    
    //Persists suspendDataObj as a JSON string in the Comm object
    this.setSuspendData = function()
    {
        var suspend_data = JSON.encode(this.suspendDataObj);
        engine.comm.setSuspendData(suspend_data);
    };
    
    this.areAllPagesVisited = function()
    {
        // Should make an option related to whether or not branching courses should support this
        return (this.visiblePageTotal === this.getTotalPagesVisited());
    };
    
    this.getCourseState = function()
    {
        var tmp = '';
        for(var i=0;i<this.pageList.length;i++)
        {
            if(this.pageList[i].visited || this.pageList[i].here)
            {
                if(this.pageList[i].passed)
                {
                    tmp += 'p';
                }
                else if(this.pageList[i].failed)
                {
                    tmp += 'f';
                }
                else
                {
                    tmp += '1';
                }
            }
            else
            {
                tmp += '0';
            }
        }
        return tmp;
    };
    
    this.resetCourseState = function(v)
    {
        for(var i=0;i<v.length;i++)
        {
            if(v.charAt(i) == '1' || v.charAt(i) == 'p' || v.charAt(i) == 'f')
            {
                this.pageList[i].visited = true;
            }
            
            if(v.charAt(i) == 'p')
            {
                this.pageList[i].passed = true;
                this.pageList[i].failed = false;
                this.pageList[i].assessment.passed = true;
                this.pageList[i].assessment.failed = false;
                this.pageList[i].assessment.completed = true;
            }
    
            if(v.charAt(i) == 'f')
            {
                this.pageList[i].passed = false;
                this.pageList[i].failed = true;
                this.pageList[i].assessment.passed = false;
                this.pageList[i].assessment.failed = true;
                this.pageList[i].assessment.completed = true;
            }
        }
    };
    
    this.getHistoryState = function()
    {
        return this.history.join("-");
    };

    this.resetHistoryState = function(h)
    {
        this.history = h.split("-");
    };
    
    this.setStudentResponse = function(simApi, title, totalToInclude, totalIncorrect, incStepNumberList)
    {
        try 
        {
            var o = {};
            o.simApi = simApi;
            o.title = escape(title);
            o.totalToInclude = totalToInclude;
            o.totalIncorrect = totalIncorrect;
            o.incStepNumberList = incStepNumberList;
            
            this.currentPageObj.assessment.setStudentResponse(o);
        } 
        catch (e) 
        {
            Utils.debug.trace('Error: An error occurred while attempting to pass the sim result to the assessment. ' + e);
        }
    };
}
