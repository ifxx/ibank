﻿/** 
* Defines the base question object
* @constructor
*/
function Question(o)
{
	for (var prop in o)
	{
		this[prop] = o[prop];
	}
	
	this.attempts = 0;
	this.choices = [];
	this.hotspots = [];
	this.zoomButtons = [];
	this.skipped = false;
	this.alphas = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
}
	
Question.prototype.addChoice = function(c)
{
	var cid = this.choices.length;
	c.cid = this.alphas[cid];
	this.choices.push(c);
};

Question.prototype.addHotspot = function(o)
{
	this.hotspots.push(o);
};

Question.prototype.pushHotspots = function(contentFrame)
{
	for(var i=0;i<this.hotspots.length;i++)
	{
		contentFrame.Hotspot.hotspots.push(this.hotspots[i]);
	}
};

Question.prototype.addZoomButton = function(o)
{
	this.zoomButtons.push(o);
};

Question.prototype.pushZoomButtons = function(contentFrame)
{
	var len = this.zoomButtons.length;
	for(var i=0;i<len;i++)
	{
		contentFrame.Zoom.zoomButtons.push(this.zoomButtons[i]);
	}
};

Question.prototype.disable = function()
{
	try
	{
		var contentDoc = this.assessment.contentDoc;
		var len = this.choices.length;
		if(this.quesType == "DragDrop")
		{
			this.disableDraggables();
			return;
		}
		if(this.quesType == "HotSpot")
		{
			this.disable();
			return;
		}
		for(var i=0;i<len;i++)
		{
			switch(this.quesType)
			{
				case "MultiCorrect":
					contentDoc.forms["contentForm"][this.name][i].disabled = true;
					break;
				case "MultiChoice":
					contentDoc.forms["contentForm"][this.name][i].disabled = true;
					break;
				case "FillIn":
					contentDoc.forms["contentForm"][this.name+i].disabled = true;
					break;
				case "Sim":
					if(!this.assessment.isPostAssessment)
					{
						contentDoc.forms["contentForm"][this.name+this.choices[i].mode].disabled = true;
					}
					else
					{
						contentDoc.forms["contentForm"][this.name+"3"].disabled = true;
					}
					break;
				default:
					break;
			}
		}
	}
	catch(e){}
};

Question.prototype.reset = function()
{
	this.correctResponse = null;
	this.studentResponse = null;
	this.correct = false;
	this.answered = false;
	this.skipped = false;
	this.choice = null;
};

Question.prototype.getCorrectResponse=function()
{
	return this.correctResponse;
};

Question.prototype.getStudentResponse=function()
{
	return this.studentResponse;
};

Question.prototype.setInteractionResult=function()
{
	if(this.assessment.isPostAssessment)
	{
		engine.comm.setInteractionResult(this.assessment.currentQues, this.isCorrect());
		engine.comm.setInteractionTime(this.assessment.currentQues);
		engine.comm.setInteractionLatency(this.assessment.currentQues);
	}
};
