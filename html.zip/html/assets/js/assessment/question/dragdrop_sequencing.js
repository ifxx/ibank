/** 
* Defines the DragDropSequencing object for Sequencing (Ordering) Drag-n-Drop interactions
* @requires Question
* @extends Question
* @constructor
*/
function DragDropSequencing(o)
{
	DragDropStandard.call(this,o);
	
	// Used by assessment
	this.quesType = "DragDrop";
	
	// Used by SCORM interactions
	this.interactionsType = "sequencing";

	this.sortedDraggables = [];

	this.isCorrect=function()
	{
		this.correct = true;

		this.studentResponse.each(function(o,i){
			if((o.correct && !o.dropped) || (!o.correct && o.dropped) || ((o.correctIndex != null) && (o.correctIndex != o.droppedIndex)))
			{
				this.correct = false;
			}
		},this);

		return this.correct;
	};

	this.setCorrectResponse=function(correctResponse)
	{
		if(!correctResponse){return;}
		this.correctResponse = correctResponse;
		
		if (this.assessment.isPostAssessment)
		{
			var responsesArray = [];
			this.correctResponse.each(function(o,i){
				responsesArray.push(this.alphas[o.origIndex]);
			},this);
			var response = responsesArray.join(engine.comm.groupSep);

			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, response);
		}
	};
	
	this.setStudentResponse=function(studentResponse)
	{
		if(!studentResponse){return;}
		this.studentResponse = studentResponse;
		
		if (this.assessment.isPostAssessment)
		{
			var responsesArray = [];
			var sortedStudentResponse = this.studentResponse.sortBy('droppedIndex');
			sortedStudentResponse.each(function(o,i){
				if(o.dropped)
				{
					responsesArray.push(this.alphas[o.origIndex]);
				}
			},this);
			var response = responsesArray.join(engine.comm.groupSep);

			if(responsesArray.length > 1)
			{
				engine.comm.setInteractionStudentResponse(this.assessment.currentQues, response);
			}
		}
	};

	this.getStudentResponse=function()
	{
		var response = [];
		this.draggables.each(function(d,i){
			var o  = {};
			o.correct = d.correct;
			o.dragText = d.label;
			o.targetIdx = this.alphas[0];
			o.dropped = (this.draggableElements[i].drop != null);
			o.droppedIndex = this.draggableElements[i].droppedIndex-1;
			o.correctIndex = d.index;
			o.origIndex = d.origIndex;

			response.push(o);
		},this);
		return response;
	};

	this.getCorrectResponse=function()
	{
		this.sortedDraggables = Array.clone(this.draggables);
		this.sortedDraggables.sortBy('index');

		var response = [];
		this.sortedDraggables.each(function(d,i){

			if(d.index !== null)
			{
				var o  = {};
				o.correct = d.correct;
				o.dragText = d.label;
				o.targetIdx = this.alphas[0];
				o.correctIndex = d.index;
				o.origIndex = d.origIndex;

				Utils.debug.trace("Setting correct response: "+o.dragText+" ("+o.correctIndex+"), origIndex: "+this.alphas[o.origIndex]);

				response.push(o);
			}
			
		},this);
		return response;
	};

	this.getCorrectResponseTxt=function(responseObj)
	{
		var html = '';
		var sortedResponseObj = responseObj.sortBy('correctIndex');
		sortedResponseObj.each(function(item,index){
			if (item.correct && (item.correctIndex != null))
			{
				html += '<p>' + (item.correctIndex+1) + ': ' + unescape(item.dragText) + '</p>';
			}
		},this);
		
		return html;
	};

	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+this.getStudentResponseTxt(this.studentResponse)+'</span>';
		html += '</p>';
		
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+this.getCorrectResponseTxt(this.correctResponse)+'</span>';
			html += '</p>';
		}
		
		return html;
	};

	this.getStudentResponseTxt=function(responseObj)
	{
		var html = '';
		var sortedResponseObj = responseObj.sortBy('droppedIndex');
		sortedResponseObj.each(function(item,index){
			if (item.dropped)
			{
				html += '<p>' + (item.droppedIndex+1) + ': ' + unescape(item.dragText) + '</p>';
			}
		},this);
		
		return html;
	};

	this.assessInteraction=function()
	{
		this.assessment.enableReset();
		this.assessment.enableContinue();
		if(this.countDrops() >= 1)
		{
			var studentResponse = this.getStudentResponse();
			this.setStudentResponse(studentResponse);

			this.answered = true;
		}
		else
		{
			this.answered = false;
		}
	};

	this.showMe=function()
	{
		try
		{
		    var target = $CONTENT('tContent', this.assessment.contentDoc);
			target.innerHTML = '';
			var drops=0;
			
			// loop over each of the sorted draggable objects
			this.sortedDraggables = this.getCorrectResponse();
			this.sortedDraggables.each(function(dragObj){
				var d = this.getDraggableElementByIndex(dragObj.origIndex);
				var dContent = d.parentNode;
				if(d.correct)
				{
					drops++;
					target.innerHTML += '<div class="singleTargetItem"><div class="targetItemNumber">'+drops+'</div>'+d.innerHTML+'</div>';
					target.set('title',target.get('title')+'. '+d.innerHTML);
				}

				d.correct = false;
				dContent.enabled = false;

				dContent.removeEvents('click');
				dContent.tabIndex = -1;
				dContent.set('aria-grabbed',false);

				d.removeEvents('mousedown');
				d.removeClass('dragActive');
				d.setStyles({opacity:0.7});
			},this);

			this.selectedElement = null;
			this.answered=false;
		}
		catch(e)
		{
			Utils.debug.trace("Error in showMe: "+(e.description || e),'error');
		}
	};

	this.getDraggableElementByIndex = function(index)
	{
		var el=null;
		this.draggableElements.each(function(d,i){
			if(i == index){el = d;}
		},this);
		return el;
	};

	this.assessMatch = function(el)
	{
		if(!this.selectedElement || !this.focusedElement){return;}

		el = (el) ? el : this.focusedElement;

		var draggable = this.selectedElement.getElements('div')[0];
		var target = el;

		draggable.drop = el;
		draggable.droppedIndex = this.countDrops();
		target.innerHTML += '<div class="singleTargetItem"><div class="targetItemNumber">'+draggable.droppedIndex+'</div>'+draggable.innerHTML+'</div>';

		var targetTitle = target.get('title');
		target.set('title',targetTitle+'. '+draggable.innerHTML);

		this.selectedElement.removeEvents('click');
		this.selectedElement.tabIndex = -1;

		draggable.removeEvents('mousedown');
		draggable.removeClass('dragActive');
		draggable.setStyles({opacity:0.7});
		

		this.selectedElement = null;

		$CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragContent').each(function (el) {
			el.removeClass('dragSelected');
			el.set('aria-grabbed',false);
		});

		this.assessInteraction();
	};

	this.makeDraggables=function(container)
	{
		var self = this;

		// create draggables
		this.draggables.each(function(item,index){
			
			// Create draggableContent container
			var dContent = this.CONTENT_DOC.newElement('div',{
				id: 'dContent'+index,
				title: Lang.ACCESSIBILITY_DRAGGABLE+'-'+Lang.ACCESSIBILITY_DESELECTED+': '+unescape(item.label),
				tabIndex: 0,
				events:{
					'click': function(e) {
						self.dragClicked(e,this);
					},
					'focus': function(e) {
						self.dragFocused(e,this);
					},
					'keydown': function(e){
						if(e.code == 32 || e.code == 13)
						{
							self.selectDrag(this);
							e.stop();
						}
					}
				}
			}).inject(container);
			dContent.enabled = true;
			dContent.label = item.label;
			dContent.isDraggable = true;
			dContent.isTarget = false;
			dContent.target = 'tContent';
			dContent.addClass('clearfix');
			dContent.addClass('dragContent');
			dContent.set('aria-grabbed',false);

			// Create draggable element
			var draggable = this.CONTENT_DOC.newElement('div',{
			    id: 'draggable'+index,
				text: unescape(item.label)
			}).inject(dContent);
			draggable.drop = null;
			draggable.index = item.index;
			draggable.droppedIndex = null;
			draggable.label = Utils.string.replaceChars(item.label);
			draggable.title = unescape(item.label);
			draggable.correct = item.correct;
			draggable.addClass('uiTextColor');
			draggable.addClass('uiSecondaryBackgroundColor');
			draggable.addClass('dragActive');
			draggable.addClass('draggableMany');
			draggable.target = item.target;

			if(Utils.browserDetection.isMobile())
			{
				var clone = draggable.clone();
				var z = draggable.getStyle('z-index');
				var origin = draggable.getPosition();
				var dimensions = draggable.getComputedSize();
				
				clone.setStyles({
					opacity:0.01,
					position:'absolute',
					left:origin.x,
					top:origin.y,
					width:dimensions.width,
					height:dimensions.height,
					zIndex:z+1
				}).inject(container);
				clone.addClass('dragClone');
				clone.target = item.target;
				clone.label = item.label;
				clone.dContent = dContent;
				clone.dragEl = draggable;
				clone.origin = origin;
			}
			
			this.draggableElements.push(draggable);

		},this);
	};
	
	this.makeTargets=function(container)
	{
		var self = this;

		// Create targetContent container
		var tContent = this.CONTENT_DOC.newElement('div',{
			id: 'tContent',
			title: Lang.ACCESSIBILITY_TARGET,
			tabindex: 0,
			events:{
				'click': function(e) {
					self.targetClicked(e,this);
				},
				'focus': function(e) {
					self.targetFocused(e,this);
				},
				'keydown': function(e){
					if((e.control && e.code == 77) || e.code == 13 || e.code == 32)
					{
						self.assessMatch(this);
						e.stop();
					}
				}
			}
		}).inject(container);
		tContent.isDraggable = false;
		tContent.isTarget = true;
		tContent.enabled = true;
		tContent.targetId = 'tContent';
		tContent.addClass('targetContent');
		tContent.addClass('target');
		tContent.addClass('singleTarget');
		tContent.set('aria-dropeffect','move');

		var dragContainerH = $CONTENT('draggablesContainer', this.assessment.contentDoc).getSize().y;
		tContent.setStyle('height',dragContainerH);
		//tContent.setStyle('width',this.elementWidth-20);

		this.targetElements.push(tContent);
	};

	this.createDragEvents=function()
	{
		var self = this;
		var allowance = 10;
		var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.draggableMany');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		draggables.addEvent('mousedown',function(ev){
			var clone = this.clone();
			var origin = this.getPosition();
			var size = this.getSize();
			var draggable = this;
			clone.target = this.target;

			var scrTop = $CONTENT('wrapper', self.assessment.contentDoc).getScrollTop();

			clone.setStyles({opacity:0,position:'absolute',left:origin.x,top:origin.y+scrTop,width:size.x,height:size.y}).inject(container);

			clone.makeDraggable({
				droppables:self.targetElements,
				snap:15,
				onSnap:function(el){
					el.setStyle('opacity',0.7);
				},
				onEnter:function(el,drop){
					drop.addClass('dragover');
					el.addClass('dragover');
				},
				onLeave:function(el,drop){
					drop.removeClass('dragover');
					el.removeClass('dragover');
				},
				onDrop:function(el,drop){
					if(drop)
					{
						draggable.drop = drop;
						draggable.droppedIndex = self.countDrops();
						drop.innerHTML += '<div class="singleTargetItem"><div class="targetItemNumber">'+draggable.droppedIndex+'</div>'+unescape(draggable.label)+'</div>';
						var dropTitle = drop.get('title');
						drop.set('title',dropTitle+'. '+draggable.title);
						drop.removeClass('dragover');
						clone.destroy();

						draggable.removeEvents('mousedown');
						draggable.removeClass('dragActive');
						draggable.setStyles({opacity:0.7});
						drop.parentNode.tabIndex = -1;
						draggable.parentNode.tabIndex = -1;
						draggable.parentNode.enabled = false;
						drop.parentNode.enabled = false;
						

						self.selectedElement = null;

						$CONTENT('draggablesContainer', self.assessment.contentDoc).getElements('div.dragContent').each(function (el) {
							el.removeClass('dragSelected');
							el.set('aria-grabbed',false);
						});

						self.assessInteraction();
					}
					else
					{
						draggable.correct = false;
						draggable.drop = null;
						el.get('morph').start({
							opacity:0,
							left:origin.x,
							top:origin.y+scrTop
						}).chain(el.destroy.bind(el));

						self.assessInteraction();
					}
				}
			}).start(ev);
		});
	};

	this.createTouchDragEvents=function()
	{
		var self = this;
		var dragClones = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragClone');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		dragClones.addEvents({
			'touchend':function(e)
			{
				if(!this.moving)
				{
					return;
				}
				this.moving = false;

				var droppedTarget = $CONTENT('tContent', this.assessment.contentDoc);
				
				if (Utils.dom.hitTest(this, $CONTENT('tContent', this.assessment.contentDoc)))
				{
					this.dragEl.drop = droppedTarget;
					this.dragEl.droppedIndex = self.countDrops();
					droppedTarget.innerHTML += '<div class="singleTargetItem"><div class="targetItemNumber">'+this.dragEl.droppedIndex+'</div>'+this.label+'</div>';
					this.dragEl.setStyle('opacity',0.7);
					this.dContent.removeEvents();
					this.setStyle('display','none');
				}
				else
				{
					this.get('morph').start({
						opacity:0.01,
						left:this.origin.x,
						top:this.origin.y
					});

					this.dragEl.drop = null;
					this.dragEl.correct = false;
					self.assessInteraction();
				}
				
				self.assessInteraction();
				
				e.preventDefault();
				e.stopPropagation();
			},
			'touchmove':function(e)
			{
				e.preventDefault();
				e.stopPropagation();

				this.moving = true;

				var t = e.targetTouches[0];
				if(t == null){return}

				this.setStyle('opacity',0.75);

				this.setStyle('left', ((t.pageX-(this.getStyle('width').toInt()/2)))-container.getPosition().x);
				this.setStyle('top', ((t.pageY-(this.getStyle('height').toInt()/2)))-self.CONTENT_FRAME.contentScroller.y);
			}
		})
	};

	this.disableDraggables=function()
	{
		if(Utils.browserDetection.isMobile())
		{
		    var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragClone');
		}
		else
		{
		    var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.draggableMany');
		    var dragContent = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragContent');
			dragContent.removeEvents();
		}
		$CONTENT('tContent', this.assessment.contentDoc).removeEvents();
		draggables.removeEvents();		
	};

	this.toString=function()
	{
		return 'DragDropManyToOne Instance';
	};
}
DragDropSequencing.prototype = Utils.object.extend(DragDropStandard.prototype);
