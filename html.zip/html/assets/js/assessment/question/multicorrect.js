/** 
* Defines the MultiCorrect object for Multiple-Correct interactions
* @requires Question
* @extends Question
* @constructor
*/
function MultiCorrect(o)
{
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "MultiCorrect";
	
	// Used by SCORM interactions
	this.interactionsType = "choice";
	
	this.render=function()
	{
		var html=''
	
		html+='<div class="question">\n';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';
		
		if(this.img !== null)
		{
			html+='<table class="countImages" width="100%"><tr><td width="50%" valign="top">';
		}
	
		for(var i=0;i<this.choices.length; i++)
		{
			if(Utils.string.stripTags(unescape(this.choices[i].txt)) != "")
			{
				html+='<div class="choice">\n';
				html+='	<table class="choiceTable"><tr>';
				html+='		<td><input type="checkbox" name="'+this.name+'" id="'+this.name+i+'" value="'+i+'"></td>\n';
				html+='		<td><label for="'+this.name+i+'">'+unescape(this.choices[i].txt)+'</label></td>\n';
				html+='	</tr></table>';
				html+='</div>\n';
			}
		}
		
		if(this.img != null)
		{
			this.align = (this.align) || "left";
			this.valign = (this.valign) || "top";
			html+='<td width="50%" align="'+this.align+'" valign="'+this.valign+'"><img src="images/'+this.img+'" alt="' + unescape(this.caption) + '" title="' + unescape(this.caption) + '" onload="checkAssessImagesLoaded(this);" onerror="errAssessImagesLoaded();" onreadystatechange="checkAssessImagesLoaded(this);" id="'+this.imgId+'" style="'+unescape(this.style)+'"></td>';
			html+='</td></tr></table>';
		}	
		
		html+='<div class="corFb" id="'+this.name+'_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='</div>';
	
		return html;
	};
	
	this.isAnswered=function()
	{
		var contentDoc = this.assessment.contentDoc;
		var len = contentDoc.forms["contentForm"][this.name].length;
	
		this.answered = false;
		
		for(var i=0;i<len; i++)
		{
			if(contentDoc.forms["contentForm"][this.name][i].checked)
			{
				this.answered = true;
			}
		}
			
		return this.answered;
	};
	
	this.isCorrect=function()
	{
		var len = this.choices.length;
	
		this.correct = true;
	
		for(var i=0;i<len; i++)
		{
			if(this.studentResponse[i] != this.correctResponse[i])
			{
				this.correct = false;
			}
		}
		
		return this.correct;
	};
	
	this.setCorrectResponse=function()
	{
		var correctResponses = [];
		for(var i=0;i<this.choices.length;i++)
		{
			if(this.choices[i].correct)
			{
				correctResponses.push(this.choices[i].cid);
			}
		}
		
		this.correctResponse = correctResponses;
		Utils.debug.trace("Interaction - correct response: "+this.correctResponse.join(engine.comm.groupSep));
		
		if (this.assessment.isPostAssessment)
		{
			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, this.correctResponse.join(engine.comm.groupSep));
		}
	};
	
	this.setStudentResponse=function()
	{
		var contentDoc = this.assessment.contentDoc;
		var checkboxObj = contentDoc.forms["contentForm"][this.name];
		var studentResponses = [];
		
		if(!checkboxObj)
		{
			return "";
		}
	
		var checkboxLength = checkboxObj.length;
	
		for(var i = 0; i < checkboxLength; i++)
		{
			if(checkboxObj[i].checked)
			{
				studentResponses.push(this.choices[i].cid);
			}
		}
		
		this.studentResponse = studentResponses;
		Utils.debug.trace("Interaction - student response: "+this.studentResponse.join(engine.comm.groupSep));
		
		if (this.assessment.isPostAssessment)
		{
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, this.studentResponse.join(engine.comm.groupSep));
		}
	};
	
	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+unescape(this.getResponseTxtByCid(this.studentResponse))+'</span>';
		html += '</p>';
		
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+unescape(this.getResponseTxtByCid(this.correctResponse))+'</span>';
			html += '</p>';
		}
		
		return html;
	};
	
	this.getResponseTxtByCid=function(cid)
	{
		var a = [];
		for(var i=0;i<this.choices.length;i++)
		{
			for(var j=0;j<cid.length;j++)
			{
				if(this.choices[i].cid == cid[j])
				{
					a.push(unescape(this.choices[i].txt).replace(/<\/?[^>]+(>|$)/g, ""));
				}
			}
		}

		var strippedTagsString = a.join("<br>");
		return strippedTagsString;
	};
	
	this.init = function(contentFrame)
	{
	    var contentDoc = (contentFrame.document || this.assessment.contentDoc);;
		
		if (this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
			
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);
			
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, this.stem);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);
		}
		contentDoc.getElementById("btnContinue").value = unescape(Lang.UI_ASSESS_SUBMIT);
		
		// Set the correct response - utilized by SCORM interactions and summary pages
		this.setCorrectResponse();
		
		if(this.img == null){
			this.assessment.renderRemaining();
		}
	};
	
	this.focus = function()
	{
	    var contentDoc = this.assessment.contentDoc;
		
		if (contentDoc.forms["contentForm"][this.name])
		{
			var self = this;
			if (contentDoc.forms["contentForm"][this.name][0])
			{
				setTimeout(function(){contentDoc.forms["contentForm"][self.name][0].focus();},0);
			}
			else	
			{
				setTimeout(function(){contentDoc.forms["contentForm"][self.name].focus();},0);
			}
		}
	};
}
MultiCorrect.prototype = Utils.object.extend(Question.prototype);

