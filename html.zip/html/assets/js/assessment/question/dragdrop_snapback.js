/** 
* Defines the DragDropSnapBack object for Snap-back Drag-n-Drop interactions
* @requires Question
* @extends Question
* @constructor
*/
function DragDropSnapBack(o)
{
	DragDropStandard.call(this,o);
	
	// Used by assessment
	this.quesType = "DragDrop";
	
	// Used by SCORM interactions
	this.interactionsType = "matching";

	this.assessMatch = function(el)
	{
		if(!this.selectedElement || !this.focusedElement){return;}

		el = (el) ? el : this.focusedElement;

		var draggable = this.selectedElement.getElements('div')[0];
		var target = el.getElements('div')[0];

		if(el.targetId == this.selectedElement.target)
		{
			Utils.debug.trace('correct!');
			draggable.correct = true;

			target.innerHTML = draggable.innerHTML;

			this.selectedElement.removeEvents('click');
			this.selectedElement.tabIndex = -1;
			el.enabled = false;
			el.tabIndex = -1;
			draggable.drop = target;

			draggable.removeEvents('mousedown');
			draggable.removeClass('dragActive');
			draggable.setStyles({opacity:0.7});

			this.selectedElement = null;

			$CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragContent').each(function (el) {
				el.removeClass('dragSelected');
			});
		}
		else
		{
			Utils.debug.trace('incorrect!');
			draggable.correct = false;
		}

		this.assessInteraction();
	};

	this.createDragEvents=function()
	{
		var self = this;
		var allowance = 10;
		var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.draggable');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		draggables.addEvent('mousedown',function(ev){
			var clone = this.clone();
			var origin = this.getPosition();
			var draggable = this;
			clone.target = this.target;

			var scrTop = $CONTENT('wrapper', self.assessment.contentDoc).getScrollTop();

			clone.setStyles({opacity:0.7,position:'absolute',left:origin.x,top:origin.y+scrTop}).inject(container);

			clone.makeDraggable({
				droppables:self.targetElements,
				onEnter:function(el,drop){
					if(!drop.parentNode.enabled){return;}
					drop.addClass('dragover');
					el.addClass('dragover');
				},
				onLeave:function(el,drop){
					if(!drop.parentNode.enabled){return;}
					drop.removeClass('dragover');
					el.removeClass('dragover');
				},
				onDrop:function(el,drop){
					if(drop)
					{
						if(!drop.parentNode.enabled)
						{
							el.get('morph').start({
								opacity:0,
								left:origin.x,
								top:origin.y+scrTop
							}).chain(el.destroy.bind(el));
							return;
						}
						if(drop.targetId == el.target)
						{
							Utils.debug.trace('correct!');
							draggable.correct = true;

							drop.innerHTML = clone.innerHTML;
							drop.removeClass('dragover');
							clone.destroy();

							draggable.removeEvents('mousedown');
							draggable.removeClass('dragActive');
							drop.removeClass('dragover');
							draggable.setStyles({opacity:0.7});
							drop.parentNode.tabIndex = -1;
							draggable.parentNode.tabIndex = -1;
							draggable.parentNode.enabled = false;
							drop.parentNode.enabled = false;
							draggable.drop = drop;

							self.assessInteraction();
						}
						else
						{
							Utils.debug.trace('incorrect!');
							draggable.drop = null;
							draggable.correct = false;
							drop.removeClass('dragover');
							el.get('morph').start({
								opacity:0,
								left:origin.x,
								top:origin.y+scrTop
							}).chain(el.destroy.bind(el));

							self.assessInteraction();
						}
					}
					else
					{
						draggable.correct = false;
						draggable.drop = null;
						el.get('morph').start({
							opacity:0,
							left:origin.x,
							top:origin.y+scrTop
						}).chain(el.destroy.bind(el));

						self.assessInteraction();
					}
				}
			}).start(ev);
		});
	};

	this.createTouchDragEvents=function()
	{
		var self = this;
		var dragClones = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragClone');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		dragClones.addEvents({
			'touchend':function(e)
			{
				if(!this.moving)
				{
					return;
				}
				this.moving = false;

				var correctTarget = $CONTENT(this.target, self.assessment.contentDoc);

				if(Utils.dom.hitTest(this,correctTarget))
				{
					this.dragEl.correct = true;
					correctTarget.innerHTML = this.innerHTML;

					this.dragEl.drop = correctTarget;
					this.dragEl.setStyle('opacity',0.7);
					
					this.setStyle('display','none');
				}
				else
				{
					this.dragEl.correct = false;
					this.dragEl.drop = null;

					this.get('morph').start({
						opacity:0.1,
						left:this.origin.x,
						top:this.origin.y
					});
				}

				self.assessInteraction();
				
				e.preventDefault();
				e.stopPropagation();
			},
			'touchmove':function(e)
			{
				e.preventDefault();
				e.stopPropagation();

				this.moving = true;

				var t = e.targetTouches[0];
				if(t == null){return}

				this.setStyle('opacity',0.75);

				this.setStyle('left', ((t.pageX-(this.getStyle('width').toInt()/2)))-container.getPosition().x);
				this.setStyle('top', (t.pageY-(this.getStyle('height').toInt()/2)));
			}
		})
	};

	this.toString=function()
	{
		return 'DragDropSnapBack Instance';
	};
}
DragDropSnapBack.prototype = Utils.object.extend(DragDropStandard.prototype);


