/** 
* Defines the Sim object for simulation-based interactions
* @requires Question
* @extends Question
* @constructor
*/
function Sim(o)
{
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "Sim";
	
	// Used by SCORM interactions
	this.interactionsType = "true-false";
	
	this.render=function()
	{
		var html=''
	
		
		if(this.directions != "")
		{
			html+='<div>\n';
		}
		else
		{
		html+='<div class="question">\n';
		}	
	
		if (this.img != null)
		{
		    html += '<div>\n';
		    html += '<table class="countImages" width="100%"><tr>';
		    this.align = (this.align) || "left";
		    this.valign = (this.valign) || "top";
		    html += '<td align="' + this.align + '" valign="' + this.valign + '"><img src="images/' + this.img + '" alt="' + unescape(this.caption) + '" title="' + unescape(this.caption) + '" onload="checkAssessImagesLoaded(this);" onerror="errAssessImagesLoaded();" onreadystatechange="checkAssessImagesLoaded(this);" id="' + this.imgId + '" style="' + unescape(this.style) + '"></td>';
		    html += '<td valign="top">';
		}

		html += '<div><p>' + unescape(this.stem) + '</p></div>\n';

		if (!this.assessment.isPostAssessment) {
		    for (var i = 0; i < this.choices.length; i++) {
		        html += '<div class="choice">\n';
		        html += '<input type="button" name="' + this.name + this.choices[i].mode + '" id="' + this.name + this.choices[i].mode + '"  class="uiSecondaryBackgroundColor uiTextColor simButton" value="' + unescape(this.choices[i].txt) + '" onclick="openSim(\'' + this.simId + '\',' + this.choices[i].mode + ');">\n';
		        html += '</div>\n';
		    }
		}
		else {
		    for (var i = 0; i < this.choices.length; i++) {
		        if (this.choices[i].mode == 3) {
		            html += '<div class="choice">\n';
		            html += '<input type="button" name="' + this.name + 3 + '" id="' + this.name + 3 + '"  class="uiSecondaryBackgroundColor uiTextColor simButton" value="' + unescape(this.choices[i].txt) + '" onclick="openSim(\'' + this.simId + '\',3);">\n';
		            html += '</div>\n';
		        }
		    }
		}

		if (this.img != null) {
		    html += '</td></tr></table></div>';
		}

		html += '<div class="corFb" id="' + this.name + '_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
	
		html+='</div>';
	
		return html;
	};
	
	this.isAnswered=function(contentDoc)
	{
		return this.answered;
	};
	
	this.isCorrect=function(contentDoc)
	{
		return this.correct;
	};
	
	this.isSkipped=function(contentDoc){
		return this.skipped;
	}
	
	this.setCorrectResponse=function()
	{
		this.correctResponse = true;
		Utils.debug.trace("Interaction - correct response: "+JSON.encode(this.correctResponse));
		
		if (this.assessment.isPostAssessment)
		{
			// Set the correct response in the SCORM interactions data
			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, engine.comm.interactionTrueString);
		}
	};
	
	this.setStudentResponse=function(studentResponse)
	{
		if(!studentResponse){return;}
		
		// We have a response, so the user completed the simulation
		this.answered = true;
		
		// Parse the simulation's SCORM 1.2 API object
		var simApiObj = JSON.decode(studentResponse.simApi);
		
		// Grab the raw score element
		//var score = (simApiObj._data_elements["score"]) ? simApiObj._data_elements["score"] : simApiObj._data_elements["cmi.core.score.raw"];
		// UPC-11610 Changed condition to check for undefined which should cover null value as well.
		var score = (typeof simApiObj._data_elements["score"] != 'undefined') ? simApiObj._data_elements["score"] : simApiObj._data_elements["cmi.core.score.raw"];
	
		var lesson_status = (simApiObj._data_elements["lesson_status"]) ? simApiObj._data_elements["lesson_status"] : simApiObj._data_elements["cmi.core.lesson_status"];
		Utils.debug.trace(lesson_status);
		if(lesson_status == "passed" || lesson_status == "completed")
		{
			this.correct = true;
		}
		else if(lesson_status == "failed" || lesson_status == "incomplete")
		{
			this.correct = false;
		}

		if(lesson_status == "undefined")
		{
			Utils.debug.trace("Error: Cannot get lesson status from simulation.  Are you sure the sim was published as a SCORM 1.2 package before being imported?");
		}
		
		// Build the student response object
		var o = {};
		o.title = studentResponse.title;
		o.score = score;
		o.correct = this.correct;
		o.totalToInclude = studentResponse.totalToInclude;
		o.totalIncorrect = studentResponse.totalIncorrect;
		o.incStepNumberList = escape(studentResponse.incStepNumberList);
		this.studentResponse = o;

		Utils.debug.trace("Interaction - student response: "+JSON.encode(this.studentResponse));
		
		if(this.assessment.isPostAssessment)
		{
			var descString = ((typeof this.studentResponse.title != "undefined") && (this.studentResponse.title != "undefined")) ? this.studentResponse.title : escape("Sim #"+(this.orgIndex+1));
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, descString);

			// True-False interactions have different response string values between SCORM versions
			var resultString = (this.correct) ? engine.comm.interactionTrueString : engine.comm.interactionFalseString;
			
			// Set the student's response in the SCORM interactions data
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, resultString);
		}
		
		// Tell the assessment to move on...
		this.assessment.autoAdvance();
	};
	
	this.getSummary=function()
	{
		var html = '';
		
		try {
		// Student Response
		if((typeof this.studentResponse.title != "undefined") && (this.studentResponse.title != "undefined"))
		{
			html += '<p><b>'+unescape(this.studentResponse.title)+'</b></p>';
		}
		else
		{
			html += '<p><b>'+unescape(Lang.ASSESSMENT_SIM_GEN_INCORRECT_STEPS)+'</b></p>';
		}
		
		html += '<p><span class="response">';
		
		html += unescape(Lang.ASSESSMENT_SIM_ACCURACY)+':';
		html += '<i>'+this.studentResponse.score+'%</i>';
		html += '<br>';
		
		if(this.studentResponse.totalToInclude)
		{
			html += unescape(Lang.ASSESSMENT_SIM_TOTAL_STEPS)+':';
			html += '<i>'+this.studentResponse.totalToInclude+'</i>';
			html += '<br>';
		}
		
		if(this.studentResponse.totalIncorrect)
		{
			html += unescape(Lang.ASSESSMENT_SIM_NUM_INC_STEPS)+':';
			html += '<i>'+this.studentResponse.totalIncorrect+'</i>';
			html += '<br>';
		}
		
		if(this.studentResponse.incStepNumberList)
		{
			html += unescape(Lang.ASSESSMENT_SIM_INCORRECT_STEPS)+':';
			html += '<i>'+unescape(this.studentResponse.incStepNumberList)+'</i>';
		}
		
		html += '</p></span>';
		} catch(error){
			if (this.isSkipped()){
				html += '<p><span class="response"><i>' + unescape(Lang.ASSESSMENT_SIM_SKIPPED_RESULT)+ '</i></p></span>';
			}
		}
		
		return html;
	};
	
	this.init = function(contentFrame)
	{
	    var contentDoc = (contentFrame.document || this.assessment.contentDoc);
		
		if(this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
			
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);
		}
		// Set the correct response - utilized by SCORM interactions and summary pages
		this.setCorrectResponse();
		
		if(this.img == null){
			this.assessment.renderRemaining();
		}
	};
	
	this.focus = function()
	{
	    var contentDoc = this.assessment.contentDoc;
		
		if (contentDoc.forms["contentForm"].elements.length > 0)
		{
			setTimeout(function(){contentDoc.forms["contentForm"][0].focus();},0);
		}
	};
}
Sim.prototype = Utils.object.extend(Question.prototype);



