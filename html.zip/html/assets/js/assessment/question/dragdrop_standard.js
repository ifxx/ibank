/** 
* Defines the DragDropStandard object for standard Drag-n-Drop interactions
* @requires Question
* @extends Question
* @constructor
*/
function DragDropStandard(o)
{
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "DragDrop";
	
	// Used by SCORM interactions
	this.interactionsType = "matching";
	
	this.draggables = [];
	this.targets = [];

	this.draggableElements = [];
	this.targetElements = [];

	this.selectedElement = null;
	this.focusedElement = null;

	this.randTargets = [];

	this.addDrag=function(o)
	{
		if(Utils.string.stripTags(unescape(o.label)) === ""){return;}
		var idx = this.draggables.push(o);
		o.origIndex = idx-1;
	};
	
	this.addTarget=function(o)
	{
		if(Utils.string.stripTags(unescape(o.label)) === ""){return;}
		var idx = this.targets.push(o);
		o.origIndex = idx-1;
	};
	
	this.render=function()
	{
		var html=''
	
		html+='<div class="question">\n';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';
		
		html+='<div id="dndContainer" role="application">';
		html+='	<div id="draggablesContainer"></div>';
		html+='	<div id="targetsContainer"></div>';
		html+='</div>';

		html+='<div class="clear"></div>';
		
		html+='<div class="corFb" id="'+this.name+'_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';		
		
	
		html+='</div>';
	
		return html;
	};
	
	this.isAnswered=function()
	{
		return this.answered;
	};
	
	this.isCorrect=function()
	{
		this.correct = true;
		for(var i = 0;i<this.studentResponse.length;i++)
		{
			if(!this.studentResponse[i].correct)
			{
				this.correct = false;
			}
		}
		return this.correct;
	};
	
	this.setCorrectResponse=function(correctResponse)
	{
		if(!correctResponse){return;}
		this.correctResponse = correctResponse;
		Utils.debug.trace("Interaction - correct response: "+JSON.encode(correctResponse));
		
		if (this.assessment.isPostAssessment)
		{
			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, this.getInteractionsResponse(this.correctResponse));
		}
	};
	
	this.setStudentResponse=function(studentResponse)
	{
		if(!studentResponse){return;}
		this.studentResponse = studentResponse;
		Utils.debug.trace("Interaction - student response: "+JSON.encode(studentResponse));
		
		if (this.assessment.isPostAssessment)
		{
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, this.getInteractionsResponse(this.studentResponse));
		}
	};
	
	this.getInteractionsResponse=function(responseObj)
	{
		var responsesArray = [];
		for(var i=0;i<responseObj.length;i++)
		{
			// {"targetIdx":1,"dragAlpha":"a","targetText":"Red","dragText":"Apple","correct":true}
			responsesArray.push(escape(responseObj[i].dragIdx)+engine.comm.matchSep+escape(responseObj[i].targetAlpha));
		}
		
		return responsesArray.join(engine.comm.groupSep);
	};

	this.getStudentResponse=function()
	{
		//Create a student response containing all drag/drop pairs as objects in an array
		var response = [];
		this.draggableElements.each(function(d,i){
			//Create the drag/drop pair
			var o  = {};
			o.correct = d.correct;
			o.dragText = d.label;
			o.targetText = d.drop.label;
			o.dragIdx = (i+1);
			o.targetAlpha = this.alphas[d.drop.targetIdx];
			
			Utils.debug.trace("Setting student response: "+o.dragText+" ("+o.dragIdx+"), "+o.targetText+" ("+o.targetAlpha+"), "+o.correct);

			//Add the drag/drop pair to the response array
			response.push(o);
		},this);
		return response;
	}

	this.getCorrectResponse=function()
	{
		this.injectDraggableTargets();

		//Create a correct response containing all drag/drop pairs as objects in an array
		var response = [];
		this.draggables.each(function(d,i){
			//Create the drag/drop pair

			var o  = {};
			o.dragText = d.label;
			o.targetText = d.targetObj.label;
			o.dragIdx = (i+1);
			o.targetAlpha = this.alphas[i];
			
			Utils.debug.trace("Setting correct response: "+o.dragText+" ("+o.dragIdx+"), "+o.targetText+" ("+o.targetAlpha+")");

			//Add the drag/drop pair to the response array
			response.push(o);
		},this);
		return response;
	};

	this.injectDraggableTargets=function()
	{
		var target = null;
		this.draggables.each(function(d,i){
			var t = this.targets[i];
			if(t.id == d.target)
			{
				d.targetObj = t;
			}
		},this);
	};

	this.countDrops=function()
	{
		var int = 0;
		this.draggableElements.each(function(d,i){
			if(d.drop)
			{
				int++;
			}
		},this);
		return int;
	};
	
	this.assessInteraction=function()
	{
		this.assessment.enableReset();
		this.assessment.enableContinue();
		if(this.countDrops() == this.draggableElements.length)
		{
			var studentResponse = this.getStudentResponse();
			this.setStudentResponse(studentResponse);

			this.answered = true;
		}
		else
		{
			this.answered = false;
		}
	};
	
	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+this.getResponseTxt(this.studentResponse)+'</span>';
		html += '</p>';
		
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+this.getResponseTxt(this.correctResponse)+'</span>';
			html += '</p>';
		}
		
		return html;
	};
	
	this.getResponseTxt=function(responseObj)
	{
		var html = '';
		for(var i=0;i<responseObj.length;i++)
		{
			// {"targetIdx":1,"dragAlpha":"a","targetText":"Red","dragText":"Apple","correct":true}
			html += '<p><b>'+unescape(responseObj[i].dragText)+"</b> &gt; "+unescape(responseObj[i].targetText)+'</p>';
		}
		
		return html;
	};

	this.setTargetIndexes=function()
	{
		for(var i = 0;i<this.targets.length;i++)
		{
			this.targets[i].idx = i+1;
		}
	}

	this.showMe=function()
	{
		try
		{
			this.draggableElements.each(function(d){
				
				var dContent = d.parentNode;
				var target = null;

				this.targetElements.each(function(t){
					if(t.targetId == d.target)
					{
						target = t;
					}
				},this);

				target.innerHTML = d.innerHTML;

				d.correct = false;
				dContent.enabled = false;
				d.drop = target;

				dContent.removeEvents('click');
				dContent.tabIndex = -1;

				d.removeEvents('mousedown');
				d.removeClass('dragActive');
				d.setStyles({opacity:0.7});

			},this);

			this.selectedElement = null;
			this.answered=false;
		}
		catch(e){Utils.debug.trace("Error in showMe: "+(e.description || e),'error');}
	};
	
	this.init=function(contentFrame)
	{
		var self = this;

		this.answered = false;

		this.randTargets = this.targets.slice(0);

		this.CONTENT_FRAME = this.assessment.contentFrame;
		this.CONTENT_DOC = this.assessment.contentDoc;
				
		if(this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
	
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);
			
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, this.stem);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);

			// Set the correct response array for remediation and SCORM interaction data
			var correctResponse = this.getCorrectResponse();
			this.setCorrectResponse(correctResponse);
		}
		this.CONTENT_DOC.getElementById("btnContinue").value = unescape(Lang.UI_ASSESS_SUBMIT);
		
	    //Since we apply preload page so function $CONTENT work incorrectly
		//var draggablesContainer = $CONTENT('draggablesContainer');
	    //var targetsContainer = $CONTENT('targetsContainer');
		var draggablesContainer = this.CONTENT_DOC.getElementById('draggablesContainer');
		var targetsContainer = this.CONTENT_DOC.getElementById('targetsContainer');

		this.draggableElements = [];
		this.targetElements = [];

		this.selectedElement = null;
		this.focusedElement = null;

		this.makeDraggables(draggablesContainer);
		this.makeTargets(targetsContainer);
		if(!Utils.browserDetection.isMobile())
		{
			this.createDragEvents();
		}
		else
		{
			this.createTouchDragEvents();
		}

		var dndContainer = this.CONTENT_DOC.getElementById('dndContainer');
		Utils.dom.unselectable(dndContainer);
		var self = this;
		if (this.CONTENT_DOC.getElementById('dContent0'))
		{
			setTimeout(function(){
			    self.CONTENT_DOC.getElementById('dContent0').focus();
			}, 0);
		}
		
		this.assessment.renderRemaining();
	};

	this.dragFocused = function(e,el)
	{
		if(!el.enabled){return;}
		engine.ui.contentFocused = true;
		this.focusedElement = el;
	};

	this.dragClicked = function(e,el)
	{
		if(this.selectedElement)
		{
			if(!this.selectedElement.enabled){return;}
		}

		if(!el.enabled){return;}

		e.preventDefault();

		this.selectedElement = el;

		this.selectDrag(el);
	};

	this.selectDrag = function(el)
	{
		if(!el.enabled){return;}

		this.CONTENT_DOC.getElementById('draggablesContainer').getElements('div.dragContent').each(function (otherEl) {
			otherEl.removeClass('dragSelected');
			otherEl.title = Lang.ACCESSIBILITY_DRAGGABLE+'-'+Lang.ACCESSIBILITY_DESELECTED+': '+unescape(otherEl.label);
			otherEl.set('aria-grabbed',false);
		},this);

		el = (el) ? el : this.focusedElement;

		el.addClass('dragSelected');
		el.set('aria-grabbed',true);

		this.selectedElement = el;
		this.selectedElement.title = Lang.ACCESSIBILITY_DRAGGABLE+'-'+Lang.ACCESSIBILITY_SELECTED+': '+unescape(this.selectedElement.label);
	};

	this.targetClicked = function(e,el)
	{
		if(!el.enabled){return;}

		if(el.isTarget)
		{
			this.assessMatch(el);
		}
	};

	this.targetFocused = function(e,el)
	{
		engine.ui.contentFocused = true;
		this.focusedElement = el;
	};

	this.assessMatch = function(el)
	{
		if(!this.selectedElement || !this.focusedElement){return;}

		el = (el) ? el : this.focusedElement;

		var draggable = this.selectedElement.getElements('div')[0];
		var target = el.getElements('div')[0];

		if(el.targetId == this.selectedElement.target)
		{
			Utils.debug.trace('correct!');
			draggable.correct = true;
		}
		else
		{
			Utils.debug.trace('incorrect!');
			draggable.correct = false;
		}

		target.innerHTML = draggable.innerHTML;

		this.selectedElement.removeEvents('click');
		this.selectedElement.tabIndex = -1;
		el.enabled = false;
		el.tabIndex = -1;
		draggable.drop = target;

		draggable.removeEvents('mousedown');
		draggable.removeClass('dragActive');
		draggable.setStyles({opacity:0.7});

		this.selectedElement = null;

		$CONTENT('draggablesContainer').getElements('div.dragContent').each(function(el){
			el.removeClass('dragSelected');
			el.set('aria-grabbed',false);
		});

		this.assessInteraction();
	};
	
	// Fix http://jira.ancile.com/browse/UPC-15318
	function html_entity_decode(str){
		var tarea=document.createElement('textarea');
		tarea.innerHTML = str;
		return tarea.value;
		tarea.parentNode.removeChild(tarea);
	}

	this.makeDraggables=function(container)
	{
		var self = this;

		// create draggables
		this.draggables.each(function(item,index){
			
			// Create draggableContent container
			var dContent = this.CONTENT_DOC.newElement('div',{
				id: 'dContent'+index,
				title: Lang.ACCESSIBILITY_DRAGGABLE+'-'+Lang.ACCESSIBILITY_DESELECTED+': '+html_entity_decode(unescape(item.label)),
				tabIndex: 0,
				events:{
					'click': function(e) {
						self.dragClicked(e,this);
						e.stop();
					},
					'focus': function(e) {
						self.dragFocused(e,this);
					},
					'keydown': function(e){
						if(e.code == 32 || e.code == 13)
						{
							self.selectDrag(this);
							e.stop();
						}
					}
				}
			}).inject(container);
			dContent.enabled = true;
			dContent.label = item.label;
			dContent.drop = null;
			dContent.isDraggable = true;
			dContent.isTarget = false;
			dContent.target = item.target;
			dContent.set('aria-grabbed',false);
			dContent.addClass('clearfix');
			dContent.addClass('dragContent');
			dContent.addClass('uiContentDragDropStyle');

			// Create draggable element
			var draggable = this.CONTENT_DOC.newElement('div',{
			    id: 'draggable'+index,
				text: (index+1)
			}).inject(dContent);
			draggable.label = item.label;
			draggable.addClass('uiTextColor');
			draggable.addClass('uiSecondaryBackgroundColor');
			draggable.addClass('draggable');
			draggable.addClass('dragActive');
			draggable.target = item.target;
			this.draggableElements.push(draggable);

			if(Utils.browserDetection.isMobile())
			{
				var clone = draggable.clone();
				var z = draggable.getStyle('z-index');
				var origin = draggable.getPosition();
				
				clone.setStyles({
					opacity:0.01,
					position:'absolute',
					left:origin.x,
					top:origin.y,
					zIndex:z+1
				}).inject(container);
				clone.addClass('dragClone');
				clone.target = item.target;
				clone.label = item.label;
				clone.dragEl = draggable;
				clone.origin = origin;
			}

			// Create drag label
			var dLabel = this.CONTENT_DOC.newElement('div',{
				id: 'dLabel'+index,
				text: html_entity_decode(unescape(item.label))
			}).inject(dContent);
			dLabel.addClass('dragLabel');

		},this);
	};

	this.makeTargets=function(container)
	{
		var self = this;

		this.setTargetIndexes();

		Utils.array.fisherYates(this.randTargets);

		// create targets from randomized targets
		this.randTargets.each(function(item,index){
			
			// Create targetContent container
			var tContent = this.CONTENT_DOC.newElement('div',{
				id: 'tContent'+index,
				title: Lang.ACCESSIBILITY_TARGET+': '+unescape(item.label),
				tabindex: 0,
				events:{
					'click': function(e) {
						self.targetClicked(e,this);
					},
					'focus': function(e) {
						self.targetFocused(e,this);
					},
					'keydown': function(e){
						if((e.control && e.code == 77) || e.code == 13 || e.code == 32)
						{
							self.assessMatch(this);
							e.stop();
						}
					}
				}
			}).inject(container);
			tContent.enabled = true;
			tContent.isDraggable = false;
			tContent.isTarget = true;
			tContent.targetId = item.id;
			tContent.targetIdx = item.origIndex;
			tContent.set('aria-dropeffect','move');
			tContent.addClass('clearfix');
			tContent.addClass('targetContent');

			// Create target element
			var target = this.CONTENT_DOC.newElement('div',{
			    'id': item.id,
				'text': ''
			}).inject(tContent);
			target.addClass('target');
			target.label=unescape(item.label);
			target.idx=item.idx;
			target.targetId = item.id;
			target.targetIdx = item.origIndex;

			// Create target label
			var tLabel = this.CONTENT_DOC.newElement('div',{
				id: 'tLabel'+index,
				text: unescape(item.label)
			}).inject(tContent);
			tLabel.addClass('targetLabel');

			this.targetElements.push(target);
		},this);
	};

	this.createDragEvents=function()
	{
		var self = this;
		var allowance = 10;
		var draggables = this.CONTENT_DOC.getElementById('draggablesContainer').getElements('div.draggable');
		var container = this.CONTENT_DOC.getElementById('dndContainer');
			
		draggables.addEvent('mousedown',function(ev){
			var clone = this.clone();
			var origin = this.getPosition();
			var draggable = this;
			clone.target = this.target;

			self.dragClicked(ev,draggable.parentNode);

			var scrTop = self.CONTENT_DOC.getElementById('wrapper').getScrollTop();

			clone.setStyles({opacity:0.01,position:'absolute',left:origin.x,top:origin.y+scrTop}).inject(container);
			clone.addEvents({
				'click': function(e) {
					self.dragClicked(e,draggable.parentNode);
					e.stop();
				}
			});

			clone.makeDraggable({
				droppables:self.targetElements,
				snap:15,
				onSnap:function(el){
					el.setStyle('opacity',0.7);
					self.dragClicked(ev,draggable.parentNode);
				},
				onEnter:function(el,drop){
					if(!drop.parentNode.enabled){return;}
					drop.addClass('dragover');
					el.addClass('dragover');
				},
				onLeave:function(el,drop){
					if(!drop.parentNode.enabled){return;}
					drop.removeClass('dragover');
					el.removeClass('dragover');
				},
				onDrop:function(el,drop){
					if(drop)
					{
						if(!drop.parentNode.enabled)
						{
							el.get('morph').start({
								opacity:0,
								left:origin.x,
								top:origin.y
							}).chain(el.destroy.bind(el));
							return;
						}
						if(drop.targetId == el.target)
						{
							Utils.debug.trace('correct');
							draggable.correct = true;
						}
						else
						{
							Utils.debug.trace('incorrect');
							draggable.correct = false;
						}

						self.assessMatch(drop.parentNode);

						drop.innerHTML = clone.innerHTML;
						drop.removeClass('dragover');
						clone.destroy();

						draggable.removeEvents('mousedown');
						draggable.removeClass('dragActive');
						draggable.setStyles({opacity:0.7});
						drop.parentNode.tabIndex = -1;
						draggable.parentNode.tabIndex = -1;
						draggable.parentNode.enabled = false;
						drop.parentNode.enabled = false;
						draggable.drop = drop;

						self.assessInteraction();
					}
					else
					{
						draggable.drop = null;
						el.get('morph').start({
							opacity:0,
							left:origin.x,
							top:origin.y+scrTop
						}).chain(el.destroy.bind(el));

						self.assessInteraction();
					}
				}
			}).start(ev);
		});
	};

	this.createTouchDragEvents=function()
	{
		var self = this;
		var dragClones = this.CONTENT_DOC.getElementById('draggablesContainer').getElements('div.dragClone');
		var container = this.CONTENT_DOC.getElementById('dndContainer');
		
		dragClones.addEvents({
			'touchend':function(e)
			{
				if(!this.moving)
				{
					return;
				}
				this.moving = false;

				var droppedTarget = null;

				self.targetElements.each(function(item,index){
					if(Utils.dom.hitTest(this,item))
					{
						if(!item.parentNode.enabled){return;}
						droppedTarget = item
					}
				},this);

				if(droppedTarget != null)
				{
					droppedTarget.parentNode.enabled = false;
					
					droppedTarget.innerHTML = this.innerHTML;
					
					if (Utils.dom.hitTest(this, self.CONTENT_DOC.getElementById(this.target)))
					{
						this.dragEl.correct = true;
					}
					else
					{
						this.dragEl.correct = false;
					}
					this.dragEl.drop = droppedTarget;
					this.dragEl.setStyle('opacity',0.7);
					
					this.setStyle('display','none');

					self.assessInteraction();
				}
				else
				{
					this.get('morph').start({
						opacity:0.01,
						left:this.origin.x,
						top:this.origin.y
					});

					this.dragEl.drop = null;
					this.dragEl.correct = false;
					self.assessInteraction();
				}
				
				e.preventDefault();
				e.stopPropagation();
			},
			'touchmove':function(e)
			{
				e.preventDefault();
				e.stopPropagation();

				this.moving = true;

				var t = e.targetTouches[0];
				if(t == null){return}

				this.setStyle('opacity',0.75);

				this.setStyle('left', ((t.pageX-(this.getStyle('width').toInt()/2)))-container.getPosition().x);
				this.setStyle('top', ((t.pageY-(this.getStyle('height').toInt()/2)))-self.CONTENT_FRAME.contentScroller.y);
			}
		})
	};

	this.disableDraggables=function()
	{
		//...Many to One only
	};

	this.toString=function()
	{
		return 'DragDropStandard Instance';
	};
}
DragDropStandard.prototype = Utils.object.extend(Question.prototype);
