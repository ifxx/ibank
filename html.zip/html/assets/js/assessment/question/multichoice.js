﻿/** 
* Defines the MultiChoice object for Multiple-Choice interactions
* @requires Question
* @extends Question
* @constructor
*/
function MultiChoice(o)
{
    this.contentDoc = null;
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "MultiChoice";
	
	// Used by SCORM interactions
	this.interactionsType = "choice";
	
	this.render=function()
	{
		var html=''
	
		html+='<div class="question">\n';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';
		
		if(this.img != null)
		{
			html+='<table class="countImages" width="100%"><tr><td width="50%" valign="top">';
		}
	
		for(var i=0;i<this.choices.length; i++)
		{
			if(Utils.string.stripTags(unescape(this.choices[i].txt)) != "")
			{
				html+='<div class="choice">\n';
				html+='	<table class="choiceTable"><tr>';
				html+='		<td><input type="radio" name="'+this.name+'" id="'+this.name+i+'" value="'+i+'"></td>\n';
				html+='		<td><label for="'+this.name+i+'">'+unescape(this.choices[i].txt)+'</label></td>\n';
				html+='	</tr></table>';
				html+='</div>\n';
			}
		}
		
		if(this.img != null)
		{
			this.align = (this.align) || "left";
			this.valign = (this.valign) || "top";
			html+='<td width="50%" align="'+this.align+'" valign="'+this.valign+'"><img src="images/'+this.img+'" alt="' + unescape(this.caption) + '" title="' + unescape(this.caption) + '" onload="checkAssessImagesLoaded(this);" onerror="errAssessImagesLoaded();" onreadystatechange="checkAssessImagesLoaded(this);" id="'+this.imgId+'" style="'+unescape(this.style)+'"></td>';
			html+='</td></tr></table>';
		}
	
		html+='<div class="persistFb" id="'+this.name+'_persistFb">'+unescape(Lang.ASSESSMENT_YOUR_RESPONSE_HAS_BEEN_SAVED)+'</div>\n';
		
		html+='<div class="corFb" id="'+this.name+'_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='</div>';
	
		return html;
	};
	
	this.isAnswered=function()
	{
		var contentDoc = this.assessment.contentDoc;
		var len = contentDoc.forms["contentForm"][this.name].length;
	
		this.answered = false;
	
		for(var i=0;i<len; i++)
		{
			if(contentDoc.forms["contentForm"][this.name][i].checked)
			{
				this.answered = true;
			}
		}
	
		return this.answered;
	};
	
	this.isCorrect=function()
	{
		this.correct = (this.correctResponse == this.studentResponse);
		return this.correct;
	};
	
	this.setCorrectResponse=function()
	{
		for(var i=0;i<this.choices.length;i++)
		{
			if(this.choices[i].correct)
			{
				this.correctResponse = this.choices[i].cid;
			}
		}

		Utils.debug.trace("Interaction - correct response: "+this.correctResponse);
		
		if (this.assessment.isPostAssessment)
		{
			// Set the correct response in the SCORM interactions data
			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, this.correctResponse);
		}
	};
	
	this.setStudentResponse=function()
	{
		var contentDoc = this.assessment.contentDoc;
		var radioObj = contentDoc.forms['contentForm'][this.name];
		
		if(!radioObj)
		{
			return "";
		}
		
		var radioLength = radioObj.length;
	
		for(var i = 0; i < radioLength; i++)
		{
			if(radioObj[i].checked)
			{
				this.studentResponse = this.choices[i].cid;
				if(this.persistChoice)
				{
					Utils.debug.trace("Interaction - student response has been saved.");
					this.assessment.parentPageObj.persistedChoiceText = unescape(this.choices[i].txt);
				}
			}
		}

		Utils.debug.trace("Interaction - student response: "+this.studentResponse);
		
		if (this.assessment.isPostAssessment)
		{
			// Set the student's response in the SCORM interactions data
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, this.studentResponse);
		}
	};
	
	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+unescape(this.getResponseTxtByCid(this.studentResponse))+'</span>';
		html += '</p>';
		
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>'+(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+unescape(this.getResponseTxtByCid(this.correctResponse))+'</span>';
			html += '</p>';
		}
		
		return html;
	};
	
	this.getResponseTxtByCid=function(cid)
	{
		for(var i=0;i<this.choices.length;i++)
		{
			if(this.choices[i].cid == cid)
			{
				return unescape(this.choices[i].txt).replace(/<\/?[^>]+(>|$)/g, "");
			}
		}
	};
	
	this.init = function(contentFrame)
	{
	    this.contentDoc = (contentFrame.document || this.assessment.contentDoc);
		
		if (this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
			
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);
			
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, this.stem);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);
		}
		this.contentDoc.getElementById("btnContinue").value = unescape(Lang.UI_ASSESS_SUBMIT);
		
		// Set the correct response - utilized by SCORM interactions and summary pages
		this.setCorrectResponse();
			
		if(this.img == null){
			this.assessment.renderRemaining();
		}
	};
	
	this.focus = function()
	{
		//var contentDoc = (content.contentDocument || $("content").contentWindow.document);
		
		if (this.contentDoc.forms["contentForm"][this.name])
		{			
			var self = this;
			if (this.contentDoc.forms["contentForm"][this.name][0])
			{
			    setTimeout(function () { self.contentDoc.forms["contentForm"][self.name][0].focus(); }, 0);
			}
			else	
			{
			    setTimeout(function () { self.contentDoc.forms["contentForm"][self.name].focus(); }, 0);
			}
		}
	};
}
MultiChoice.prototype = Utils.object.extend(Question.prototype);

