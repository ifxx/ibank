/** 
* Defines the FillIn object for Fill-in interactions
* @requires Question
* @extends Question
* @constructor
*/
function FillIn(o)
{
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "FillIn";
	
	// Used by SCORM interactions
	this.interactionsType = "fill-in";
	
	this.render=function()
	{
		var html=''
	
		html+='<div class="question">\n';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';
	
		html+='<div class="choices">';
	
		for(var i=0;i<this.choices.length; i++)
		{
			if(Utils.string.stripTags(unescape(this.choices[i].txt)) != "")
			{
				html+='<div class="choice" onclick="try{$(\''+this.name+i+'\').focus();}catch(er){return;}">\n';
				html+='	<table class="choiceTable"><tr>';
				html+='		<td><input type="text" name="'+this.name+i+'" id="'+this.name+i+'" value=""></td>\n';
				html+='		<td><label for="'+this.name+i+'">'+unescape(this.choices[i].txt)+'</label></td>\n';
				html+='	</tr></table>';
				html+='</div>\n';
			}
		}
	
		html+='</div>';
		
		html+='<div class="corFb" id="'+this.name+'_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='</div>';
	
		return html;
	};
	
	this.isAnswered=function(contentDoc)
	{
		var contentDoc = this.assessment.contentDoc;
		
		var answered = true;

		this.choices.each(function(item,index){
			var txtField = contentDoc.forms["contentForm"][this.name+index];
			if(Utils.string.trim(txtField.value) === '')
			{
				answered = false;
			}
		},this);
		
		this.answered = answered
		
		return answered;
	};
	
	this.isCorrect=function(contentDoc)
	{
		var correct = true;

		this.choices.each(function(item,index){
			var answerCorrect = false
			this.correctResponse[index].each(function(answer){
				if(this.studentResponse[index].toLowerCase() === unescape(answer.toLowerCase()))
				{
					answerCorrect = true;
				}
			},this);
			if(!answerCorrect)
			{
				correct=false;
			}
		},this);
		
		this.correct = correct;

		return correct;
	};
	
	this.setCorrectResponse=function()
	{
		var correctResponses = [];
		this.choices.each(function(item,index){
			correctResponses.push(item.answer);
		});
		
		this.correctResponse = correctResponses;
		Utils.debug.trace("Interaction - correct response: "+this.correctResponse.join(",").toString());

		if(this.assessment.isPostAssessment)
		{
			var escapedResponse = this.escapeResponses(this.correctResponse);
			if(this.choices.length > 1)
			{
				correctResponses.each(function(item,index){
					engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, item.toString(), index);
				},this);
			}
			else
			{
				correctResponses.each(function(item){
					item.each(function(answer,index){
						engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, answer.toString(), index);
					},this);
				},this);
			}
		}
	};
	
	this.setStudentResponse=function()
	{
		var contentDoc = this.assessment.contentDoc;
		var studentResponses = [];
		this.choices.each(function(item,index){
			var txtField = contentDoc.forms["contentForm"][this.name+index];
			studentResponses.push(txtField.value);
		},this);
		
		this.studentResponse = studentResponses;
		Utils.debug.trace("Interaction - student response: "+this.studentResponse.join(",").toString());
		
		if(this.assessment.isPostAssessment)
		{
			var escapedResponse = this.escapeResponses(this.studentResponse);
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, escapedResponse.join(engine.comm.groupSep));
		}
	};
	
	this.escapeResponses=function(responses)
	{
		var tmp = [];
		for(var i=0;i<responses.length;i++)
		{
			tmp.push(escape(responses[i]));
		}
		return tmp;
	};
	
	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+this.getFixedResponseTxt(this.studentResponse)+'</span>';
		html += '</p>';
		
		if (Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>' + unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER) + ':</b><br>';
			html += '<span class="response">' + this.getFixedResponseTxt(this.correctResponse) + '</span>';
			html += '</p>';
		}
		
		return html;
	};

	this.getFixedResponseTxt=function(responses)
	{
		a = [];
		for(var i=0;i<responses.length;i++)
		{
			var response = responses[i];
			if(typeof response === 'object')
			{
				response = response.join(",");
			}
			a.push(Utils.string.stripTags(unescape(response)));
		}

		var strippedTagsString = a.join("<br>");
		return strippedTagsString;
	};
	
	this.init = function(contentFrame)
	{
	    var contentDoc = (contentFrame.document || this.assessment.contentDoc);
		
		if (this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
			
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);
			
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, this.stem);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);
		}
		contentDoc.getElementById("btnContinue").value = unescape(Lang.UI_ASSESS_SUBMIT);
		
		// Set the correct response - utilized by SCORM interactions and summary pages
		this.setCorrectResponse();

		var focus = function()
		{
			EventHandler.disable();
		};

		var blur = function()
		{
			EventHandler.enable();
		};
		
		for(var i=0;i<this.choices.length; i++)
		{
			if (contentDoc.forms["contentForm"][this.name+i]) {
				contentDoc.forms["contentForm"][this.name+i].onblur = blur;
				contentDoc.forms["contentForm"][this.name+i].onfocus = focus;
			}
		}
		
		if (contentDoc.forms["contentForm"][this.name+'0'])
		{
			var self = this;
			setTimeout(function(){contentDoc.forms["contentForm"][self.name+'0'].focus();},0);
		}
		this.assessment.renderRemaining();
	};
}
FillIn.prototype = Utils.object.extend(Question.prototype);


