﻿/** 
* Defines the HotSpot object for image hotspot interactions
* @requires Question
* @extends Question
* @constructor
*/
function HotSpot(o)
{
	Question.call(this,o);
	
	// Used by assessment
	this.quesType = "HotSpot";
	
	// Used by SCORM interactions
	this.interactionsType = "true-false";

	this.hotspotAreas = [];
	this.studentResponseObj = {};
	this.hotspotObj = {};

	this.addHotSpotArea=function(o)
	{
		var idx = this.hotspotAreas.push(o);
		o.origIndex = idx-1;
	};
	
	this.render=function()
	{
		var html=''
	
		html+='<div class="question">\n';

		html+='<table class="countImages" width="100%"><tr><td width="35%" valign="top">';
	
		html+='<div class="uiQuestionStyle"><p>'+unescape(this.stem)+'</p></div>\n';

		html+='</td><td width="65%" valign="top">';

		html+='<div id="hotspotInteractionContainer">\n';

		var hotspotHtml = '';
		this.hotspotAreas.each(function(item,index){
			hotspotHtml = '<div id="hotspotInteractionArea_'+index+'" class="hotspotInteractionArea"';
			hotspotHtml += ' style="top:'+item.y+'px;left:'+item.x+'px;width:'+item.w+'px;height:'+item.h+'px;">';
			hotspotHtml += '<img src="./images/blank.gif" onload="checkAssessImagesLoaded(this);" onerror="errAssessImagesLoaded();" onreadystatechange="checkAssessImagesLoaded(this);" width="100%" height="100%">';
			hotspotHtml += '</div>';
		},this);
		html+=hotspotHtml;

		html+='	<img src="images/'+this.img+'" class="hsImg" alt="' + unescape(this.caption) + '" title="' + unescape(this.caption) + '" onload="checkAssessImagesLoaded(this);" onerror="errAssessImagesLoaded();" onreadystatechange="checkAssessImagesLoaded(this);" id="'+this.imgId+'" style="'+unescape(this.style)+'">\n';
		html+='</div>\n';

		html+='</td></tr></table>';
	
		html+='<div class="persistFb" id="'+this.name+'_persistFb">'+unescape(Lang.ASSESSMENT_YOUR_RESPONSE_HAS_BEEN_SAVED)+'</div>\n';
		
		html+='<div class="corFb" id="'+this.name+'_corFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="corFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_corFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';
		
		html+='<div class="incFb" id="'+this.name+'_incFb">';
		html+='	<div style="display: table;">';
		html+='		<div style="display: table-row;">';
		html+='			<div class="incFb_icon">&nbsp;</div>'							
		html+='			<div style="display: table-cell;">';
		html+='				<div id="'+this.name+'_incFb_render" aria-live="assertive" aria-atomic="true"></div>\n';
		html+='			</div>';
		html+='		</div>';
		html+='	</div>';
		html+='</div>';	
	
		html+='</div>'; // end question div
	
		return html;
	};

	this.renderCatcher=function()
	{
		var self = this;
		var container = $CONTENT(this.imgId, this.assessment.contentDoc);
		container.addEvent('click',function(e){
			self.markIncorrect(e);
			e.stop();
		});
	};

	this.renderHotspots=function()
	{
		var self = this;
		var x = Utils.dom.findPosX($CONTENT(this.imgId, this.assessment.contentDoc));
		var y = Utils.dom.findPosY($CONTENT(this.imgId, this.assessment.contentDoc));
		this.hotspotAreas.each(function(item,index){
		    $CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc).setStyles({
				left:x+item.x,
				top:y+item.y
			});
		    $CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc).addEvent('click', function (e) {
				self.markCorrect(e);
				e.stop();
			});
		},this);
	};

	this.renderStamp=function(e,o)
	{
		if(this.disabled){return;}

		var self = this;
		var imgX = Utils.dom.findPosX($CONTENT(this.imgId, this.assessment.contentDoc));
		var imgY = Utils.dom.findPosY($CONTENT(this.imgId, this.assessment.contentDoc));
		var func = function(){};
		var origX;
		var origY;
		
		if ($chk($CONTENT('hotspotInteractionStamp', this.assessment.contentDoc)))
		{
		    $CONTENT('hotspotInteractionStamp', this.assessment.contentDoc).destroy();
		}

		if(e)
		{
			func = function(e)
			{
				self.removeStamp(this);
			};
		}

		var onload=function(img)
		{
			if(e) // If the event "e" exists, this is being called as a result of a click event
			{
			    origX = e.client.x + $CONTENT('wrapper', self.assessment.contentDoc).scrollLeft - (img.width / 2);
			    origY = e.client.y + $CONTENT('wrapper', self.assessment.contentDoc).scrollTop - (img.height / 2);

				self.studentResponseObj = {x:origX-imgX, y:origY-imgY};
			}
			else if(o) // Otherwise we're passing in an object with x/y properties for "show me"
			{
				origX = o.x-(img.width/2);
				origY = o.y-(img.height/2);
			}

			el.setStyle('top',origY);
			el.setStyle('left',origX);

			$CONTENT("hotspotInteractionStamp", self.assessment.contentDoc).store('offsetX', origX - imgX);
			$CONTENT("hotspotInteractionStamp", self.assessment.contentDoc).store('offsetY', origY - imgY);
		};

		var el = this.CONTENT_DOC.newElement('div',{
			id:'hotspotInteractionStamp',
			tabindex:-1,
			events:{
				click:func
			}
		});

		var img = this.CONTENT_DOC.newElement('img',{
			events:{
				load:function(){
					onload(this,this);
				}
			}
		});
		
		$CONTENT('hotspotInteractionContainer', this.assessment.contentDoc).adopt(el);

		el.adopt(img);
		img.set("src","./images/"+Conf.HOTSPOT_INTERACTION_STAMP);
	};

	this.disable=function()
	{
		this.disabled = true;
	};

	this.enable=function()
	{
		this.disabled = false;
	};

	this.removeStamp=function(el)
	{
		if(this.disabled){return;}
		this.answered = false;
		this.correct = false;
		el.destroy();
	};

	this.updatePositions=function(e)
	{
	    var x = Utils.dom.findPosX($CONTENT(this.imgId, this.assessment.contentDoc));
	    var y = Utils.dom.findPosY($CONTENT(this.imgId, this.assessment.contentDoc));
		this.hotspotAreas.each(function(item,index){
		    if ($chk($CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc)))
			{
		        $CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc).setStyles({
					top:y+item.y,
					left:x+item.x
				});
			}
		},this);

		if ($chk($CONTENT('hotspotInteractionStamp', this.assessment.contentDoc)))
		{
		    var offsetX = $CONTENT("hotspotInteractionStamp", this.assessment.contentDoc).retrieve('offsetX');
		    var offsetY = $CONTENT("hotspotInteractionStamp", this.assessment.contentDoc).retrieve('offsetY');
		    $CONTENT("hotspotInteractionStamp", this.assessment.contentDoc).setStyles({
				top:y+offsetY,
				left:x+offsetX
			});
		}
	};

	this.showMe=function()
	{
		this.answered = false;
		this.correct = false;

		var x = Utils.dom.findPosX($CONTENT(this.imgId, this.assessment.contentDoc));
		var y = Utils.dom.findPosY($CONTENT(this.imgId, this.assessment.contentDoc));
		this.hotspotAreas.each(function(item,index){
			var o = {};
			o.x = x+item.x+(item.w/2);
			o.y = y+item.y+(item.h/2);
			$CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc).setStyles({
				border:'1px solid '+unescape(item.color),
				opacity:0.8
			})
			$CONTENT('hotspotInteractionArea_' + index, this.assessment.contentDoc).getElements('img')[0].setStyles({
				background:unescape(item.color),
				opacity:0.4
			})
			this.renderStamp(null,o);
		},this);
		this.disable();
	};

	this.isAnswered=function()
	{
		return this.answered;
	};
	
	this.isCorrect=function()
	{
		return this.correct;
	};

	this.markIncorrect=function(e)
	{
		if(this.disabled){return;}
		this.correct = false;
		this.answer(e);
	};

	this.markCorrect=function(e)
	{
		if(this.disabled){return;}
		this.correct = true;
		this.answer(e);
	};

	this.answer=function(e)
	{
		this.assessment.enableReset();
		this.assessment.enableContinue();
		this.answered = true;
		this.renderStamp(e);
	};
	
	this.setCorrectResponse=function()
	{
	    var x = Utils.dom.findPosX($CONTENT(this.imgId, this.assessment.contentDoc));
	    var y = Utils.dom.findPosY($CONTENT(this.imgId, this.assessment.contentDoc));
		//currently assumes only one hotspot
		this.hotspotAreas.each(function(item,index){
			this.hotspotObj = {x:item.x, y:item.y};
		},this);

		this.correctResponse = true;
		Utils.debug.trace("Interaction - correct response: "+JSON.encode(this.correctResponse));
		
		if (this.assessment.isPostAssessment)
		{
			engine.comm.setInteractionCorrectResponse(this.assessment.currentQues, engine.comm.interactionTrueString);
		}
	};
	
	this.setStudentResponse=function()
	{
		this.studentResponse = this.correct;
		Utils.debug.trace("Interaction - correct response: "+JSON.encode(this.studentResponse));
		
		if (this.assessment.isPostAssessment)
		{
			var r = (this.studentResponse) ? engine.comm.interactionTrueString : engine.comm.interactionFalseString;
			engine.comm.setInteractionStudentResponse(this.assessment.currentQues, r);
		}
	};
	
	this.getSummary=function()
	{
		var stampX = this.studentResponseObj.x;
		var stampY = this.studentResponseObj.y;
		var hsX = this.hotspotObj.x;
		var hsY = this.hotspotObj.y;
		var html = '';
		var stampHtml = '<div class="hotspotInteractionStamp"><img src="./images/'+Conf.HOTSPOT_INTERACTION_STAMP+'"></div>\n';
		var imgHthml = '<img src="images/'+this.img+'" class="hsImg" alt="' + unescape(this.caption) + '" title="' + unescape(this.caption) + '" id="'+this.imgId+'" style="'+unescape(this.style)+'">\n'
		var hotspotHtml = '';
		this.hotspotAreas.each(function(item,index){
			hotspotHtml = '<div id="hotspotInteractionArea_'+index+'" class="hotspotInteractionArea"';
			hotspotHtml += ' style="width:'+item.w+'px;height:'+item.h+'px;border:1px solid '+unescape(item.color)+';opacity:0.8;filter:alpha(opacity=80);">';
			hotspotHtml += '<img src="./images/blank.gif" width="100%" height="100%" style="background:'+unescape(item.color)+';opacity:0.4;filter:alpha(opacity=40);">';
			hotspotHtml += '</div>';
		},this);
		
		// Student Response
		var container = this.imgId+'_incorrect';

		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+this.getResponseTxt(this.studentResponse);
		html += '	<b><span id="'+container+'_show" style="display:inline;"><a href="#" onclick="showIncorrectAnswer(\''+container+'\');updateHotspotOverlay(\''+container+'\','+hsX+','+hsY+','+stampX+','+stampY+',false);return false;">'+Lang.ASSESSMENT_HOTSPOT_SHOW_INCORRECT_AREA+'</a></span><span id="'+container+'_hide" style="display:none;"><a href="#" onclick="hideIncorrectAnswer(\''+container+'\');updateHotspotOverlay(\''+container+'\','+hsX+','+hsY+','+stampX+','+stampY+',false);return false;">'+Lang.ASSESSMENT_HOTSPOT_HIDE_INCORRECT_AREA+'</a></span></b>';
		html += '</span>\n';
		html += '<div id="'+container+'" class="hotspotAnswer">\n';
		html += stampHtml;
		html += hotspotHtml;
		html += imgHthml;
		html += '</div>\n';
		html += '</p>';
		
		// Correct Response
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			var container = this.imgId+'_correct';

			html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+this.getResponseTxt(this.correctResponse);
			html += '	<b><span id="'+container+'_show" style="display:inline;"><a href="#" onclick="showCorrectAnswer(\''+container+'\');updateHotspotOverlay(\''+container+'\','+hsX+','+hsY+','+stampX+','+stampY+',true);return false;">'+Lang.ASSESSMENT_HOTSPOT_SHOW_CORRECT_AREA+'</a></span><span id="'+container+'_hide" style="display:none;"><a href="#" onclick="hideCorrectAnswer(\''+container+'\');updateHotspotOverlay(\''+container+'\','+hsX+','+hsY+','+stampX+','+stampY+',true);return false;">'+Lang.ASSESSMENT_HOTSPOT_HIDE_CORRECT_AREA+'</a></span></b>';
			html += '</span>\n';
			html += '<div id="'+container+'" class="hotspotAnswer">\n';
			html += stampHtml;
			html += hotspotHtml;
			html += imgHthml;
			html += '</div>\n';
			html += '</p>';
		}
		
		return html;
	};
	
	this.getResponseTxt=function(result)
	{
		if(result)
		{
			return unescape(Lang.ASSESSMENT_HOTSPOT_CORRECT);
		}
		else
		{
			return unescape(Lang.ASSESSMENT_HOTSPOT_INCORRECT);
		}
	};
	
	this.init = function(contentFrame)
	{
		this.answered = false;
		this.correct = false;
		this.disabled = false;

		var self = this;

		this.CONTENT_FRAME = this.assessment.contentFrame;
		this.CONTENT_DOC = this.assessment.contentDoc;
		
		if (this.assessment.isPostAssessment)
		{
			// Set the ID of the interaction based on name value, so this won't be reassigned.
			engine.comm.setInteractionId(this.assessment.currentQues, this.name);
			
			// Set the interaction type
			engine.comm.setInteractionType(this.assessment.currentQues, this.interactionsType);
			
			// Set the interaction's description
			engine.comm.setInteractionDescription(this.assessment.currentQues, this.stem);

			// Set the timestamp of when this interaction kicked off
			engine.comm.setInteractionTimeStamp(this.assessment.currentQues);
			this.CONTENT_DOC.getElementById("btnContinue").value = unescape(Lang.UI_ASSESS_SUBMIT);
		}

		var c = $CONTENT('hotspotInteractionContainer', this.assessment.contentDoc);
		Utils.dom.unselectable(c);
		
		setTimeout(function(){
			self.renderCatcher();
			self.renderHotspots();
		},0);

		// Set the correct response - utilized by SCORM interactions and summary pages
		this.setCorrectResponse();
	};

	this.toString=function()
	{
		return this.quesType;
	};
}
HotSpot.prototype = Utils.object.extend(Question.prototype);

