/** 
* Defines the DragDropManyToOne object for Many-to-One Drag-n-Drop interactions
* @requires Question
* @extends Question
* @constructor
*/
function DragDropManyToOne(o)
{
	DragDropStandard.call(this,o);
	
	// Used by assessment
	this.quesType = "DragDrop";
	
	// Used by SCORM interactions
	this.interactionsType = "matching";

	this.isCorrect=function()
	{
		this.correct = true;
		if(this.studentResponse.length != this.correctResponse.length)
		{
			this.correct =  false;
		}
		else 
		{
			for(var i = 0;i<this.studentResponse.length;i++)
			{
				if((this.studentResponse[i].correct && !this.studentResponse[i].dropped) || (!this.studentResponse[i].correct && this.studentResponse[i].dropped))
				{
					this.correct = false;
				}
			}
		}
		return this.correct;
	};

	this.getStudentResponse=function()
	{
		//Create a student response containing all drag/drop pairs as objects in an array
		var response = [];
		this.draggables.each(function(d,i){
			//Create the drag/drop pair
			var o  = {};
			o.correct = d.correct;
			o.dragText = d.label;
			o.dragIdx = (i+1);
			o.targetAlpha = this.alphas[0];
			o.dropped = (this.draggableElements[i].drop != null) ? true : false;
			
			Utils.debug.trace("Setting student response: "+o.dragText+" ("+o.dragIdx+"), "+o.targetAlpha+", "+o.correct+", "+o.dropped);

			//Add the drag/drop pair to the response array
			if(o.dropped)
			{
				response.push(o);
			}
		},this);
		return response;
	};

	this.getCorrectResponse=function()
	{
		//Create a correct response containing all drag/drop pairs as objects in an array
		var response = [];
		this.draggables.each(function(d,i){
			//Create the drag/drop pair

			var o  = {};
			o.correct = d.correct;
			o.dragText = d.label;
			o.dragIdx = (i+1);
			o.targetAlpha = this.alphas[0];
			
			Utils.debug.trace("Setting correct response: "+o.dragText+" ("+o.dragIdx+"), "+o.targetAlpha+", "+o.correct);

			//Add the drag/drop pair to the response array
			if(o.correct)
			{
				response.push(o);
			}
		},this);
		return response;
	};

	this.getCorrectResponseTxt=function(responseObj)
	{
		var html = '';
		for(var i=0;i<responseObj.length;i++)
		{
			if(responseObj[i].correct)
			{
				// {"targetIdx":1,"dragAlpha":"a","dragText":"Steering Wheel","correct":true}
				html += '<p>'+unescape(responseObj[i].dragText)+'</p>';
			}
		}
		
		return html;
	};

	this.getSummary=function()
	{
		var html = '';
		
		// Student Response
		html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER)+':</b><br>';
		html += '<span class="response">'+this.getStudentResponseTxt(this.studentResponse)+'</span>';
		html += '</p>';
		
		if(Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY)
		{
			// Correct Response
			html += '<p><b>'+unescape(Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER)+':</b><br>';
			html += '<span class="response">'+this.getCorrectResponseTxt(this.correctResponse)+'</span>';
			html += '</p>';
		}
		
		return html;
	};

	this.getStudentResponseTxt=function(responseObj)
	{
		var html = '';
		for(var i=0;i<responseObj.length;i++)
		{
			if (responseObj[i].dropped)
			{
				// {"targetIdx":1,"dragAlpha":"a","dragText":"Steering Wheel","correct":true}
				html += '<p>' + unescape(responseObj[i].dragText) + '</p>';
			}
		}
		
		return html;
	};

	this.assessInteraction=function()
	{
		this.assessment.enableReset();
		this.assessment.enableContinue();
		if(this.countDrops() >= 1)
		{
			var correctResponse = this.getCorrectResponse();
			var studentResponse = this.getStudentResponse();
			this.setCorrectResponse(correctResponse);
			this.setStudentResponse(studentResponse);

			this.answered = true;
		}
		else
		{
			this.answered = false;
		}
	};

	this.showMe=function()
	{
	    var target = $CONTENT('tContent', this.assessment.contentDoc);
		target.innerHTML = '';
		this.draggableElements.each(function(d){
			
			var dContent = d.parentNode;

			if(d.correct)
			{
				target.innerHTML += '<p>'+d.innerHTML+'</p>';
				target.set('title',target.get('title')+'. '+d.innerHTML);
			}

			d.correct = false;
			dContent.enabled = false;

			dContent.removeEvents('click');
			dContent.tabIndex = -1;
			dContent.set('aria-grabbed',false);

			d.removeEvents('mousedown');
			d.removeClass('dragActive');
			d.setStyles({opacity:0.7});

		},this);

		this.selectedElement = null;
		this.answered=false;
	};

	this.assessMatch = function(el)
	{
		if(!this.selectedElement || !this.focusedElement){return;}

		el = (el) ? el : this.focusedElement;

		var draggable = this.selectedElement.getElements('div')[0];
		var target = el;

		if(el.targetId == this.selectedElement.target)
		{
			Utils.debug.trace('correct!');
			draggable.correct = true;
		}
		else
		{
			Utils.debug.trace('incorrect!');
			draggable.correct = false;
		}

		target.innerHTML += '<p>'+draggable.innerHTML+'</p>';

		var targetTitle = target.get('title');
		target.set('title',targetTitle+'. '+draggable.innerHTML);

		this.selectedElement.removeEvents('click');
		this.selectedElement.tabIndex = -1;

		draggable.removeEvents('mousedown');
		draggable.removeClass('dragActive');
		draggable.setStyles({opacity:0.7});
		draggable.drop = el;

		this.selectedElement = null;

		$CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragContent').each(function (el) {
			el.removeClass('dragSelected');
			el.set('aria-grabbed',false);
		});

		this.assessInteraction();
	};

	this.makeDraggables=function(container)
	{
		var self = this;

		// create draggables
		this.draggables.each(function(item,index){
			
			// Create draggableContent container
			var dContent = this.CONTENT_DOC.newElement('div',{
				id: 'dContent'+index,
				title: Lang.ACCESSIBILITY_DRAGGABLE+'-'+Lang.ACCESSIBILITY_DESELECTED+': '+unescape(item.label),
				tabIndex: 0,
				events:{
					'click': function(e) {
						self.dragClicked(e,this);
					},
					'focus': function(e) {
						self.dragFocused(e,this);
					},
					'keydown': function(e){
						if(e.code == 32 || e.code == 13)
						{
							self.selectDrag(this);
							e.stop();
						}
					}
				}
			}).inject(container);
			dContent.enabled = true;
			dContent.label = item.label;
			dContent.isDraggable = true;
			dContent.isTarget = false;
			dContent.target = 'tContent';
			dContent.addClass('clearfix');
			dContent.addClass('dragContent');
			dContent.set('aria-grabbed',false);

			// Create draggable element
			var draggable = this.CONTENT_DOC.newElement('div',{
			    id: 'draggable'+index,
				text: unescape(item.label)
			}).inject(dContent);
			draggable.drop = null;
			draggable.label = Utils.string.replaceChars(item.label);
			draggable.title = unescape(item.label);
			draggable.correct = item.correct;
			draggable.addClass('uiTextColor');
			draggable.addClass('uiSecondaryBackgroundColor');
			draggable.addClass('dragActive');
			draggable.addClass('draggableMany');
			draggable.target = item.target;

			if(Utils.browserDetection.isMobile())
			{
				var clone = draggable.clone();
				var z = draggable.getStyle('z-index');
				var origin = draggable.getPosition();
				var dimensions = draggable.getComputedSize();
				
				clone.setStyles({
					opacity:0.01,
					position:'absolute',
					left:origin.x,
					top:origin.y,
					width:dimensions.width,
					height:dimensions.height,
					zIndex:z+1
				}).inject(container);
				clone.addClass('dragClone');
				clone.target = item.target;
				clone.label = item.label;
				clone.dContent = dContent;
				clone.dragEl = draggable;
				clone.origin = origin;
			}
			
			this.draggableElements.push(draggable);

		},this);
	};
	
	this.makeTargets=function(container)
	{
		var self = this;

		// Create targetContent container
		var tContent = this.CONTENT_DOC.newElement('div',{
			id: 'tContent',
			title: Lang.ACCESSIBILITY_TARGET,
			tabindex: 0,
			events:{
				'click': function(e) {
					self.targetClicked(e,this);
				},
				'focus': function(e) {
					self.targetFocused(e,this);
				},
				'keydown': function(e){
					if((e.control && e.code == 77) || e.code == 13 || e.code == 32)
					{
						self.assessMatch(this);
						e.stop();
					}
				}
			}
		}).inject(container);
		tContent.isDraggable = false;
		tContent.isTarget = true;
		tContent.enabled = true;
		tContent.targetId = 'tContent';
		tContent.addClass('targetContent');
		tContent.addClass('target');
		tContent.addClass('singleTarget');
		tContent.set('aria-dropeffect','move');

		var dragContainerH = $CONTENT('draggablesContainer', this.assessment.contentDoc).getSize().y;
		tContent.setStyle('height',dragContainerH);
		//tContent.setStyle('width',this.elementWidth-20);

		this.targetElements.push(tContent);
	};

	this.createDragEvents=function()
	{
		var self = this;
		var allowance = 10;
		var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.draggableMany');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		draggables.addEvent('mousedown',function(ev){
			var clone = this.clone();
			var origin = this.getPosition();
			var size = this.getSize();
			var draggable = this;
			clone.target = this.target;

			var scrTop = $CONTENT('wrapper', self.assessment.contentDoc).getScrollTop();

			clone.setStyles({opacity:0,position:'absolute',left:origin.x,top:origin.y+scrTop,width:size.x,height:size.y}).inject(container);

			clone.makeDraggable({
				droppables:self.targetElements,
				snap:15,
				onSnap:function(el){
					el.setStyle('opacity',0.7);
				},
				onEnter:function(el,drop){
					drop.addClass('dragover');
					el.addClass('dragover');
				},
				onLeave:function(el,drop){
					drop.removeClass('dragover');
					el.removeClass('dragover');
				},
				onDrop:function(el,drop){
					if(drop)
					{
						if(drop.targetId == el.target)
						{
							Utils.debug.trace('correct!');
						}
						else
						{
							Utils.debug.trace('incorrect!');
						}
						drop.innerHTML += '<p>'+unescape(draggable.label)+'</p>';
						var dropTitle = drop.get('title');
						drop.set('title',dropTitle+'. '+draggable.title);
						drop.removeClass('dragover');
						clone.destroy();

						draggable.removeEvents('mousedown');
						draggable.removeClass('dragActive');
						draggable.setStyles({opacity:0.7});
						drop.parentNode.tabIndex = -1;
						draggable.parentNode.tabIndex = -1;
						draggable.parentNode.enabled = false;
						drop.parentNode.enabled = false;
						draggable.drop = drop;

						self.selectedElement = null;

						$CONTENT('draggablesContainer', self.assessment.contentDoc).getElements('div.dragContent').each(function (el) {
							el.removeClass('dragSelected');
							el.set('aria-grabbed',false);
						});

						self.assessInteraction();
					}
					else
					{
						draggable.correct = false;
						draggable.drop = null;
						el.get('morph').start({
							opacity:0,
							left:origin.x,
							top:origin.y+scrTop
						}).chain(el.destroy.bind(el));

						self.assessInteraction();
					}
				}
			}).start(ev);
		});
	};

	this.createTouchDragEvents=function()
	{
		var self = this;
		var dragClones = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragClone');
		var container = $CONTENT('dndContainer', this.assessment.contentDoc);
		
		dragClones.addEvents({
			'touchend':function(e)
			{
				if(!this.moving)
				{
					return;
				}
				this.moving = false;

				var droppedTarget = $CONTENT('tContent', self.assessment.contentDoc);
				
				if (Utils.dom.hitTest(this, $CONTENT('tContent', self.assessment.contentDoc)))
				{
					droppedTarget.innerHTML += '<p>'+this.label+'</p>';
					this.dragEl.drop = droppedTarget;
					this.dragEl.setStyle('opacity',0.7);
					this.dContent.removeEvents();
					this.setStyle('display','none');
				}
				else
				{
					this.get('morph').start({
						opacity:0.01,
						left:this.origin.x,
						top:this.origin.y
					});

					this.dragEl.drop = null;
					this.dragEl.correct = false;
					self.assessInteraction();
				}
				
				self.assessInteraction();
				
				e.preventDefault();
				e.stopPropagation();
			},
			'touchmove':function(e)
			{
				e.preventDefault();
				e.stopPropagation();

				this.moving = true;

				var t = e.targetTouches[0];
				if(t == null){return}

				this.setStyle('opacity',0.75);

				this.setStyle('left', ((t.pageX-(this.getStyle('width').toInt()/2)))-container.getPosition().x);
				this.setStyle('top', ((t.pageY-(this.getStyle('height').toInt()/2)))-self.CONTENT_FRAME.contentScroller.y);
			}
		})
	};

	this.disableDraggables=function()
	{
		if(Utils.browserDetection.isMobile())
		{
		    var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragClone');
		}
		else
		{
		    var draggables = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.draggableMany');
		    var dragContent = $CONTENT('draggablesContainer', this.assessment.contentDoc).getElements('div.dragContent');
			dragContent.removeEvents();
		}
		$CONTENT('tContent', this.assessment.contentDoc).removeEvents();
		draggables.removeEvents();		
	};

	this.toString=function()
	{
		return 'DragDropManyToOne Instance';
	};
}
DragDropManyToOne.prototype = Utils.object.extend(DragDropStandard.prototype);
