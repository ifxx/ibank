/**
* Class defining the resource
* @param {Object} o A param that specifies the resource class configuration
* @requires Engine
* @constructor

*/
function Resource(o)
{
	for (var prop in o)
	{
		this[prop] = o[prop];
	}
	
	this.open = false;
	this.visited = false;
	this.url = unescape(this.url);
	this.title = Utils.string.replaceChars(this.title);
	
	this.index = engine.controller.resources.length;
	engine.controller.resources.push(this);
	
	/**
	 * Get path to the resource to load
	 * @method getResourceURL
	 * @return {String} Returns a string containing the path to the resource to load
	 */
	this.getResourceURL = function()
	{
		var resourceURL;
		
		resourceURL = engine.rootPath + '/content/resources/' + this.file;
		
		return resourceURL;
	};
	
	/**
	 * Get the HTML for the resource
	 * @method getResourceHTML
	 * @return {String} Returns a string containing the HTML for the resource
	 */
	this.getResourceHTML = function()
	{
		var resourceHTML;
				
		resourceHTML = '<li id="' + this.name + '_li" class="menuEntry" tabindex="0" onFocus="engine.ui.setMenuFocused(true,this);" onBlur="engine.ui.setMenuFocused(false,null);"';
		if ($chk(this.url)){
			resourceHTML += ' resourcename="'+this.name+'" title="' + this.title + '">';
		}
		if ($chk(this.file)){
			resourceHTML += ' resourcename="'+this.name+'" title="' + this.title + '">';
		}
		resourceHTML += '<a href="#" tabindex="-1" onClick="'+this.name+'.openWindow(true);return false;">';
		resourceHTML += '<span class="resourceHere">' + this.title + '</span></a>';
		resourceHTML += '</li>';
		if ($chk(this.description))
		{
			resourceHTML += this.renderDescription();
		}
				
		return resourceHTML;
	};

	this.renderDescription = function()
	{
		var descriptionHTML = "";
		this.description = Utils.string.replaceChars(this.description);
				
		descriptionHTML += '<ul class="descriptionContent" role="group">';
		descriptionHTML += '<li id="' + this.name + '_description_li" class="resourceEntry" tabindex="0" onFocus="engine.ui.setMenuFocused(true,this);" onBlur="engine.ui.setMenuFocused(false,null);"';
		descriptionHTML += ' <span class="description">' + this.description + '</span>';
		descriptionHTML += '</li>';
		descriptionHTML += '</ul>';
		
		return descriptionHTML;
	};
	
	/**
	 * Open the resource in a browser window
	 * @method openWindow
	 * @param {Boolean} refresh	Whether or not the resource panel re-renders itself
	 */
	this.openWindow = function(refresh, newwindow)
	{
		if ($chk(this.url)){
			if (newwindow == "true" || newwindow == true){
				Utils.window.open(this.url, this.name + '_win',800,600,'resizable,scrollbars,location,menubar');
			} else {
				Utils.window.open(this.url,'auxWin',800,600,'resizable,scrollbars,location,menubar');
			}
		}
		if ($chk(this.file)){
			if (newwindow == "true" || newwindow == true){
				Utils.window.open(this.getResourceURL(), this.name + '_win',800,600,'resizable,scrollbars,location,menubar');
			} else {
				Utils.window.open(this.getResourceURL(),'auxWin',800,600,'resizable,scrollbars,location,menubar');
			}
		}
		if (refresh) 
		{
			engine.ui.renderResource();
		}
	};
}
