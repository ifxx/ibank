/** 
* Global singleton JavaScript event handler library (engine-level)
* @type {Object}
*/
if(!window.EventHandler)
{
	window.EventHandler = {

		enabled: false,

		createMouseListener: function(el)
		{
			var self = this;
			el.addEvent('mousedown', self.click);
		},

		createKeyListeners: function()
		{
			if(document.addEventListener)
			{
				document.addEventListener('keydown', EventHandler.keyDown, true);
				if(document.onkeypress){document.addEventListener('keypress', EventHandler.doNothing, true);}
				Utils.debug.trace('Key listeners registered');
			}
			else if(document.attachEvent)
			{
				document.attachEvent('onkeydown',EventHandler.keyDown);
				if(document.onkeypress){document.attachEvent('onkeypress',EventHandler.doNothing);}
				Utils.debug.trace('Key events attached');
			}
			else
			{
				document.onkeydown = EventHandler.keyDown;
				if(document.onkeypress){document.onkeypress = EventHandler.doNothing};
				Utils.debug.trace('Key events assigned');
			}

			this.enabled = true;
		},

		doNothing: function(e)
		{
			if(!e) var e = window.event;
			return EventHandler.killEvent(e);
		},

		killEvent: function(e)
		{
			if(!e) var e = window.event;

			e.cancelBubble = true;
			e.returnValue = false;

			if(e.preventDefault) e.preventDefault();
			if(e.stopPropagation) e.stopPropagation();
			if(e.preventCapture) e.preventCapture();
			if(e.preventBubble) e.preventBubble();

			return false;
		},

		click: function(e)
		{
			if(!EventHandler.enabled){return;}

			engine.ui.contentFocused = false;
		},

		keyDown: function(e)
		{
			if(!EventHandler.enabled)
			{
				return;
			}

			if(!e) var e = window.event;
			
			return engine.ui.handleKeyDownEvent(e);
		},

		disable: function()
		{
			EventHandler.enabled = false;
		},

		enable: function()
		{
			EventHandler.enabled = true;
		},

		toString: function()
		{
			return "Event Handler Instance";
		}
	}
}