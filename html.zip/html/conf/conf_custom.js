
//Settings for SCORM/AICC wrappers & CommFactory
Conf.API_WRAPPER_DEBUG = false;
Conf.COOKIE_LIFETIME_IN_HOURS = 730; // 730 ~= 30 days
Conf.SCORM_COMPLETION_THRESHOLD = 1.0;

//UI settings
Conf.UI_MARGIN = 10;
Conf.POPUP_WIDTH = 350;

//Audio object type: "HTML5", "FLASH", "CUSTOM" or null (without quotes!)
Conf.AUDIO_TYPE = "HTML5";
Conf.STREAM_AUDIO = true;

//Should menu be inaccessible for pages not yet visited
Conf.LOCKSTEP_MENU_NAVIGATION = false;

//Assessment settings
Conf.SHOW_QUESTIONS_IN_SUMMARY = true;
Conf.SHOW_CORRECT_QUESTIONS_IN_SUMMARY = false;
Conf.OVERWRITE_PREV_HIGHER_SCORE = false;
Conf.OVERWRITE_PREV_COMPLETION_STATUS = false;
Conf.OVERWRITE_PREV_SUCCESS_STATUS = false;

//History Settings
Conf.MAX_HISTORY_LENGTH = 25;

//Close window or call LMSFinish
Conf.CLOSE_ON_TERMINATE = true;

//Flash plugin required versions (used in Utils.flash)
Conf.FLASH_MAJOR_VERSION = 8;
Conf.FLASH_MINOR_VERSION = 0;
Conf.FLASH_REVISION = 0;

// Misc...
Conf.ENABLE_CHECK_FOR_ENGINE = false;

//Reviewer/Comments (commenting feature)
Conf.ENABLE_COMMENTS = false;
Conf.REVIEWER_CLIENT_ID = "";
Conf.REVIEWER_PROJECT_ID = "";