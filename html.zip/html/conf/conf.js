if(!window.Conf){window.Conf = {};}
//uPerform Version: 5.30.0.77
Conf.UPERFORM_VERSION = '5.30.0.77';
//Simple String value used for LocalAPI and Window Names
Conf.CONTENT_ID = 'da5297890e';
Conf.RTLSupport = false;
//SCORM12, SCORM2004, AICC, COOKIE, or CUSTOM API version
Conf.API_TYPE = "COOKIE";
//Scorm 1.2 or AICC Status
Conf.COMPLETION_STRING = "completed_incomplete";
//Use remote AICC proxy for cross-domain use
Conf.REMOTE_PROXY = false;
//UI settings
Conf.PREVIEW_MODE = false;
Conf.CONTENT_WIDTH = 900;
// UI button options
Conf.ENABLE_HELP_BUTTON = false;
Conf.HELP_URL = "";
Conf.ENABLE_RESOURCES_BUTTON = true;
Conf.RESOURCES_PANEL_ENABLED = true;
Conf.RESOURCES_URL = "";
Conf.ENABLE_GLOSSARY_BUTTON = false;
Conf.GLOSSARY_URL = "";
Conf.ENABLE_EXIT_BUTTON = true;
Conf.ENABLE_MENU_BUTTON = true;
Conf.ENABLE_HISTORY_BUTTON = true;
Conf.ENABLE_NEXT_BUTTON = true;
Conf.ENABLE_BACK_BUTTON = true;
Conf.ENABLE_SIM_EXIT_BUTTON = true;
Conf.ENABLE_SKIP_SIM_BUTTON = true;
Conf.ENABLE_DEBUGGER = false;
//used to display menu onload
Conf.MENU_DISPLAY_ONLOAD = "hidden";
//Assessment settings
Conf.SHOW_CORRECT_ANSWERS_IN_SUMMARY = true;
Conf.ASSESSMENT_URI = "http://localhost/result.asp";
Conf.PASSING_SCORE = 70;
Conf.INCLUDE_DOCUMENT_NAME = true;
Conf.INCLUDE_NUMBER_OF_INCORRECT_STEPS = true;
Conf.INCLUDE_NUMBER_OF_TOTAL_STEPS = true;
Conf.INCLUDE_WHICH_STEPS_INCORRECT = true;
Conf.INCLUDE_GRADE = true;
Conf.DISPLAY_USERNAME_PROMPT = false;
Conf.HOTSPOT_INTERACTION_STAMP = "hotspot_stamp.png";
//Used to enable/disable moving and resizing the course window
Conf.WINDOW_CONTROL = true;
Conf.REUSE_EXISTING_WINDOW = false;
//Should course window location be 0,0
Conf.ZEROWIN = false;
//Limit to one popup visible at a time
Conf.SINGLE_POPUP = true;
//Used to enable/disable fullscreen mode. If false, you must set the proper
//courseWidth and courseHeight vars. If enabled, width and height are ignored.
Conf.FULLSCREEN = false;
//Width of content window
Conf.WINDOW_W = 1100;
//Height of content window
Conf.WINDOW_H = 800;
//CURRENT_LOCATION or PERCENTAGE_VISITED
Conf.PROGRESS_BAR_MODE = 'CURRENT_LOCATION';
//Should audio controls hide if page does not contain audio
Conf.AUTO_HIDE_AUDIO_CONTROLS = true;
//Should the zoom button show by default
Conf.OVERRIDE_ZOOMVISIBILITY = false;
//Should the zoom button show by default
Conf.DEFAULT_ZOOMVISIBILITY = false;
//Mobile Settings
Conf.MOBILE_DEVICES = ["iOS/Safari"];
