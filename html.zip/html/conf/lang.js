﻿/**
lang.js (dynamic)
Published by ANCILE uPerform
- Static language constants populated by the publish routine
*/

if(!window.Lang){window.Lang = {};}
	
Lang.RETURN_TO_LAST_LOCATION = "Would you like to continue where you left off?";
Lang.CANNOT_OPEN_DEBUG_WIN = "Error: Cannot open debug window - Please disable all popup blockers to use this feature.%5CnThe debug content will be displayed in an alert box instead after you click 'OK'.";
Lang.AICC_CHECK_BEFORE_UNLOAD = "WARNING: You must use one of the exit buttons within the lesson in order to receive credit.  Are you sure you wish to exit?";
Lang.EXIT_CONFIRMATION = "Are you sure you wish to exit this course?";
Lang.ENTER_USER_NAME = "Please enter a user name for the test results";
Lang.SIM_EXITBTN_LABEL = "Return to Course";
Lang.NO_EMBED_MSG = "Your browser does not support the embedding of multimedia.";
Lang.SKIP_SIMULATION_WARNING_MSG = "Skipping this simulation will score this question as incorrect. Are you sure?";

Lang.UI_LABEL_CONTINUE = "Continue";
Lang.UI_LABEL_RESET = "Reset";
Lang.UI_LABEL_RETRY = "Retry";
Lang.UI_LABEL_SHOW_ME = "Show Me";	
Lang.UI_LABEL_SKIP_SIM = "Skip Simulation";
Lang.UI_LABEL_TRANSCRIPT = "Transcript";
Lang.UI_LABEL_AUDIO_ENABLED = "Audio Enabled";
Lang.UI_LABEL_AUDIO_DISABLED = "Audio Disabled";
Lang.UI_LABEL_PAGE_NUMBER = "Page %s of %t";
Lang.UI_LABEL_QUESTION_NUMBER = "Question %s of %t";

Lang.UI_CLOSE = "Close";
Lang.UI_SUBMIT = "Submit";
Lang.UI_ASSESS_SUBMIT = "Continue";
Lang.YES = "Yes";
Lang.NO = "No";

Lang.ASSESSMENT_QUESTION = "Question";
Lang.ASSESSMENT_ANSWER_QUES_PROMPT = "You must answer the question in order to proceed.";
Lang.ASSESSMENT_PASS_TEXT = "Results";
Lang.ASSESSMENT_FAIL_TEXT = "Assessment Results";
Lang.ASSESSMENT_ALREADY_PASSED = "You have already passed this course.";
Lang.ASSESSMENT_QUESTION_RESULTS = "Question Results";
Lang.ASSESSMENT_INC_QUESTION_RESULTS = "Incorrect Question Results";
Lang.ASSESSMENT_ANSWERED_ALL_CORRECTLY = "You answered all questions correctly";
Lang.ASSESSMENT_RESULTS_NOT_AVAILABLE = "Assessment results are not available";
Lang.ASSESSMENT_SUMMARY_NO_RETAKE = "You have already taken the assessment. You are allowed only one attempt to pass the assessment.";
Lang.ASSESSMENT_SIM_TOTAL_STEPS = "Total Step(s)";
Lang.ASSESSMENT_SIM_INCORRECT_STEPS = "Incorrect Step Number(s)";
Lang.ASSESSMENT_SIM_GEN_INCORRECT_STEPS = "Incorrect Simulation Steps";
Lang.ASSESSMENT_SIM_ACCURACY = "Accuracy";
Lang.ASSESSMENT_SIM_NUM_INC_STEPS = "Total Incorrect";
Lang.ASSESSMENT_SIM_SKIPPED_RESULT = "Skipped simulation";
Lang.ASSESSMENT_SUMMARY_YOUR_ANSWER = "Your Answer";
Lang.ASSESSMENT_SUMMARY_YOUR_CHOICE_WAS = "Your choice was";
Lang.ASSESSMENT_SUMMARY_CORRECT_ANSWER = "Correct Answer";
Lang.ASSESSMENT_SUMMARY_YOUR_SCORE = "Your Score";
Lang.ASSESSMENT_SUMMARY_PASSING_SCORE = "Passing Score";
Lang.ASSESSMENT_ERROR_POSTING_RESULTS = "An error occurred while attempting to post results";
Lang.ASSESSMENT_YOUR_RESPONSE_HAS_BEEN_SAVED = "Your response has been saved.";
Lang.ASSESSMENT_HOTSPOT_CORRECT = "Correct area within the image was selected.";
Lang.ASSESSMENT_HOTSPOT_INCORRECT = "Incorrect area within the image was selected.";
Lang.ASSESSMENT_HOTSPOT_SHOW_CORRECT_AREA = "Show correct answer";
Lang.ASSESSMENT_HOTSPOT_SHOW_INCORRECT_AREA = "Show my answer";
Lang.ASSESSMENT_HOTSPOT_HIDE_CORRECT_AREA = "Hide correct answer";
Lang.ASSESSMENT_HOTSPOT_HIDE_INCORRECT_AREA = "Hide my answer";
Lang.FLASH_WARNING_TITLE = "Warning!";
Lang.FLASH_WARNING_IT_APPEARS = "It appears you do not have the proper version of the Flash Plugin installed to view this courseware.";
Lang.FLASH_WARNING_CLICK_HERE_TO_INSTALL = "Click here to install the plugin";
Lang.FLASH_WARNING_CONTACT_YOUR_ADMIN = "For help on installing the Flash plugin, contact your system administrator.";
Lang.FLASH_WARNING_CURRENT_VERSION = "Current Installed Version";
Lang.FLASH_WARNING_REQUIRED_VERSION = "Required Version";
Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED = "This platform does not support the Flash Player. Some audio may be unavailable.";
Lang.FLASH_WARNING_IT_APPEARS_UNSUPPORTED_AICC = "This platform does not support the Flash Player. Your progress will not be saved for this session.";
Lang.FLASH_WARNING_DO_NOT_SHOW_MESSAGE_AGAIN = "Do not show this message again.";
Lang.FLASH_WARNING_VERSION_UNSUPPORTED = "Not supported";
Lang.FLASH_WARNING_PLATFORM_UNSUPPORTED = "This platform does not support the Flash Player.";

Lang.ACCESSIBILITY_OPEN = "Open";
Lang.ACCESSIBILITY_CLOSED = "Closed";
Lang.ACCESSIBILITY_SELECTED = "Selected";
Lang.ACCESSIBILITY_DESELECTED = "Deselected";
Lang.ACCESSIBILITY_MENU_ITEM = "Menu item";
Lang.ACCESSIBILITY_DRAGGABLE = "Draggable Element";
Lang.ACCESSIBILITY_TARGET = "Target Element";
Lang.ACCESSIBILITY_ZOOM = "Zoom Image";
Lang.ACCESSIBILITY_ON = "ON";
Lang.ACCESSIBILITY_OFF = "OFF";
