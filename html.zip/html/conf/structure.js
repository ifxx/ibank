﻿
/**
structure.js (dynamic)
Published by ANCILE uPerform 5.30.0.77
*/

var initStructure = function()
{
	try
	{
		//Course Title
		engine.courseTitle="hi2";

		page_47eed2be1a0144a588cbcd1c4dc40690=new Page({recallChoice:null,title:"hi2",transcript:"",name:"page_47eed2be1a0144a588cbcd1c4dc40690",audio:null,transitionIn:"",transitionOut:"",animations:"",duration:""});
		engine.root=page_47eed2be1a0144a588cbcd1c4dc40690;


		page_58d4601a830a47038ab2e1db034ecad4=new Page({recallChoice:null,title:"pic",transcript:"",name:"page_58d4601a830a47038ab2e1db034ecad4",audio:"pytXXoTZ_N34f41_CjLjfBUtwUg=.wav.swf",transitionIn:"",transitionOut:"",animations:"",duration:""});
		engine.root.addPage(page_58d4601a830a47038ab2e1db034ecad4);


		page_3dd177d4330644ac801102e87adc7047=new Page({isAssessment:true,passingScore:70,pool:false,poolTotal:0,feedbackEnabled:true,randomQuestions:false,retakeAllowed:true,onlyRetakeIncorrect:false,isPostAssessment:true,showCorrectAnswers:true,title:"assessment",transcript:"",name:"page_3dd177d4330644ac801102e87adc7047",audio:"PPoqFqf3FLbR6grwbzMSq97lpyA=.wav.swf",transitionIn:"",transitionOut:"",animations:"",duration:""});
		engine.root.addPage(page_3dd177d4330644ac801102e87adc7047);


			page_bcd2d25ccac845f0836ce1efea97dbc0=new MultiCorrect({img:null,imgId:null,align:"",valign:"",style:"",caption:"",directions:"optional_text",stem:"%3Cp%3E%26%2321738%3B%26%2320010%3B%26%2322478%3B%26%2324066%3B%26%2326159%3B%26%2327993%3B%26%2327743%3B%26%2330340%3B%3C%2Fp%3E",corFb:"%26%2324456%3B%26%2322909%3B%20%26%2331572%3B%26%2323545%3B%26%2320102%3B",incFb:"%26%2319981%3B%26%2324184%3B%26%2331572%3B%26%2338169%3B%26%2320102%3B",incFb2:"Your%20response%20is%20still%20incorrect.",transcriptOverride:"",name:"page_bcd2d25ccac845f0836ce1efea97dbc0",audio:null,transitionIn:"",transitionOut:"",animations:"",duration:""});
			page_bcd2d25ccac845f0836ce1efea97dbc0.addChoice({txt:"%3Cp%3E%26%2338271%3B%26%2327801%3B%3C%2Fp%3E",correct:false});
			page_bcd2d25ccac845f0836ce1efea97dbc0.addChoice({txt:"%3Cp%3E%26%2326477%3B%26%2324030%3B%3C%2Fp%3E",correct:true});
			page_3dd177d4330644ac801102e87adc7047.assessment.addQuestion(page_bcd2d25ccac845f0836ce1efea97dbc0);


			page_a8fb493aceda4e4ea24da27cd3b50499=new DragDropManyToOne({directions:"Drag%20each%20correct%20item%20into%20the%20drop%20area.",stem:"%3Cp%3E%26%2321738%3B%26%2320010%3B%26%2322478%3B%26%2324066%3B%26%2326159%3B%26%2327993%3B%26%2327743%3B%26%2330340%3B%3C%2Fp%3E",corFb:"Your%20response%20is%20correct.",incFb:"Your%20response%20is%20incorrect.",incFb2:"Your%20response%20is%20still%20incorrect.",transcriptOverride:"",name:"page_a8fb493aceda4e4ea24da27cd3b50499",audio:"WlxZZcpNg82V9ZnscIY98zaswnM=.wav.swf",transitionIn:"",transitionOut:"",animations:"",duration:""});
			page_a8fb493aceda4e4ea24da27cd3b50499.addDrag({label:"长沙",correct:false});
			page_a8fb493aceda4e4ea24da27cd3b50499.addDrag({label:"杭州",correct:true});
			page_a8fb493aceda4e4ea24da27cd3b50499.addDrag({label:"南京",correct:false});
			page_3dd177d4330644ac801102e87adc7047.assessment.addQuestion(page_a8fb493aceda4e4ea24da27cd3b50499);


			page_544ba9cabb0748eaa634c3e0624e6bd9=new DragDropStandard({directions:"%3Cp%3E%26%2324038%3B%26%2321491%3B%26%2336830%3B%26%2332447%3B%3C%2Fp%3E",stem:"%3Cp%3E%26%2336873%3B%26%2325321%3B%26%2330465%3B%26%2320250%3B%3C%2Fp%3E",corFb:"Your%20response%20is%20correct.",incFb:"Your%20response%20is%20incorrect.",incFb2:"Your%20response%20is%20still%20incorrect.",transcriptOverride:"",name:"page_544ba9cabb0748eaa634c3e0624e6bd9",audio:null,transitionIn:"",transitionOut:"",animations:"",duration:""});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addDrag({target:"target_00000000000000000000000000000006",label:"江苏"});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addDrag({target:"target_00000000000000000000000000000007",label:"湖南"});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addDrag({target:"target_00000000000000000000000000000008",label:"浙江"});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addTarget({id:"target_00000000000000000000000000000006",label:"南京"});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addTarget({id:"target_00000000000000000000000000000007",label:"长沙"});
			page_544ba9cabb0748eaa634c3e0624e6bd9.addTarget({id:"target_00000000000000000000000000000008",label:"杭州"});
			page_3dd177d4330644ac801102e87adc7047.assessment.addQuestion(page_544ba9cabb0748eaa634c3e0624e6bd9);



		Utils.debug.trace('Structure initialized successfully');		
	}
	catch(e)
	{
		Utils.debug.trace('Error: Cannot inialize structure: '+(e.description || e));
	}
};
