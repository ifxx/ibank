
var initAssessmentSummary = function()
{
	try
	{
		if(engine)
		{
		    var assessment;
		    if (engine.controller.passAssessment && window.location.href.indexOf('passAssessment=true') > 0)
		    {
		        assessment = engine.controller.passAssessment;
		    }
		    else
		    {
		        assessment = engine.controller.currentPageObj.assessment;
		    }
			var retakeAllowed = assessment.retakeAllowed;
			var passingScore = assessment.passingScore;
			var score = assessment.score;
			var completed = assessment.completed;
			var bypassed = assessment.bypassed;
			var quesTotal = assessment.quesTotal;
			var questionList = assessment.questionList;
			
			this.btnSendResults = $("btnSendResults", this.contentDoc);
			this.btnRetakeAssessment = $("btnRetakeAssessment", this.contentDoc);
			this.btnExitCourse = $("btnExitCourse", this.contentDoc);
			
			this.btnSendResults.onclick = function()
			{
				assessment.sendResults();
			};
			
			this.btnRetakeAssessment.onclick = function()
			{
				assessment.retakeAssessment();
			};
			
			this.btnExitCourse.onclick = function()
			{
				engine.displayExitPrompt();
			};
			
			if(!assessment.retakeAllowed || (assessment.onlyRetakeIncorrect && assessment.passed) || (assessment.retakeAllowed && score >= passingScore))
			{
				Utils.dom.hide("btnRetakeAssessment");
			}
			
			if(!engine.comm.enableManualSubmit)
			{
				Utils.dom.hide("btnSendResults");
			}
			
			Utils.dom.renderHTML('passingScoreDisplayHeader',unescape(Lang.ASSESSMENT_SUMMARY_PASSING_SCORE));
			Utils.dom.renderHTML('yourScoreDisplayHeader',unescape(Lang.ASSESSMENT_SUMMARY_YOUR_SCORE));
			
			if(assessment.passed)
			{
				// Passed
				Utils.dom.setStyleById('passed','display','block');
				Utils.dom.setStyleById('failed','display','none');
				Utils.dom.renderHTML('passed','<p>'+unescape(Lang.ASSESSMENT_PASS_TEXT)+'</p>');
				Utils.dom.renderHTML('yourScoreDisplay','<span class="passed">'+score+'</span>');
			}
			else
			{
				// Failed
				Utils.dom.setStyleById('passed','display','none');
				Utils.dom.setStyleById('failed','display','block');
				Utils.dom.renderHTML('failed','<p>'+unescape(Lang.ASSESSMENT_FAIL_TEXT)+'</p>');
				Utils.dom.renderHTML('yourScoreDisplay','<span class="failed">' + score + '</span>');
			}
			
			Utils.dom.renderHTML('passingScoreDisplay',passingScore);

			if(completed && bypassed)
			{
				if(assessment.passed)
				{
					Utils.dom.renderHTML('noRetakeMessage','<p>'+unescape(Lang.ASSESSMENT_ALREADY_PASSED)+'</p>');
				}
				else
				{
					Utils.dom.renderHTML('noRetakeMessage','<p>'+unescape(Lang.ASSESSMENT_SUMMARY_NO_RETAKE)+'</p>');
				}
			}
			
			if(Conf.SHOW_QUESTIONS_IN_SUMMARY)
			{
				if(Conf.SHOW_CORRECT_QUESTIONS_IN_SUMMARY)
				{
					Utils.dom.renderHTML('resultsListLegend',unescape(Lang.ASSESSMENT_QUESTION_RESULTS));
				}
				else
				{
					Utils.dom.renderHTML('resultsListLegend',unescape(Lang.ASSESSMENT_INC_QUESTION_RESULTS));
				}
				
				// Check to see if the assessment has been completed either in this session or in a previous session.
				// If there are no questions, we know that we've bypassed the assessment in a session where there
				// were never any questions added to the questionList array, making it a subsequent session.
				if(completed && (questionList.length > 0))
				{
					if(score < 100)
					{
						var html = '';
						
						for (var i = 0; i < quesTotal; i++)
						{
							var correct = questionList[i].correct;

							var stem = (questionList[i].stem != "") ? unescape(questionList[i].stem) : '';
							
							if(Conf.SHOW_CORRECT_QUESTIONS_IN_SUMMARY) 
							{
								html += '<div class="correct_' + correct + '">';
								html += '	<div class="correct_header_' + correct + '">';
								html += '		<p id="correct">'+unescape(Lang.ASSESSMENT_QUESTION)+' '+(i+1)+'/'+assessment.realQuesTotal+'</p>';
								html += '	</div>';
								html += '	<div class="stem">'+stem+'</div>';
								html += '	<p>'+questionList[i].getSummary()+'</p>';
								html += '</div>';
							}
							else 
							{
								if(!questionList[i].correct) 
								{
									html += '<div class="correct_' + correct + '">';
									html += '	<div class="correct_header_' + correct + '">';
									html += '		<div style="display: table">';
									html += '		<div style="display: table-row">';
									html += '			<div class="summary_incorrect_icon">&nbsp;</div>';
									html += '			<div style="display: table-cell">'; 
									html += '				<p id="incorrect">'+unescape(Lang.ASSESSMENT_QUESTION)+' '+(i+1)+'/'+assessment.realQuesTotal+'</p>';
									html += '			</div>';									
									html += '		</div>';
									html += '		</div>';
									html += '	</div>';
									html += '	<div class="stem">'+stem+'</div>';
									html += '	<p>'+questionList[i].getSummary()+'</p>';
									html += '</div>';
								}
							}
						}
						
						Utils.dom.renderHTML('resultsList',html);
						addImageEvents(engine);
					}
					else
					{
						Utils.dom.renderHTML('resultsList','<div class="noresults">'+unescape(Lang.ASSESSMENT_ANSWERED_ALL_CORRECTLY)+'</div>');
					}
				}
				else
				{
					Utils.dom.renderHTML('resultsList',unescape(Lang.ASSESSMENT_RESULTS_NOT_AVAILABLE));
				}
			}
			else
			{
				Utils.dom.setStyleById('resultsListFieldset','display','none', '');
			}

			window.addEvent('resize', function(e){
				updateAnswers(e);
			});
		}
	}
	catch(e)
	{
		alert('Error: Cannot initialize assessment summary page. '+e);
	}
};

var showCorrectAnswer = function(container)
{
	$(container).show();
	$(container+'_hide').setStyle('display','inline');
	$(container+'_show').setStyle('display','none');
	updateAnswers();
	setTimeout(function(){if(contentScroller){contentScroller.refresh()}},0);
};

var hideCorrectAnswer = function(container)
{
	$(container).hide();
	$(container+'_show').setStyle('display','inline');
	$(container+'_hide').setStyle('display','none');
	updateAnswers();
	setTimeout(function(){if(contentScroller){contentScroller.refresh()}},0);
};

var showIncorrectAnswer = function(container)
{
	$(container).show();
	$(container+'_hide').setStyle('display','inline');
	$(container+'_show').setStyle('display','none');
	updateAnswers();
	setTimeout(function(){if(contentScroller){contentScroller.refresh()}},0);
};

var hideIncorrectAnswer = function(container)
{
	$(container).hide();
	$(container+'_show').setStyle('display','inline');
	$(container+'_hide').setStyle('display','none');
	updateAnswers();
	setTimeout(function(){if(contentScroller){contentScroller.refresh()}},0);
};

var updateHotspotOverlay = function(container,hsX,hsY,stampX,stampY,isCorrect)
{
	var img = $(container).getElements('img.hsImg')[0];
	var imgX = Utils.dom.findPosX($(img))+$('wrapper').scrollLeft;
	var imgY = Utils.dom.findPosY($(img))+$('wrapper').scrollTop;

	//hotspot
	var hotspot = $(container).getElement('div.hotspotInteractionArea');
	if(hsX == null || hsY == null)
	{
		var hsX = hotspot.retrieve('x');
		var hsY = hotspot.retrieve('y');
		var offsetX = imgX+hsX;
		var offsetY = imgY+hsY;
	}
	else
	{
		var offsetX = imgX+hsX;
		var offsetY = imgY+hsY;
		hotspot.store('x',hsX);
		hotspot.store('y',hsY);
	}
	hotspot.setStyles({
		left:offsetX-$('wrapper').scrollLeft,
		top:offsetY-$('wrapper').scrollTop
	});

	//stamp
	var stamp = $(container).getElement('div.hotspotInteractionStamp');
	if(stampX == null || stampY == null)
	{
		var stampX = stamp.retrieve('x');
		var stampY = stamp.retrieve('y');
		var offsetX = imgX+stampX;
		var offsetY = imgY+stampY;
	}
	else
	{
		if(isCorrect)
		{
			var offsetX = imgX+hsX;
			var offsetY = imgY+hsY;
			stamp.store('x',hsX);
			stamp.store('y',hsY);
		}
		else
		{
			var offsetX = imgX+stampX;
			var offsetY = imgY+stampY;
			stamp.store('x',stampX);
			stamp.store('y',stampY);
		}
	}
	stamp.setStyles({
		left:offsetX-$('wrapper').scrollLeft,
		top:offsetY-$('wrapper').scrollTop
	});
};

var addImageEvents = function(engine)
{
	var images = $$('#resultsList img');
	if (images.length > 0) {
		images.each(function(item,index){
			item.addEvents({
				load: function(){ checkImagesLoaded(item);},
				error: function(){ errImagesLoaded();},
				readystatechange: function(){ checkImagesLoaded(item);}
			});
		});
	}
}

var updateAnswers=function(e)
{
	// Hotspot interaction answers
	var hotspotAnswers = $('resultsList').getElements('div.hotspotAnswer');
	hotspotAnswers.each(function(item,index){
		updateHotspotOverlay(item);
	});
};

window.addEvent('domready', function(){
	initAssessmentSummary();
});
