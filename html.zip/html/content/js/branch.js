
/**
* Initializes the branch stencil
* @method initBranch
*/
var initBranch = function()
{
	try
	{
		if(engine)
		{
		    var pageObj = getCurrentPage();
		    if (pageObj) {
		        var branch = pageObj.branch;
		        if (branch) {
		            branch.init(window, window.document);
		            //Only preload choices for content iframe not for other iframes
		            if (window.name == 'content')
		            {
		                branch.setPreloadChoices();
		            }
		        }
		    }
		}
	}
	catch(e){}
};

window.addEvent('domready', function(){
	initBranch();
});