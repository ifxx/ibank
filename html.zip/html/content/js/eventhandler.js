/** 
* Global singleton JavaScript event handler library (content-level)
* @type {Object}
*/
if(!window.EventHandler)
{
	window.EventHandler = {

		createKeyListeners: function()
		{
			if(document.addEventListener)
			{
				document.addEventListener('keydown', EventHandler.keyDown, true);
				if(document.onkeypress){document.addEventListener('keypress', EventHandler.doNothing, true);}
				parent.Utils.debug.trace('Key listeners registered');
			}
			else if(document.attachEvent)
			{
				document.attachEvent('onkeydown',EventHandler.keyDown);
				if(document.onkeypress){document.attachEvent('onkeypress',EventHandler.doNothing);}
				parent.Utils.debug.trace('Key events attached');
			}
			else
			{
				document.onkeydown = EventHandler.keyDown;
				if(document.onkeypress){document.onkeypress = EventHandler.doNothing};
				parent.Utils.debug.trace('Key events assigned');
			}
		},

		keyDown: function(e)
		{
			if(parent.engine)
			{
				if(!e) var e = window.event;
			
				return parent.EventHandler.keyDown(e);
			}
		},

		toString: function()
		{
			return "Event Handler Instance";
		}
	}
}