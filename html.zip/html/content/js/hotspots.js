/*
 * Custom Hotspots with borders
 * ---
 * 
 * Hotspot object members:
 * 	- id: 		The ID of the hotspot DIV
 * 	- img:		The image this hotspot belongs to
 * 	- w:		The width of the hotspot
 * 	- h:		The height of the hotspot
 *  - x:		The X location of the hotspot relative to its image
 *  - y:		The Y location of the hotspot relative to its image
 *  - action:	The action type of the hotspot - "hover" or "click"
 *  - type:		The type of hotspot this is - "popup", "pagelink" or "link"
 *  - href:		The URL for this hotspot if it is "click" action and "link" type
 *  - visible:	Should the hotspot be visible by default, or only appear on mouseover
 *  - tooltip:	The title attribute of the main hotspot DIV
 *  
 *  Example Usage:
 *  ---
 *  hotspots.push({id:'hotspot1', img:'img1', w:220, h:50, x:70, y:270, action:'hover', type:'popup', popupId:'popup3', href:'', color:'#ff00ff', visible:true, tooltip:'This is a hotspot'});
 *  hotspots.push({id:'hotspot2', img:'img2', w:90, h:40, x:10, y:10, action:'click', type:'link', popupId:'', href:'http://www.google.com', color:'#ccffcc', visible:false, tooltip:'This is a hotspot'});
 *  hotspots.push({id:'hotspot3', img:'img3', w:159, h:270, x:100, y:15, action:'click', type:'pagelink', popupId:'', href:'page_1234567890', color:'#ccffcc', visible:true, tooltip:'Click here to visit page X'});
 */

if(!window.Hotspot){window.Hotspot = {};}
Hotspot.hotspots = [];

/**
* Creates the hotspots and assigns their events/functionality
*/
Hotspot.createHotspots = function()
{
	var len = Hotspot.hotspots.length;
	for (var i = 0; i < len; i++)
	{
		var hs = Hotspot.hotspots[i];
		var id = hs.popupId;

		if(!Hotspot.isImageLoaded(hs)){continue;}

		// Create the hotspot DIV element
		if(!$(hs.id))
		{
			var hsContainerDiv = new Element("div",{
				'id': hs.id+"Container",
				'class': "hotspotContainer"
			});
			$('container').adopt(hsContainerDiv);
			
			var hsDiv = new Element("div",{
				'id': hs.id				
			});

			var hsGlassDiv = new Element("div",{
	            'id': hs.id+"Glass",
				'class': "hotspotBG"
			});

			hsDiv.adopt(hsGlassDiv);
			            								
            if (hs.backImage)
            {
                var imgHotspot = new Element("img",{
                   'src': unescape(hs.backImage),
                   'zoom':"false"
                });
                
                imgHotspot.setStyle('position', 'absolute');
                imgHotspot.setStyle('margin-top', hs.margintop+'px');
                if (hs.align == "right"){
                	imgHotspot.setStyle('right', 0);
                } else if (hs.align == "left"){
                	imgHotspot.setStyle('left', 0);
                } else {
                	imgHotspot.setStyle('left', parseInt(hs.align));
                }
               
                hsDiv.adopt(imgHotspot);
            }           

			if(hs.toolTip)
			{
				hsDiv.title = unescape(hs.toolTip);
			}
			$(hs.id+"Container").adopt(hsDiv);
		}

		//Sets the positioning of the contents within the hotspot to absolute
		Utils.dom.setStyleById(hs.id, 'position', 'relative');
		Utils.dom.setStyleById(hs.id+"Glass", 'position', 'absolute');
		
		
		// Set the hotspot DIV element's styles/properties
		Utils.dom.setStyleById(hs.id, 'width', hs.w, 'px');
		Utils.dom.setStyleById(hs.id, 'height', hs.h, 'px');
		Utils.dom.setStyleById(hs.id+"Glass", 'width', hs.w, 'px');
		Utils.dom.setStyleById(hs.id+"Glass", 'height', hs.h, 'px');
		
		Utils.dom.setStyleById(hs.id+"Container", 'borderColor', unescape(hs.color));
		Utils.dom.setStyleById(hs.id+"Glass", 'backgroundColor', unescape(hs.color));
        Utils.dom.setStyleById(hs.id, 'overflow', "hidden");

		if (!hs.useTransparency)
		{
			Utils.dom.setOpacity(100,hs.id);
			Utils.dom.setOpacity(0,hs.id+"Glass");
			Utils.dom.setStyleById(hs.id+"Glass", 'visibility', 'visible');
			Utils.dom.setStyleById(hs.id+"Container", 'border', "none");
		}
		
		$(hs.id).popupId = hs.popupId;
		$(hs.id).container = $(hs.id+"Container");
		$(hs.id).visible = hs.visible;
		$(hs.id).href = unescape(hs.href);
		$(hs.id).type = hs.type;
		$(hs.id).newWindow = hs.newWindow;
		$(hs.id).tabIndex = 0;
		
		// If this hotspot is not "visible", set the opacity to 0.
		if(!hs.visible)
		{
			Utils.dom.setOpacity(0, hs.id+"Container");
			$(hs.id+"Container").style.visibility = "visible";
		}

		if(Utils.browserDetection.isMobile()) // No hover on iPad
		{
			hs.action = "click";
		}
		
		switch(hs.action)
		{
			// Clickable Hotspot
			case "click":
				var onDown = function(e,self)
				{
					switch(self.type)
					{
						case "link":
							Utils.window.open(self.href,'auxWin',800,600,'resizable,scrollbars,location,menubar');
							break;
						case "pagelink":
							pageLink(self.href);
							break;
						case "popup":
							var closePopupLink = Utils.dom.getElementsByClassName($(self.popupId), "closePopup");
							var el = Utils.dom.getEventTargetElement(e);
							Utils.popup.show(self.popupId,self);
							$(self.popupId).focus();
							setTimeout(function(){$(closePopupLink).getChildren('a')[0].focus();},500);
							break;
						case "resourcelink":
							resourceLink(self.href, self.newWindow);
							break;
						default:
							alert("Error: No valid hotspot type has been defined.");
					}
				};
				$(hs.id).onclick = function(e)
				{
					if(!e) var e = window.event;
					onDown(e,this);
				};
				$(hs.id).onkeydown = function(e)
				{
					if(!e) var e = window.event;
					if(e.keyCode == 13 || e.keyCode == 32)
					{
						parent.EventHandler.killEvent(e);
						onDown(e,this);						
					}
				};

				if(!hs.visible)
				{
					$(hs.id).container.onmouseover = function(e)
					{
						this.style.visibility = "visible";
						Utils.dom.setOpacity(100,this);
					};
					$(hs.id).container.onfocus = function(e)
					{
					    this.style.visibility = "visible";
						Utils.dom.setOpacity(100,this);
					};

					$(hs.id).container.onmouseout = function(e)
					{
						Utils.dom.setOpacity(0,this);
						this.style.visibility = "visible";
					};
					$(hs.id).container.onblur = function(e)
					{
						Utils.dom.setOpacity(0,this);
						this.style.visibility = "visible";
					};
				}
				break;
			
			// Hover-type Hotspot
			case "hover":
				// Hide the "Close" link in popups where "hover" is used to display the popup...
				var closePopupLink = Utils.dom.getElementsByClassName($(id), "closePopup");
				closePopupLink.style.display = "none";
				var overFunc = function(e,self)
				{
					var el = Utils.dom.getEventTargetElement(e);
					Utils.popup.showNoClose(self.popupId,self);
					if(!self.visible)
					{
						Utils.dom.setOpacity(100,self.container);
						//Utils.dom.fadeIn(self.container);
					}
				};

				var outFunc = function(e,self)
				{
					var el = Utils.dom.getEventTargetElement(e);
					Utils.popup.hide(self.popupId);
					if (!self.visible)
					{
						Utils.dom.setOpacity(0,self.container.id);
						$(self.id+"Container").style.visibility = "visible";
					}
				};

				$(hs.id).onmouseover = function(e)
				{
					overFunc(e,this);
				};
				$(hs.id).onfocus = function(e)
				{
					overFunc(e,this);
				};
				$(hs.id).onclick = function(e)
				{
					overFunc(e,this);
				};

				$(hs.id).onmouseout = function(e)
				{
					outFunc(e,this);
				};
				$(hs.id).onblur = function(e)
				{
					outFunc(e,this);
				};
								
				break;
		}
	}
	
	// Update on the hotspot locations
	var func=function()
	{
		Hotspot.updateHotspots();
	};
	var t = (Utils.browserDetection.isMobile()) ? 500 : 0;
	setTimeout(func,t);
};

/**
* Removes all "old" hotspots and existing images, in the case of an assessment, etc.
* where a page doesn't reload before adding further hotspots.
*/
Hotspot.removeHotspots=function()
{
	var len = Hotspot.hotspots.length;
	for (var i = 0; i < len; i++)
	{
		var hs = Hotspot.hotspots[i];
		if($(hs.id))
		{
			$(hs.id).parentNode.removeChild($(hs.id));
			$(hs.id+"Container").parentNode.removeChild($(hs.id+"Container"));
		}
		if($(hs.img))
		{
			$(hs.img).parentNode.removeChild($(hs.img));
		}
	}
	Hotspot.hotspots = [];
};

/**
* Updates the position of the hotspots in the event of window resize
*/
Hotspot.updateHotspots=function()
{
	for(var i=0;i<Hotspot.hotspots.length;i++)
	{
		var hs = Hotspot.hotspots[i];
		var x = Utils.dom.findPosX($(hs.img));
		var y = Utils.dom.findPosY($(hs.img));

		if(Utils.browserDetection.isMobile())
		{
			x -= $('container').getStyle('margin-left').toInt();
		}
		if($(hs.img))
		{
			Utils.dom.setStyleById(hs.id+"Container", 'top', y + hs.y, 'px');
			Utils.dom.setStyleById(hs.id+"Container", 'left', x + hs.x, 'px');
		}
	}
};
Hotspot.showAllHotspotPopups=function()
{
	for(var i=0;i<Hotspot.hotspots.length;i++)
	{
		var hs = Hotspot.hotspots[i];
		if ($(hs.popupId)){
			Utils.popup.showDefault(hs.popupId,$(hs.id+"Container"));
		}
	}
};
Hotspot.isImageLoaded=function(hs)
{
	var img = $(hs.img)
	if(img.readyState)
	{
		if(img.readyState === "complete")
		{
			return true;
		}
	}
	else
	{
		if(img.complete)
		{
			return true;
		}
	}
	return false;
};
window.addEvent('load', function(){
	/*Hotspot.createHotspots();
	Utils.popup.showAll();*/
});
window.addEvent('resize', function(){
	Hotspot.updateHotspots();
});
