
var engine = self.parent.engine;
var contentScroller;
var inited = false;
var isError = false;
var isLoaded;
var imgLoadedCount = 0;
var waitingLoadImage;
var container;

/**
* Inits content-level functionality and checks to see if this page has been loaded into the top level window...
* If not, we need to redirect user to the engine, using this page as the start page.
*/
var initContent = function () {
    
    if (inited) { return; }
    inited = true;
    if (window.initTimeout) {
        clearTimeout(window.initTimeout);
    }

    engine = self.parent.engine;

    Utils.browserDetection.init();

    // If I'm on my own, load the main course and pass my name to it
    if (!engine) {
        if (Utils.window.isSameDomain('top') && Conf.ENABLE_CHECK_FOR_ENGINE) {
            top.location.href = '../course.htm?uperform_startpage=' + Utils.window.getFileName();
        }
    }
    else {
        EventHandler.createKeyListeners();
    }

    createMobileScroller();

    waitingLoadImage = $('waitingLoadImage');

    if (waitingLoadImage) {
        waitingLoadImage.destroy();
    }

    if (parent && parent.Conf.ENABLE_TRANSITIONS) {
        fadeInContainer();
    }
    else {
        showContainer();
    }

    //only play transition with content frame
    if (window.name == 'content')
    {
        if (engine.controller.currentPageObj.assessment && engine.controller.pageList.length == 1) {
            // fix preview for assessment stencils
            // delay to wait the assessment is rendered completely
            var wrapper = document.getElementById('wrapper');
            wrapper.style.visibility = 'hidden';
            setTimeout(function () { wrapper.style.visibility = 'visible'; playTransition(); }, 500);
        }
        else {
            playTransition();
        }
    }
    recallChoice();

    document.ontouchstart = function (e) {
        Utils.dom.updateTouchPos(e);
    };
    document.onmousemove = function (e) {
        Utils.dom.updateCursorPos(e);
    };
    document.ondragstart = function (e) {
        return false;
    };
};

var createMobileScroller = function () {
    if (Utils.browserDetection.isMobile()) {
        document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

        if (contentScroller) {
            contentScroller.destroy();
            contentScroller = null;
        }

        contentScroller = new iScroll('wrapper');

        parent.onorientationchange = function () {
            setTimeout(function () { contentScroller.refresh(); }, 0);
        }

        var formEls = document.getElements('input');
        formEls.each(function (item, index) {
            item.addEventListener('touchstart', function (e) {
                e.stopPropagation();
            }, false);
        });
    }
};

/**
* Allows linking to resources within the course
*/
var resourceLink = function (resourceName, newwindow) {
    if (engine) {
        engine.controller.goToResourceByName(resourceName, newwindow);
    }
};

/**
* Allows content pages to link to each other within the course
*/
var pageLink = function (pageName) {
    if (engine) {
        engine.controller.gotoPageByName(pageName);
    }
};

/**
* Allows content pages to recall and display a persisted choice made on a previous MC page
*/
var recallChoice = function () {
    if (engine) {
        var choicePageName = engine.controller.currentPageObj.recallChoice;
        if (choicePageName != null) {
            var recallContainerDiv = document.createElement("div");
            recallContainerDiv.id = "recallContainer";
            $("container").appendChild(recallContainerDiv);

            var page = engine.controller.getPageByName(choicePageName);
            var choiceText = page.persistedChoiceText;
            if (choiceText) {
                Utils.dom.renderHTML("recallContainer", "<p><b>" + unescape(Lang.ASSESSMENT_SUMMARY_YOUR_CHOICE_WAS) + ":</b> " + choiceText.replace(/<\/?[^>]+(>|$)/g, "") + "</p>");
            }
        }
    }
};

var hidePopups = function () {
    var len = document.getElementsByTagName('div').length;
    for (var i = 0; i < len; i++) {
        var div = document.getElementsByTagName('div')[i];
        if (div.id.indexOf("pu_") >= 0) {
            Utils.popup.hide(div.id);
        }
    }
};

var showAllPopups = function () {
    Utils.popup.showAll();
};

/**
* Check if the images on a content or assessment page has finished loading 
*/
var checkImagesLoaded = function (imgSrc) {
    var images = $$('#container img[onload^=checkImagesLoaded]');
    isLoaded = false;
    if (images.length > 0) {
        if (imgSrc.readyState) {
            if (imgSrc.readyState === "complete") {
                imgLoadedCount++;
                imgSrc.onreadyStatechange = null;
                imgSrc.onload = null;
            }
        } else {
            if (imgSrc.complete) {
                imgLoadedCount++;
            }
        }
    }
    if (images.length > 0 && images.length == imgLoadedCount) {
        isLoaded = true;
        initContent();
    }
    if (inited) {
        Hotspot.createHotspots();
        Zoom.createZoomButtons();
    }
};

/**
* Check if the images on a content or assessment page has finished loading 
*/
var errImagesLoaded = function () {
    isError = true;
    initContent();
    parent.Utils.debug.trace("errImagesLoaded");
};

/**
* Fades in the content within the "container" DIV, in which all HTML *must* reside
*/
var fadeInContainer = function () {
    container = $("container");

    if (typeof container != "undefined") {
        Utils.dom.fadeIn(container, function () {
            Utils.dom.removeFilter($("container"));
            Hotspot.createHotspots();
            Zoom.createZoomButtons();
            Utils.popup.showAll();
        });
    }
};

/**
* When transitions are disabled, displays the content within the "container" DIV
*/
var showContainer = function () {
    container = $("container");

    if (typeof container != "undefined") {
        Utils.dom.setOpacity(100, container, document);
        Hotspot.createHotspots();
        Zoom.createZoomButtons();
        Utils.popup.showAll();
    }
};

var supportsVideo = function () {
    return !!document.createElement('video').canPlayType;
};

var supportsVideoFormat = function (format) {
    if (!supportsVideo()) { return false; }

    var v = document.createElement("video");
    return !!v.canPlayType && "" != v.canPlayType(format);
};

function onVideoError(i) {
    loadVideos(i);
};

var loadVideos = function (index) {
    
    var videoContainers = document.getElements('.videoContainer');


    for (i = 0; i < videoContainers.length; i++) {
        if(index && i != index)
        {
            continue;
        }
        
        var videoID = videoContainers[i].id;
        var offsetWidth = videoContainers[i].offsetWidth;

        var videoAttributesString = videoContainers[i].parentNode.innerText;
        if (videoAttributesString == null || !videoAttributesString)
        {
            videoAttributesString = videoContainers[i].parentNode.textContent;
        }
        
        var isLocalVideo = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidLocalVideo')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidLocalVideo'))));
        
        isLocalVideo = (isLocalVideo.indexOf("true") > -1);
        
        if(isLocalVideo)
        {
            var vidWidth = parseInt(videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidWidth')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidWidth')))));
            var vidHeight = parseInt(videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidHeight')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidHeight')))));
            var vidFile = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidFile')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidFile'))));
            vidFile = vidFile.replace(/['"]+/g, '');
            var vidId = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidId')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidId'))));
            vidId = vidId.replace(/['"]+/g, '');
            var vidLoop = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidLoop')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidLoop'))));
            vidLoop = vidLoop.replace(/['"]+/g, '');
            var vidAutoPlay = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidAutoPlay')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidAutoPlay'))));
            vidAutoPlay = vidAutoPlay.replace(/['"]+/g, '');
            var vidVolume = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidVolume')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidVolume'))));
            vidVolume = vidVolume.replace(/['"]+/g, '');
            var vidTitle = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidTitle')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidTitle'))));
            vidTitle = vidTitle.replace(/['"]+/g, '');
            var vidMarginTop = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidMarginTop')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidMarginTop'))));
            vidMarginTop = vidMarginTop.replace(/['"]+/g, '');
            var vidStartTime = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidStartTime')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidStartTime'))));
            vidStartTime = vidStartTime.replace(/['"]+/g, '');
            var vidEndTime = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidEndTime')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidEndTime'))));
            vidEndTime = vidEndTime.replace(/['"]+/g, '');
			var vidCaption = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidCaption')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidCaption'))));
			vidCaption = vidCaption.replace(/\\"/g, '&quot;').replace(/[']+/g, '&#39;').replace(/%3B+/g, ';').replace(/%3D+/g, '=').slice(1,-1);
				
            if (vidWidth > offsetWidth) {
                var ratio = offsetWidth / vidWidth;
                vidWidth = vidWidth * ratio;
                vidHeight = vidHeight * ratio;
            }

            vidVolume = new Number((vidVolume / 255) * 100).toFixed(2);
            var ext = /[^.]+$/.exec(vidFile).toString().toLowerCase();
            var startTime = formattedDurationToSeconds(vidStartTime, false);
            if (vidEndTime != "null") {
                var endTime = formattedDurationToSeconds(vidEndTime, true);
            }

            var isCanPlayWithHtml5Video = supportsVideoFormat("video/mp4");
            if (isCanPlayWithHtml5Video && (ext === "mp4" || ext === "mov") && Utils.browserDetection.isMobile()) {
                var volume = (vidVolume / 100);
                var voAtts = {
                    src: vidFile,
                    id: vidId,
                    width: vidWidth,
                    height: vidHeight,
                    preload: "preload",
                    controls: "controls",
                    tabindex: 0,
                    title: vidTitle
                };

                if (vidAutoPlay) {
                    voAtts.autoplay = "autoplay";
                }

                if (vidLoop) {
                    voAtts.loop = "loop";
                }

                var vo = new Element("video", voAtts);

                vo.addEventListener('canplaythrough', function (e) {
                    if (startTime > 0) {
                        this.currentTime = startTime;
                    }
                    this.volume = volume.toFixed(2);
                }, true);
                vo.addEventListener('timeupdate', function (e) {
                    if (this.currentTime >= endTime) {
                        this.pause();
                    }
                }, true);

                $("videoContainer").adopt(vo);
            }
            else if (index != i && isCanPlayWithHtml5Video && (ext === "mp4" || ext === "mov")){
                var vidHTML = '<video id="' + vidId + '" width="' + vidWidth + '" height="' + vidHeight + '" title="' + vidCaption +'" controls onerror="onVideoError(' + i + ')" style="margin-top:' + vidMarginTop + 'px;"';
                if(vidAutoPlay=='true'){
                     vidHTML += ' autoplay="autoplay"';
                }
                if(vidLoop=='true'){
                    vidHTML += ' loop="loop"';
                }
                vidHTML += '>';
                vidHTML += '<source src="' + vidFile + '" type="video/mp4" onerror="onVideoError(' + i + ')">';
                vidHTML += '<script>'
                vidHTML += 'var video = document.getElementById(' + vidId + ');';
                vidHTML += 'video.volume = ' + vidVolume + ';';
                vidHTML += 'video.addEventListener("loadedmetadata", function(){';
                vidHTML += 'this.currentTime = ' + vidStartTime + ';';
                vidHTML += '}, false);';
                vidHTML += '</script>';
                vidHTML += '</video>';
                $(videoID).set("html", vidHTML);
            }
            else {
                var embMsg = (Lang.NO_EMBED_MSG) ? Lang.NO_EMBED_MSG : "";
                if (ext === "wmv" || ext === "asf") {
                    // WMP
                    var vidHTML = '<object style="margin-top:' + vidMarginTop + 'px" id="' + vidId + '" width="' + vidWidth + '" height="' + vidHeight + '" onreadystatechange="handleReadyStateChange(this)" tabindex="0" title="' + vidTitle + '" classid="CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6" type="application/x-oleobject">';
                    vidHTML += '	<param name="url" value="' + vidFile + '">';
                    vidHTML += '	<param name="autostart" value="' + vidAutoPlay + '">';
                    vidHTML += '	<param name="showcontrols" value="true">';
                    vidHTML += '	<param name="stretchtofit" value="true">';
                    vidHTML += '	<param name="autosize" value="true">';
                    if (vidLoop === "true") {
                        vidHTML += '	<param name="playcount" value="999">';
                    } else {
                        vidHTML += '	<param name="playcount" value="false">';
                    }
                }
                else {
                    var vidHTML = '<object id="' + vidId + '" width="' + vidWidth + '" height="' + vidHeight + '" tabindex="0" title="' + vidTitle + '">';
                    vidHTML += '	<param name="src" value="' + vidFile + '">';
                }

                vidHTML += '	<param name="loop" value="' + vidLoop + '">';
                vidHTML += '	<param name="volume" value="' + vidVolume + '">';

                // Quicktime
                vidHTML += '	<param name="controller" value="true">';
                vidHTML += '	<param name="autoplay" value="' + vidAutoPlay + '">';
                vidHTML += '	<param name="starttime" value="' + vidStartTime + '">';
                if (vidEndTime != "null") {
                    vidHTML += '	<param name="endtime" value="' + vidEndTime + '">';
                }
                vidHTML += '	<param name="enablejavascript" value="true">';
                vidHTML += '	<param name="scale" value="aspect">';

                var embedType = (ext === "wmv" || ext === "asf") ? 'type="application/x-mplayer2"' : '';
                vidHTML += '	<embed src="' + vidFile + '" id="' + vidId + '" ' + embedType + ' title="' + vidTitle + '" style="margin-top:' + vidMarginTop + 'px" width="' + vidWidth + '" height="' + vidHeight + '" autoplay="' + vidAutoPlay + '" controller="true" loop="' + vidLoop + '" volume="' + vidVolume + '" starttime="' + vidStartTime + '" ';
                if (vidEndTime != "null") {
                    vidHTML += 'endtime="' + vidEndTime + '" ';
                }
                if (ext === "wmv" || ext === "asf") {
                    if (vidLoop === "true") {
                        vidHTML += 'playcount="' + vidLoop + '" ';
                    }
                }
                vidHTML += 'scale="aspect" autosize="true" showcontrols="true" autostart="' + vidAutoPlay + '">';
                vidHTML += '		<noembed>' + embMsg + '</noembed>';
                vidHTML += '	</embed>';
                vidHTML += '</object>';

                $(videoID).set("html", vidHTML);
            }
        }
        else
        {
            var vidId = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidId')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidId'))));
            vidId = vidId.replace(/['"]+/g, '');
            var vidCaption = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidCaption')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidCaption'))));
            
			if(vidCaption.length > 1)
            {
			   vidCaption = vidCaption.replace(/\\"/g, '&quot;').replace(/[']+/g, '&#39;').replace(/%3B+/g, ';').replace(/%3D+/g, '=').slice(1,-1);
            }
            var embed = videoAttributesString.substring(videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidEmbeddedCode')) + 1, videoAttributesString.indexOf(";", videoAttributesString.indexOf("=", videoAttributesString.indexOf(videoID + 'vidEmbeddedCode'))));
            embed = embed.substring(1,embed.length-1);
            var vidEmbeddedCode = '<div id="' + vidId + '" alt="' + vidCaption + '">' + embed + '</div>';
            $(videoID).set("html",vidEmbeddedCode);
        }
    }
};


var handleReadyStateChange = function (el) {
    if (el.readyState >= 3) {
        if (vidEndTime == "null") { return; }
        var startTime = formattedDurationToSeconds(vidStartTime, false);
        var endTime = formattedDurationToSeconds(vidEndTime, true);
        el.controls.currentPosition = startTime;

        var func = function () {
            if (el.controls.currentPosition >= endTime) {
                el.controls.pause();
            }
            setTimeout(function () { func(); }, 500);
        };
        func();
    }
};

var formattedDurationToSeconds = function (time, increment) {
    var t = time.split(":");
    if (t.length == 4) {
        t.erase(t[3]);
    }
    var h = t[0];
    var hToSec = (((h.toInt()) * 60) * 60);
    var m = t[1];
    var mToSec = ((m.toInt()) * 60);
    var s = t[2];
    var parsedSec = s.toInt();
    // UPC-13133 round up to account for milliseconds
    if (increment) {
        parsedSec++;
    }

    return (hToSec + mToSec + parsedSec);
};

var getCurrentPage = function () {
    if (engine) {
        var indexOf = window.location.href.lastIndexOf('page_');
        if (indexOf > 0) {
            var pageName = window.location.href.substring(indexOf, window.location.href.indexOf('.htm'));
            var pageObj = engine.controller.getPageByName(pageName);
            return pageObj;
        }
    }
};

window.addEvent('load', function () {
    container = $("container");

    if (typeof container != "undefined") {
        var images = $$('#container img[onload^=checkImagesLoaded]');
        if (images.length == 0) {
            initContent();
        }
    }
});
window.addEvent('unload', function () {
    if (window.initTimeout) {
        clearTimeout(window.initTimeout);
    }
});
window.initTimeout = setTimeout(function () {
    window.initContent();
}, 5000);
