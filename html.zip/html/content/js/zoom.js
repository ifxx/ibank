
/*
 * Graphic zoom buttons for all images in a page
 * ---
 * 
 * Hotspot object members:
 * 	- id: 		The ID of the hotspot DIV
 * 	- img:		The image this hotspot belongs to
 *  - x:		The X location of the hotspot relative to its image
 *  - y:		The Y location of the hotspot relative to its image
 *  
 *  Example Usage:
 *  ---
 *  zoomButtons.push({id:'zoomBtn1', img:'img1', x:70, y:270});
 */


if(!window.Zoom){window.Zoom = {};}
Zoom.zoomButtons = [];
Zoom.zoomButtonContainers = [];

Zoom.createZoomButtons = function () {
    var images = document.querySelectorAll("img");
    //var len = $$("img[id^=img_]").length;
	for (var i = 0; i < images.length; i++) {
		// The current image
		var img = images[i];
		var imgId = img.id;

		if(!Zoom.isImageLoaded(img)){continue;}

		var zoomButtonObj = Zoom.getZoomButtonObjByImageId(img.id);
		var canAdd = false;

		if (zoomButtonObj) {
			if (zoomButtonObj.enabled)
			{
				canAdd = true;
			}
		} else {
			if (img.getAttribute("zoom")) {
				if (img.getAttribute("zoom") == "true") {
					canAdd = true;
				} else {
					canAdd = false;
				}
			} else {
				canAdd = false;
			}
		}

		if (canAdd)
		{
			var zoomBtnDiv = $("ZoomBtn_"+img.id);
			
			if (!zoomBtnDiv)
			{
				// Create a DIV for the zoom button
				zoomBtnDiv = new Element('div',{
					id: "ZoomBtn_"+img.id,
					"class": "zoomBtn",
					tabindex: 0,
					title: Lang.ACCESSIBILITY_ZOOM,
					role: 'application',
					events:{
							'click': function (e) {
							if(!e) var e = window.event;
							zoomImg(e,this);
						},
							'keydown': function (e) {
							if(!e) var e = window.event;
							
								if (e.code == 13) {
								zoomImg(e,this);
								e.stop();
							}
						},
							'mouseover': function (e) {
							Utils.dom.setOpacity(100,this.id);
						},
							'focus': function (e) {
							Utils.dom.setOpacity(100,this.id);
						},
							'mouseout': function (e) {
							Utils.dom.setOpacity(40,this.id);
						},
							'blur': function (e) {
							Utils.dom.setOpacity(40,this.id);
						}
					}
				});

				$('container').adopt(zoomBtnDiv);
			}
			else
			{
				continue;
			}

			Zoom.zoomButtonContainers.push(zoomBtnDiv);
			
			// Add the zoomBtn DIV as a property of the image element
			img.zoomBtn = zoomBtnDiv;
			
			var imgFile = unescape(img.src.substring(img.src.lastIndexOf("/")+1));
			var imgName = imgFile.split(".")[0];
			var imgExt = imgFile.split(".")[1];
			var imgPath = (imgName.indexOf("output_") < 0) ? "images/output_"+imgName+"."+imgExt : "images/"+imgName+"."+imgExt;
			var zoomsrc= img.getAttribute('zoomsrc');
			if (zoomsrc)
			{
				imgPath = zoomsrc;
			}

			zoomBtnDiv.imgPath = imgPath;
					
			// Add the mouse events to the zoom button and image
			var zoomImg = function (e, self)
			{
				Utils.window.open("zoom.htm?img="+self.imgPath,"zoomImageWin",100,100,'resizable,scrollbars');
			};
		}
	}

	// Update on the zoom button locations
	var func = function ()
	{
		Zoom.updateZoomButtons();
	}
	var t = (Utils.browserDetection.isMobile()) ? 500 : 0;
	setTimeout(func,t);
};

/**
* Removes all "old" zoom buttons, in the case of an assessment, etc.
* where a page doesn't reload before adding zoom buttons.
*/
Zoom.removeZoomButtons=function()
{
	var len = Zoom.zoomButtonContainers.length;
	for (var i = 0; i < len; i++)
	{
		var zoomBtnDiv = Zoom.zoomButtonContainers[i];
		
		if(zoomBtnDiv)
		{
			if(zoomBtnDiv.parentNode)
			{
				zoomBtnDiv.parentNode.removeChild(zoomBtnDiv);
			}
		}
	}

	var len = Zoom.zoomButtons.length;
	for (var i = 0; i < len; i++)
	{
		var z = Zoom.zoomButtons[i];
		var zoomBtnDiv = $(z.img);
		if(zoomBtnDiv)
		{
			zoomBtnDiv.parentNode.removeChild(zoomBtnDiv);
		}
	}

	Zoom.zoomButtons = [];
	Zoom.zoomButtonContainers = [];
}

/**
* Retrieves a zoom button object by image ID
*/
Zoom.getZoomButtonObjByImageId=function(id)
{
	var len = Zoom.zoomButtons.length;
	for (var i = 0; i < len; i++)
	{
		if(Zoom.zoomButtons[i].img === id)
		{
			return Zoom.zoomButtons[i];
		}
	}
	return false;
}

/**
* Updates the position of the zoom buttons in the event of window resize
*/
Zoom.updateZoomButtons=function()
{
	var len = $$('img').length;
	for(var i = 0; i < len; i++)
	{
		try
		{
			// The current image
			var img = $$('img')[i];

			//var x = Utils.dom.findPosX(img);
			//var y = Utils.dom.findPosY(img);

			var imgPos = img.getPosition();
			var x = imgPos.x;
			var y = imgPos.y;

			var zoomButtonObj = Zoom.getZoomButtonObjByImageId(img.id);
			if(zoomButtonObj)
			{
				if(Utils.browserDetection.isMobile())
				{
					var x = Utils.dom.findPosX(img)-$('container').getStyle('margin-left').toInt();
				}
				else
				{
					var x = Utils.dom.findPosX(img);
				}
				var y = Utils.dom.findPosY(img);
			}

			// Set the zoom button location
			Utils.dom.setStyleById("ZoomBtn_"+img.id, 'left', x, 'px');
			Utils.dom.setStyleById("ZoomBtn_"+img.id, 'top', y, 'px');
			
			
			
			if($("ZoomBtn_"+img.id))
				{
					if($("ZoomBtn_"+img.id).style.top === "0px" && $("ZoomBtn_"+img.id).style.left === "0px")
					{
						Utils.dom.setStyleById("ZoomBtn_"+img.id, "display", "none");
					}
				}
			
		}
		catch (e)
		{

		}
	}
};
Zoom.ZoomPopup = function()
{
	var len = $$('img').length;
	for(var i = 0; i < len; i++)
	{
		// The current image
		var img = $$('img')[i];
		if($(img.id) != null)
		{
			if($(img.id).getParent("div.popupContent"))
			{
				if($("ZoomBtn_"+img.id)) {
					Utils.dom.setStyleById("ZoomBtn_"+img.id, "display", "block");
					$("ZoomBtn_"+img.id).setStyle('z-index', '1000');
				}
			}
		} 
	}
}

Zoom.isImageLoaded=function(img)
{
	if(img.readyState)
	{
		if(img.readyState === "complete")
		{
			return true;
		}
	}
	else
	{
		if(img.complete)
		{
			return true;
		}
	}
	return false;
};
window.addEvent('load', function(){
	//Zoom.createZoomButtons();
});
window.addEvent('resize', function(){
	Zoom.updateZoomButtons();
});
