var originalClassName = "";
var currentAnimationIndex = -1;
var elementIdOfElementFiringAnimationEnd = "";
var isForceAbortAnimation = false;
var isPlayingAnimation = false;
var maxAnimationWaitingTime = 0;
var wrapperScrollWidth = null;

var onTransitionEnd = function () {
    var wrapper = document.getElementById('wrapper');
    if (wrapper) {
        Utils.dom.removeEvent(wrapper, "animationend", onTransitionEnd);
        wrapper.className = originalClassName;
        wrapper.style.animationDuration = "";
    }

    playAnimations();
};

var onAnimationEnd = function (){
    if(elementIdOfElementFiringAnimationEnd){
        var element = document.getElementById(elementIdOfElementFiringAnimationEnd);
        if(element){
            Utils.dom.removeEvent(element, "animationend", onAnimationEnd);
			//fix D-10919
			var wrapper = document.getElementById("wrapper");
			if(wrapper){
				wrapper.style.overflowX = 'auto';
				if(wrapperScrollWidth == wrapper.clientWidth && wrapperScrollWidth != wrapper.scrollWidth){
					wrapper.style.overflowX = 'hidden';
				}
			}
			// end D-10919
        }
    }
    
    isPlayingAnimation = false;
    if (!isForceAbortAnimation) {
        playAnimation("AfterPrevious");
    }
};

var getPlayingAnimation = function(trigger){
    var animations = engine.controller.getAnimations();
    if(animations && animations.length > currentAnimationIndex){
        var firstAnimation = animations[currentAnimationIndex];
        if(firstAnimation)
        {
            if(trigger == "OnKey" && firstAnimation.trigger != "OnKey"){
                return null;
            }
            
            if(trigger != "OnKey" && firstAnimation.trigger == "OnKey"){
                return null;
            }
            
            var listOfPlayingAnimation = [];
            listOfPlayingAnimation.push(firstAnimation);
            currentAnimationIndex ++;
            while(animations.length > currentAnimationIndex)
            {
                var animation = animations[currentAnimationIndex];
                if(animation && animation.trigger == "WithPrevious"){
                    currentAnimationIndex ++;
                    listOfPlayingAnimation.push(animation);
                }
                else
                {
                    break;
                }
            }
            
            return listOfPlayingAnimation;
        }
    }
    
    return null;
};

var setUpAnimationEnd = function(listPlayingAnimation){
    if(listPlayingAnimation && listPlayingAnimation.length > 0)
    {
        var animationLastEnd = listPlayingAnimation[0];
        for(var i = 1; i < listPlayingAnimation.length; i ++)
        {
            if(Number(listPlayingAnimation[i].duration) + Number(listPlayingAnimation[i].delay) > Number(animationLastEnd.duration) + Number(animationLastEnd.delay))
            {
                animationLastEnd = listPlayingAnimation[i];
            }
        }
        
        if(animationLastEnd){
            var element = document.getElementById(animationLastEnd.eleId);
            if(element)
            {
                elementIdOfElementFiringAnimationEnd = animationLastEnd.eleId;
                maxAnimationWaitingTime = Number(animationLastEnd.duration) + Number(animationLastEnd.delay);
                Utils.dom.addEvent(element, "animationend", onAnimationEnd);
            }
        }
    }
};

var createAnimationClass = function(currentClass, animation){
    var nIndex = currentClass.search("animated");
    if(nIndex != -1)
    {
        return currentClass.substring(0, nIndex) + " animated " + animation;
    }
    
    return currentClass + " animated " + animation;
};

var playAnimation = function(trigger){
    var listPlayingAnimation = getPlayingAnimation(trigger);
	var wrapper = document.getElementById("wrapper");
	if(wrapper){
		wrapperScrollWidth = wrapper.scrollWidth;
		if (wrapperScrollWidth == wrapper.clientWidth) {
	        wrapper.style.overflowX = "hidden";
	    }
	}
    if(listPlayingAnimation && listPlayingAnimation.length > 0){
        setUpAnimationEnd(listPlayingAnimation);
        isPlayingAnimation = true;
        for(var i = 0; i < listPlayingAnimation.length; i ++){
            var element = document.getElementById(listPlayingAnimation[i].eleId);
            if(element){
                element.style.animationDuration = listPlayingAnimation[i].duration + "s";
                if(listPlayingAnimation[i].delay > 0){
					element.style.animationDelay = listPlayingAnimation[i].delay + "s";
                }
                
                element.style.visibility = "visible";
                element.className = createAnimationClass(element.className ,listPlayingAnimation[i].styles);
            }
        }
        
        return true;
    }
    
    return false;
};

var onKeyDown = function(event){
    if(event.keyCode == 39)
    {
        if(!playAnimation("OnKey"))
        {
            engine.controller.next();
        }
    }
};

var playAnimations = function() {
	try {
		this.focus();
	    if (typeof isFlash != 'undefined' && isFlash) {
	        loadFlashContent();
	    }
	    else {
	        loadVideos();
	    }
        Utils.dom.addEvent(document, "keydown", onKeyDown);
        currentAnimationIndex = 0;
        playAnimation();
	} catch (Exception) {}
};

var hideElementWithAnimationEntrance = function(){
    var animations = engine.controller.getAnimations();
    if(animations){
        for(var i = 0; i < animations.length; i ++){
            if(animations[i] && animations[i].styles && animations[i].styles.search("In") != -1 && animations[i].eleId){
                var element = document.getElementById(animations[i].eleId);
                if(element){
                    element.style.visibility = "hidden";
                }
            }
        }
    }
};

var playTransition = function() {
	try {
		this.focus();
        hideElementWithAnimationEntrance();
		var currentTransition = engine.controller.getTransitionIn();
		if (currentTransition != null && currentTransition != "") {
			var wrapper = document.getElementById('wrapper');
			if (wrapper) {
				originalClassName = wrapper.className;
				wrapper.style.animationDuration = engine.controller.getTransitionDuration();
				Utils.dom.addEvent(wrapper, "animationend", onTransitionEnd);
				wrapper.className = wrapper.className + ' animated  ' + currentTransition;
			}
			else {
				playAnimations();
			}
		}
		else {
			playAnimations();
		}
	} catch (Exception) {}
};